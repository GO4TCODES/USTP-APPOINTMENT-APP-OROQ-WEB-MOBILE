import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:mailer/smtp_server.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:intl/intl.dart';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'main.dart';
import 'package:flutter/services.dart';
import 'dart:convert';
import 'package:mailer/mailer.dart';

void main() {
  HttpClient().badCertificateCallback =
      (X509Certificate cert, String host, int port) => true;
  HttpOverrides.global = MyHttpOverrides();
  runApp(const MaterialApp(
    debugShowCheckedModeBanner: false,
    home: AppointmentFormPage(
      email: '',
      course: '',
    ),
  ));
}

class AppointmentFormPage extends StatefulWidget {
  final String email;
  final String course;

  const AppointmentFormPage({
    Key? key,
    required this.email,
    required this.course,
  }) : super(key: key);

  @override
  _AppointmentFormPageState createState() =>
      _AppointmentFormPageState(email: email, course: course);
}

class _AppointmentFormPageState extends State<AppointmentFormPage> {
  _AppointmentFormPageState({
    required this.email,
    required this.course,
  });
  final String course;
  DateTime dateOfRequest = DateTime.now();
  DateTime? dateOfGraduation;
  DateTime? dateRequested;
  final String email;
  String? dateOfRequestText;
  String? dateOfGraduationText;
  String? dateRequestedText;

  bool alreadyRequestedCredentials = false;
  bool cleared = true;

  final _formKey = GlobalKey<FormState>();

  List<String> categoryOptions = ['Undergraduate', 'Graduate'];

  List<String> yearOptions = ['1st Year', '2nd Year', '3rd Year', '4rth Year'];

  String? selectedCategory;
  String? selectedCourse;
  String? selectedYear;
  String? lastSemesterAndSY;
  String specifyText = '';
  TextEditingController specifyController = TextEditingController();

  Future<void> _selectDateOfRequest(BuildContext context) async {
    final DateTime currentDate = DateTime.now();
    final formattedDate = DateFormat('yyyy-MM-dd').format(currentDate);
    setState(() {
      dateOfRequest = currentDate;
      dateOfRequestText = 'Date: $formattedDate';
    });
  }

  Future<void> _selectDateOfGraduation(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(2000),
      lastDate: DateTime(2101),
    );
    if (picked != null) {
      final formattedDate = DateFormat('yyyy-MM-dd').format(picked);
      setState(() {
        dateOfGraduation = picked;
        dateOfGraduationText = 'Date: $formattedDate';
      });
    }
  }

  Future<List<DateTime>> fetchUnavailableDates() async {
    final response = await http.get(
        Uri.parse('https://ustp-appointment.online/USTP APP/unselectday.php'));

    if (response.statusCode == 200) {
      final List<String> dateStringList =
          (json.decode(response.body) as List).cast<String>();
      final List<DateTime> unavailableDates = dateStringList
          .map((dateString) => DateTime.parse(dateString))
          .toList();
      return unavailableDates;
    } else {
      throw Exception('Failed to load unavailable dates');
    }
  }

  List<DropdownMenuItem<String>> generateSemesterOptions() {
    int currentYear = 2021;
    int futureYear = 2030;
    List<DropdownMenuItem<String>> options = [];
    int currentSemester = 1;
    while (currentYear <= futureYear) {
      String nextYear = (currentYear + 1).toString();
      String semesterText =
          '$currentSemester${currentSemester == 1 ? 'ST' : 'ND'} SEM, $currentYear-$nextYear';
      options.add(
        DropdownMenuItem<String>(
          value: semesterText,
          child: Text(semesterText),
        ),
      );

      currentSemester = 3 - currentSemester;
      if (currentSemester == 1) {
        currentYear++;
      }
    }

    return options;
  }

  Future<void> _selectDateRequested(BuildContext context) async {
    List<DateTime> unavailableDates = await fetchUnavailableDates();

    DateTime now = DateTime.now();
    while (unavailableDates.contains(now)) {
      now = now.add(Duration(days: 1));
    }
    DateTime defaultDate = DateTime(2023, 1, 2);
    DateTime firstDate = DateTime(2000);
    DateTime lastDate = DateTime(2101);

    DateTime? picked = await showDatePicker(
      context: context,
      initialDate: defaultDate,
      firstDate: firstDate,
      lastDate: lastDate,
      selectableDayPredicate: (DateTime date) {
        if (unavailableDates.contains(date)) {
          return false;
        }

        return date.weekday != DateTime.saturday &&
            date.weekday != DateTime.sunday;
      },
    );

    if (picked != null) {
      final formattedDate = DateFormat('yyyy-MM-dd').format(picked);
      setState(() {
        dateRequested = picked;
        dateRequestedText = 'Date: $formattedDate';
      });
    }
  }

  bool isFormValid() {
    return _formKey.currentState?.validate() == true &&
        dateRequested != null &&
        selectedCategory != null &&
        dateRequested != null;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Make Appointment',
          style: TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold),
        ),
        backgroundColor: const Color.fromARGB(255, 236, 193, 0),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              const SizedBox(height: 16.0),
              const Text(
                'Request for Credential form',
                style: TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 16.0),
              const Text('Please fill out the following information:'),
              const SizedBox(height: 16.0),
              DropdownButtonFormField<String>(
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Please select a category';
                  }
                  return null;
                },
                hint: const Text('Select Category'),
                value: selectedCategory,
                items: categoryOptions.map((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
                onChanged: (String? value) {
                  setState(() {
                    selectedCategory = value;
                  });
                },
              ),
              Divider(
                thickness: 2,
              ),
              const SizedBox(height: 16.0),
              Text(
                'Course: $course',
                style: TextStyle(
                  fontSize: 16.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 16.0),
              Divider(
                thickness: 2,
              ),
              Visibility(
                visible: selectedCategory != 'Graduate',
                child: DropdownButtonFormField<String>(
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return 'Please select a year';
                    }
                    return null;
                  },
                  hint: const Text('Select Year'),
                  value: selectedYear,
                  items: yearOptions.map((String value) {
                    return DropdownMenuItem<String>(
                      value: value,
                      child: Text(value),
                    );
                  }).toList(),
                  onChanged: (String? value) {
                    setState(() {
                      selectedYear = value;
                    });
                  },
                ),
              ),
              Divider(
                thickness: 2,
              ),
              const Text(
                'Date Of Request:',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8.0),
              Row(
                children: <Widget>[
                  Expanded(
                    child: Text(
                      dateOfRequestText ??
                          DateFormat('yyyy-MM-dd').format(DateTime.now()),
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 14.0),
              Divider(
                thickness: 2,
              ),
              const SizedBox(height: 10.0),
              const Text(
                '*REMINDER*',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              const Text(
                'A. If requested by the person himself/herself named in the document, a valid Identification (ID) card must be presented.',
              ),
              const Text(
                'B. If requested by an authorized person, the following items must be presented:',
              ),
              ListTile(
                title: const Text('1. Authorization Letter'),
              ),
              ListTile(
                title: const Text('2. Photocopy of valid ID cards (Owner)'),
              ),
              ListTile(
                title: const Text(
                    '3. Photocopy of valid ID card (Authorizing Person)'),
              ),
              const SizedBox(height: 7.0),
              Visibility(
                visible: selectedCategory == 'Graduate',
                child: Column(
                  children: [
                    Divider(
                      thickness: 2,
                    ),
                    const SizedBox(height: 10.0),
                    const Text(
                      'Graduate:',
                      style: TextStyle(fontWeight: FontWeight.bold),
                    ),
                    const Text(
                      'Part 1: Please complete entries below: If graduate, state the Date of graduation:',
                    ),
                    Row(
                      children: <Widget>[
                        Expanded(
                          child: Text(
                            dateOfGraduationText ?? 'Select Date',
                          ),
                        ),
                        ElevatedButton(
                          onPressed: () => _selectDateOfGraduation(context),
                          style: ElevatedButton.styleFrom(
                            backgroundColor:
                                const Color.fromRGBO(219, 168, 0, 1),
                          ),
                          child: const Text(
                            'Pick Date',
                            style: TextStyle(
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 16.0),
              Divider(
                thickness: 2,
              ),
              const Text(
                'If already requested credentials (as stated below) before',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              Row(
                children: <Widget>[
                  Expanded(
                    child: Row(
                      children: <Widget>[
                        Radio(
                          value: true,
                          groupValue: alreadyRequestedCredentials,
                          onChanged: (bool? value) {
                            setState(() {
                              alreadyRequestedCredentials = value!;
                              if (!alreadyRequestedCredentials) {
                                specifyText = "No";
                              }
                            });
                          },
                        ),
                        const Text('Yes'),
                        Radio(
                          value: false,
                          groupValue: alreadyRequestedCredentials,
                          onChanged: (bool? value) {
                            setState(() {
                              alreadyRequestedCredentials = value!;
                              if (!alreadyRequestedCredentials) {
                                specifyText = "No";
                              }
                            });
                          },
                        ),
                        const Text('No'),
                      ],
                    ),
                  ),
                ],
              ),
              if (alreadyRequestedCredentials)
                ElevatedButton(
                  onPressed: () {
                    showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime(2000),
                      lastDate: DateTime(2101),
                    ).then((selectedDate) {
                      if (selectedDate != null) {
                        setState(() {
                          specifyText = selectedDate.toString();
                        });
                      }
                    });
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color.fromRGBO(219, 168, 0, 1),
                  ),
                  child: Text(
                    specifyText.isNotEmpty
                        ? 'Picked Date: $specifyText'
                        : 'Pick Date',
                    style: TextStyle(
                      color: Colors.white,
                    ),
                  ),
                ),
              const SizedBox(height: 20.0),
              Divider(
                thickness: 2,
              ),
              const Text(
                'Date Requested:',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
              Row(
                children: <Widget>[
                  Expanded(
                    child: Text(
                      dateRequestedText ?? 'Select Date',
                    ),
                  ),
                  ElevatedButton(
                    onPressed: () => _selectDateRequested(context),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color.fromRGBO(219, 168, 0, 1),
                    ),
                    child: const Text(
                      'Pick Date',
                      style: TextStyle(
                        color: Colors.white,
                      ),
                    ),
                  ),
                  const SizedBox(height: 20.0),
                ],
              ),
              Divider(
                thickness: 2,
              ),
              const SizedBox(height: 16.0),
              ElevatedButton(
                onPressed: isFormValid()
                    ? () {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => NextPage(
                              selectedCategory: selectedCategory,
                              selectedCourse: course,
                              selectedYear: selectedYear,
                              dateOfRequestText: dateOfRequestText,
                              dateOfRequest: dateOfRequest,
                              dateRequested: dateRequested,
                              alreadyRequestedCredentials:
                                  alreadyRequestedCredentials,
                              specifytext: specifyText,
                              dateOfGraduation: dateOfGraduation,
                              dateRequestedText: dateRequestedText,
                              dateOfGraduationText: dateOfGraduationText,
                              lastSemesterAndSY: lastSemesterAndSY,
                              email: email,
                              requirements: [],
                            ),
                          ),
                        );
                      }
                    : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: isFormValid()
                      ? const Color.fromARGB(255, 0, 2, 117)
                      : Colors.grey,
                  minimumSize: const Size(double.infinity, 60),
                  elevation: isFormValid() ? 4 : 0,
                ),
                child: const Padding(
                  padding: EdgeInsets.symmetric(vertical: 16.0),
                  child: Text(
                    'Next',
                    style: TextStyle(
                      fontSize: 20.0,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16.0),
            ],
          ),
        ),
      ),
    );
  }
}

class NextPage extends StatefulWidget {
  final String? selectedCategory;
  final String? selectedCourse;
  final String? selectedYear;
  final DateTime? dateOfRequest;
  final DateTime? dateRequested;
  final bool alreadyRequestedCredentials;
  final String specifytext;
  final DateTime? dateOfGraduation;
  final String? dateOfRequestText;
  final String? dateRequestedText;
  final String? dateOfGraduationText;
  final String? lastSemesterAndSY;
  final String email;
  final List<String>? requirements;
  const NextPage({
    super.key,
    required this.selectedCategory,
    required this.selectedCourse,
    required this.selectedYear,
    required this.dateOfRequest,
    required this.dateRequested,
    required this.alreadyRequestedCredentials,
    required this.specifytext,
    required this.dateOfGraduation,
    required this.dateOfRequestText,
    required this.dateRequestedText,
    required this.dateOfGraduationText,
    required this.lastSemesterAndSY,
    required this.email,
    required this.requirements,
  });

  @override
  _NextPageState createState() => _NextPageState();
}

class _NextPageState extends State<NextPage> {
  String? selectedType;
  String? selectedPurpose;

  List<String> types = [
    'Diploma Replacement',
    'Evaluation',
    'Honorable Dismissal',
    'Correction of Name',
    'Transcript of Records',
    'CAV Certification',
    'Certification',
    'Authentication',
  ];

  List<String> purposes = [
    'For Evaluation',
    'For Personal',
    'For Advanced Studies',
    'For Employment',
    'For Scholarship',
    'For Board Exam',
    'For Passport',
    'For Ranking',
    'Others',
  ];

  bool isNextButtonEnabled() {
    return selectedType != null && selectedPurpose != null;
  }

  void navigateToSelectedTypePage() {
    if (selectedType != null) {
      List<String>? requirements =
          SchoolRequirementPage.requirementsByType[selectedType!];

      if (requirements != null) {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => SchoolRequirementPage(
              title: selectedType!,
              selectedCategory: widget.selectedCategory,
              selectedCourse: widget.selectedCourse,
              selectedYear: widget.selectedYear,
              dateOfRequest: widget.dateOfRequest,
              dateRequested: widget.dateRequested,
              alreadyRequestedCredentials: widget.alreadyRequestedCredentials,
              specifyText: widget.specifytext,
              dateOfGraduation: widget.dateOfGraduation,
              lastSemesterAndSY: widget.lastSemesterAndSY,
              selectedPurpose: selectedPurpose,
              email: widget.email,
              requirements: requirements,
              selectedCAVCertification: null,
              selectedCertification: null,
            ),
          ),
        );
      }
    }
  }

  Future<void> pickFile() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles();
    if (result != null) {
      PlatformFile file = result.files.first;

      print('Selected file: ${file.name}');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Choose Type of School Requirements',
          style: TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold),
        ),
        backgroundColor: const Color.fromARGB(255, 236, 193, 0),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              /*Container(
                    padding: const EdgeInsets.all(12.0),
                    decoration: BoxDecoration(
                      color: Colors.blueGrey,
                      borderRadius: BorderRadius.circular(8.0),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Transferred Data:',
                          style: TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        Text('Email: ${widget.email ?? ''}',
                            style: TextStyle(color: Colors.white)),
                        Text('Category: ${widget.selectedCategory ?? ''}',
                            style: TextStyle(color: Colors.white)),
                        Text('Course: ${widget.selectedCourse ?? ''}',
                            style: TextStyle(color: Colors.white)),
                        Text('Year: ${widget.selectedYear ?? ''}',
                            style: TextStyle(color: Colors.white)),
                        Text('Date of Request: ${widget.dateOfRequestText ?? ''}',
                            style: TextStyle(color: Colors.white)),
                        Text('SY: ${widget.lastSemesterAndSY ?? ''}',
                            style: TextStyle(color: Colors.white)),
                        Text(
                            'Date of Graduation: ${widget.dateOfGraduationText ?? ''}',
                            style: TextStyle(color: Colors.white)),
                        Text(
                            'Already Requested Credentials: ${widget.alreadyRequestedCredentials ? 'Yes' : 'No'}',
                            style: TextStyle(color: Colors.white)),
                        Text('Date Requested: ${widget.dateRequestedText ?? ''}',
                            style: TextStyle(color: Colors.white)),
                      ],
                    ),
                  ),*/
              const Text('Select Type of Requirement:'),
              const SizedBox(height: 16.0),
              Wrap(
                spacing: 8.0,
                runSpacing: 8.0,
                children: types.map((String type) {
                  return GestureDetector(
                    onTap: () {
                      setState(() {
                        selectedType = type;
                      });
                    },
                    child: Container(
                      width: 100,
                      height: 100,
                      decoration: BoxDecoration(
                        color: selectedType == type
                            ? const Color.fromARGB(255, 236, 193, 0)
                            : Colors.grey,
                        borderRadius: BorderRadius.circular(10.0),
                        border: selectedType == type
                            ? Border.all(
                                color: const Color.fromARGB(255, 236, 193, 0),
                                width: 2.0,
                              )
                            : null,
                      ),
                      child: Center(
                        child: Text(
                          type,
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                            fontSize: 14.0,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ),
              const SizedBox(height: 16.0),
              const Text('Select Purpose of Request:'),
              const SizedBox(height: 16.0),
              DropdownButton<String>(
                value: selectedPurpose,
                onChanged: (String? newValue) {
                  setState(() {
                    selectedPurpose = newValue;
                  });
                },
                items: purposes.map((String purpose) {
                  return DropdownMenuItem<String>(
                    value: purpose,
                    child: Text(purpose),
                  );
                }).toList(),
              ),
              const SizedBox(height: 160.0),
              ElevatedButton(
                onPressed:
                    isNextButtonEnabled() ? navigateToSelectedTypePage : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: isNextButtonEnabled()
                      ? const Color.fromARGB(200, 0, 2, 117)
                      : Colors.grey,
                  minimumSize: const Size(double.infinity, 60),
                  elevation: isNextButtonEnabled() ? 4 : 0,
                ),
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 16.0),
                  child: Text(
                    'Next',
                    style: TextStyle(
                      fontSize: 20.0,
                      color: isNextButtonEnabled()
                          ? Color.fromARGB(255, 255, 255, 255)
                          : Colors.grey,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

String formatDate(DateTime? date) {
  if (date != null) {
    return "${date.year.toString().padLeft(4, '0')}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}";
  } else {
    return "";
  }
}

final List<String> cavCertificationTypes = [
  'PNP',
  'DEP-ED',
  'BFP',
  'BJMP',
  'Coast guard',
  'National',
  'Abroad'
];
final List<String> certificationTypes = [
  'HD',
  'COE',
  'Certificate Of Graduate',
  'NSTP Certificate Number',
  'Certificate Of Earned Units'
];
String? selectedCAVCertification;
String? selectedCertification;

class SchoolRequirementPage extends StatefulWidget {
  final String title;
  final String? selectedCategory;
  final String? selectedCourse;
  final String? selectedYear;
  final DateTime? dateOfRequest;
  final DateTime? dateRequested;
  final bool alreadyRequestedCredentials;
  final String specifyText;
  final DateTime? dateOfGraduation;
  final String? lastSemesterAndSY;
  final String? selectedPurpose;
  final String dateOfRequestText;
  final String dateOfGraduationText;
  final String dateRequestedText;
  final String email;
  final List<String>? requirements;
  final String? selectedCAVCertification;
  final String? selectedCertification;

  static final Map<String, List<String>> requirementsByType = {
    'Diploma Replacement': [
      '1 pc. of Long Brown Envelope',
      '100 Pesos Payment',
      'Original Copy of PSA',
      'Affidavit of Loss Original copy',
      'Original Copy of PSA',
    ],
    'Evaluation': ['Clearance', 'Request Form', 'Payment: ₱1͟2͟5͟.͟0͟0 Pesos'],
    'Honorable Dismissal': [
      'Clearance',
      'Request Form',
      'Payment: ₱1͟2͟5͟.͟0͟0 Pesos'
    ],
    'Correction of Name': ['PSA Birth Certificate'],
    'Transcript of Records': [
      'Clearance',
      'Request Form',
      'Payment: ₱1͟2͟5͟.͟0͟0 Pesos per page'
    ],
    'CAV Certification': [
      '1 original TOR remarkable for Employment',
      '1 original Diploma',
      '1 copy each',
      '1 long Brown Envelope'
    ],
    'Certification': [
      'Clearance',
      'Request Form',
      '1 copy each',
      '1 long brown envelope',
      'Payment: ₱1͟2͟5͟.͟0͟0 Pesos'
    ],
    'Authentication': [
      'Clearance',
      'Request Form',
      '1 copy each',
      '1 long brown envelope',
      'Payment: ₱1͟2͟5͟.͟0͟0 Pesos'
    ],
  };

  SchoolRequirementPage(
      {super.key,
      required this.title,
      required this.selectedCategory,
      required this.selectedCourse,
      required this.selectedYear,
      required this.dateOfRequest,
      required this.dateRequested,
      required this.alreadyRequestedCredentials,
      required this.specifyText,
      required this.dateOfGraduation,
      required this.lastSemesterAndSY,
      required this.selectedPurpose,
      required this.email,
      required this.requirements,
      required this.selectedCAVCertification,
      required this.selectedCertification})
      : dateOfRequestText = formatDate(dateOfRequest),
        dateOfGraduationText = formatDate(dateOfGraduation),
        dateRequestedText = formatDate(dateRequested);

  @override
  _SchoolRequirementPageState createState() => _SchoolRequirementPageState();
}

class _SchoolRequirementPageState extends State<SchoolRequirementPage> {
  late Uint8List certificate;
  File? selectedFile;

  @override
  void initState() {
    super.initState();
    isFilePicked = false;
  }

  bool isFilePicked = false;

  Future<void> completeAppointment() async {
    HttpClient().badCertificateCallback =
        (X509Certificate cert, String host, int port) => true;

    const url =
        'https://ustp-appointment.online/USTP APP/completeAppointment.php';

    final dateOfRequestText = formatDate(widget.dateOfRequest);
    final dateOfGraduationText = formatDate(widget.dateOfGraduation);
    final dateRequestedText = formatDate(widget.dateRequested);

    final data = {
      'email': widget.email ?? '',
      'title': widget.title,
      'selectedPurpose': widget.selectedPurpose ?? '',
      'selectedCategory': widget.selectedCategory ?? '',
      'selectedCourse': widget.selectedCourse ?? '',
      'selectedYear': widget.selectedYear ?? '',
      'dateOfRequest': dateOfRequestText ?? '',
      'lastSemesterAndSY': widget.lastSemesterAndSY ?? '',
      'dateOfGraduation': dateOfGraduationText ?? '',
      'alreadyRequestedCredentials':
          widget.alreadyRequestedCredentials ? 'Yes' : 'No',
      'specifyText': widget.specifyText ?? '',
      'dateRequested': dateRequestedText,
      'selectedCAVCertification': selectedCAVCertification ?? '',
      'selectedCertification': selectedCertification ?? '',
    };

    if (selectedFile != null) {
      final fileBytes = await selectedFile!.readAsBytes();
      final base64File = base64Encode(fileBytes);
      data['file'] = base64File;
    }

    final response = await http.post(
      Uri.parse(url),
      body: data,
    );
    Future<void> sendEmail() async {
      final smtpServer = SmtpServer(
        'smtp.hostinger.com',
        username: 'ustp-oro@ustp-appointment.online',
        password: ' ',
        port:  ,
        ssl: true,
        allowInsecure: false,
      );

      final message = Message()
        ..from =
            Address('ustp-oro@ustp-appointment.online', 'USTP APP OROQUIETA')
        ..recipients.add(widget.email)
        ..subject = 'Appointment Created Successfully'
        ..html = '''
          <p>Dear ${widget.email}, 
          <p>We are pleased to inform you that your appointment has been successfully created. 
          Below, you will find a comprehensive summary of the information you provided:</p>
          <ul>
            <li>Document Type: ${widget.title}</li>
            <li>Purpose: ${widget.selectedPurpose}</li>
            <li>Category: ${widget.selectedCategory}</li>
            <li>Course: ${widget.selectedCourse}</li>
            <li>Year: ${widget.selectedYear}</li>
            <li>Date of Request: ${widget.dateOfRequestText}</li>
            <li>Date Requested: ${widget.dateRequestedText}</li>
          
          <br>
          NOTE: This document might take  1-3 months to process.
          
          </ul>
          

          If you have any further questions or require additional assistance, please do not hesitate to reach out to us.
<br><br><br>
Cordially,
<br>
USTP-APP OROQUIETA
        ''';

      try {
        final sendReport = await send(message, smtpServer);
        if (sendReport != null) {
          print('Message sent successfully.');
        } else {
          print('Message not sent.');
        }
      } catch (e) {
        print('Error sending email: $e');
      }
    }

    void resetFields() {
      setState(() {
        selectedFile = null;
        selectedCAVCertification = null;
        selectedCertification = null;
      });
    }

    if (response.statusCode == 200) {
      print('Data inserted successfully');

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
              'Appointment created successfully. Your account will receive an email shortly.'),
          behavior: SnackBarBehavior.floating,
        ),
      );
      resetFields();
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(
          builder: (context) => HomeScreen(email: widget.email),
        ),
      );
    } else {
      print('Error inserting data: ${response.statusCode}');
    }
    await sendEmail();
  }

  Future<void> pickFile() async {
    var status = await Permission.storage.request();
    var status2 = await Permission.photos.request();
    if (status.isGranted) {
      try {
        final result = await FilePicker.platform.pickFiles();

        if (result != null) {
          setState(() {
            selectedFile = File(result.files.single.path!);
            isFilePicked = true;
          });
        }
      } catch (e) {
        print("Error picking file: $e");
      }
    }
    if (status2.isGranted) {
      try {
        final result = await FilePicker.platform.pickFiles();

        if (result != null) {
          setState(() {
            selectedFile = File(result.files.single.path!);
            isFilePicked = true;
          });
        }
      } catch (e) {
        print("Error picking file: $e");
      }
    } else {
      print("External storage permission denied.");
    }
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        return true;
      },
      child: Scaffold(
        appBar: AppBar(
          title: Text(
            widget.title,
            style: const TextStyle(fontSize: 24.0, fontWeight: FontWeight.bold),
          ),
          backgroundColor: const Color.fromARGB(255, 236, 193, 0),
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: <Widget>[
              const Text(
                'Specific Requirements:',
                style: TextStyle(fontSize: 30.0, fontWeight: FontWeight.bold),
              ),
              Divider(
                thickness: 2,
              ),
              if (widget.requirements != null)
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: widget.requirements!.map((requirement) {
                    return Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '• ',
                          style: const TextStyle(
                            fontWeight: FontWeight.bold,
                            fontSize: 19.0,
                          ),
                        ),
                        Expanded(
                          child: Text(
                            requirement,
                            style: const TextStyle(fontSize: 16.0),
                          ),
                        ),
                      ],
                    );
                  }).toList(),
                ),
              Divider(
                thickness: 2,
              ),
              const SizedBox(height: 16.0),
              if (widget.title == 'CAV Certification')
                DropdownButton<String>(
                  value: selectedCAVCertification,
                  hint: Text('Choose CAV Certification Type'),
                  items: cavCertificationTypes.map((type) {
                    return DropdownMenuItem<String>(
                      value: type,
                      child: Text(type),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setState(() {
                      selectedCAVCertification = value;
                    });
                  },
                ),
              const SizedBox(height: 16.0),
              if (widget.title == 'Certification')
                DropdownButton<String>(
                  value: selectedCertification,
                  hint: Text('Choose Certification Type'),
                  items: certificationTypes.map((type) {
                    return DropdownMenuItem<String>(
                      value: type,
                      child: Text(type),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setState(() {
                      selectedCertification = value;
                    });
                  },
                ),
              const SizedBox(height: 16.0),
              const Text(
                'Must be cleared in Eclearance. Pls visit first the link to get screenshots of your e clearance. Then upload the screenshot by clicking the upload button below.:',
                style: TextStyle(fontSize: 16.0),
              ),
              const SizedBox(height: 8.0),
              Center(
                child: InkWell(
                  onTap: () {
                    const url = 'https://clearance.ustp.edu.ph';
                    launch(url);
                  },
                  child: Text(
                    'https://clearance.ustp.edu.ph',
                    style: TextStyle(
                      fontSize: 16.0,
                      color: Color.fromARGB(255, 19, 0, 139),
                      decoration: TextDecoration.underline,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16.0),
              if (selectedFile != null)
                Center(
                  child: Text(
                    'File: ${selectedFile!.path}',
                    style: const TextStyle(fontSize: 16.0),
                  ),
                ),
              const SizedBox(height: 50.0),
              Center(
                child: ElevatedButton(
                  onPressed: () {
                    pickFile();
                  },
                  style: ElevatedButton.styleFrom(
                    primary: Color.fromARGB(255, 236, 193, 0),
                  ),
                  child: const Text(
                    'Upload',
                    style: TextStyle(
                      fontSize: 40.0,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16.0),
              const Text(
                '             Click Upload to Attached E-Clearance',
                style: TextStyle(fontSize: 16.0),
              ),
              const SizedBox(height: 180.0),
              Column(
                children: <Widget>[
                  ElevatedButton(
                    onPressed: isFilePicked ? completeAppointment : null,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: isFilePicked
                          ? const Color.fromARGB(255, 53, 180, 28)
                          : Colors.grey,
                      minimumSize: const Size(double.infinity, 60),
                    ),
                    child: const Padding(
                      padding: EdgeInsets.symmetric(vertical: 16.0),
                      child: const Text(
                        'Complete Appointment',
                        style: TextStyle(
                          fontSize: 15.0,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
