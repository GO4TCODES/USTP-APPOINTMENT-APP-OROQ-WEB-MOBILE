import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:table_calendar/table_calendar.dart';
import 'package:flutter/material.dart';
import 'dart:io';
import 'package:http/http.dart' as http;
import "AppointmentFormPage.dart";
import 'package:image_picker/image_picker.dart';
import 'dart:math';

import 'package:mailer/mailer.dart';
import 'package:mailer/smtp_server.dart';

//import 'package:firebase_auth/firebase_auth.dart';

class PasswordResetScreen extends StatelessWidget {
  final TextEditingController emailController = TextEditingController();

  Future<void> sendEmail(BuildContext context) async {
    final smtpServer = SmtpServer(
      'smtp.hostinger.com',
      username: 'ustp-oro@ustp-appointment.online',
      password: 'Ustp_23!!!',
      port: 465,
      ssl: true,
      allowInsecure: false,
    );

    final code = generateRandomCode();
    final recipientEmail = emailController.text;

    bool emailExists = await checkIfEmailExistsInDatabase(recipientEmail);

    if (!emailExists) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Email is not registered.'),
      ));

      return;
    }

    final message = Message()
      ..from = Address('ustp-oro@ustp-appointment.online')
      ..recipients.add(recipientEmail)
      ..subject = 'Password Reset Code'
      ..text = 'Your reset code is: $code';

    try {
      await send(message, smtpServer);
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Code sent to your email. Please check you mailbox.'),
      ));

      sendResetCodeToServer(recipientEmail, code);

      Navigator.of(context).push(MaterialPageRoute(
        builder: (context) => VerificationScreen(recipientEmail),
      ));
    } catch (e) {
      print('error: $e');
    }
  }

  Future<bool> checkIfEmailExistsInDatabase(String email) async {
    final response = await http.get(Uri.parse(
        'https://ustp-appointment.online/USTP%20APP/check_email.php?email=$email'));
    if (response.statusCode == 200) {
      return response.body == 'true';
    } else {
      return false;
    }
  }

  Future<void> sendResetCodeToServer(String email, String code) async {
    final response = await http.post(
      Uri.parse('https://ustp-appointment.online/USTP APP/password_reset.php'),
      body: {
        'action': 'insertCode',
        'email': email,
        'code': code,
      },
    );

    if (response.statusCode == 200) {
      print('Code sent to the server');
    } else {
      print('Failed to send code to the server');
    }
  }

  String generateRandomCode() {
    final random = Random();
    final codeLength = 6;
    final code = List.generate(codeLength, (_) => random.nextInt(10)).join('');
    return code;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Reset Password'),
        backgroundColor: const Color.fromARGB(255, 236, 193, 0),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: <Widget>[
            TextField(
              controller: emailController,
              decoration: InputDecoration(
                labelText: 'Email',
              ),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                sendEmail(context);
              },
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all<Color>(
                  Color.fromARGB(255, 1, 0, 75),
                ),
              ),
              child: Text('Send Reset Code'),
            ),
          ],
        ),
      ),
    );
  }
}

class VerificationScreen extends StatefulWidget {
  final String userEmail;

  VerificationScreen(this.userEmail);

  @override
  _VerificationScreenState createState() => _VerificationScreenState();
}

class _VerificationScreenState extends State<VerificationScreen> {
  TextEditingController codeController = TextEditingController();
  String verificationMessage = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Verification'),
        backgroundColor: const Color.fromARGB(255, 236, 193, 0),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: <Widget>[
            Text('Enter the verification code sent to your email:'),
            TextField(
              controller: codeController,
              decoration: InputDecoration(
                labelText: 'Verification Code',
              ),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                verifyCode();
              },
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all<Color>(
                  Color.fromARGB(255, 56, 212, 0),
                ),
              ),
              child: Text('Verify'),
            ),
            SizedBox(height: 16.0),
            Text(
              verificationMessage,
              style: TextStyle(
                color: verificationMessage == 'Verification successful'
                    ? const Color.fromARGB(255, 0, 128, 4)
                    : const Color.fromARGB(255, 255, 17, 0),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void verifyCode() {
    final enteredCode = codeController.text;
    final email = widget.userEmail;

    http.post(
      Uri.parse('https://ustp-appointment.online/USTP APP/verify_code.php'),
      body: {
        'email': email,
        'code': enteredCode,
      },
    ).then((response) {
      if (response.statusCode == 200) {
        final String result = response.body;
        if (result == 'Verified') {
          setState(() {
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(
              content: Text('Code Verified! Please enter new password.'),
            ));
          });

          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (context) => NewPasswordScreen(userEmail: email),
            ),
          );
        } else {
          setState(() {
            verificationMessage = 'Invalid code! Please input code.';
          });
        }
      } else {
        setState(() {
          verificationMessage =
              'Failed to verify code (HTTP ${response.statusCode})';
        });
      }
    }).catchError((error) {
      setState(() {
        verificationMessage = 'An error occurred: $error';
      });
    });
  }
}

class NewPasswordScreen extends StatefulWidget {
  final String userEmail;

  NewPasswordScreen({required this.userEmail});

  @override
  _NewPasswordScreenState createState() => _NewPasswordScreenState();
}

class _NewPasswordScreenState extends State<NewPasswordScreen> {
  TextEditingController newPasswordController = TextEditingController();
  TextEditingController confirmNewPasswordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color.fromARGB(255, 56, 212, 0),
        title: Text('Create Your New Password'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: <Widget>[
            Text('Enter your new password:'),
            TextField(
              controller: newPasswordController,
              obscureText: true,
              decoration: InputDecoration(
                labelText: 'New Password',
              ),
            ),
            SizedBox(height: 16.0),
            Text('Confirm your new password:'),
            TextField(
              controller: confirmNewPasswordController,
              obscureText: true,
              decoration: InputDecoration(
                labelText: 'Confirm New Password',
              ),
            ),
            SizedBox(height: 16.0),
            ElevatedButton(
              onPressed: () {
                resetPassword();
              },
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all<Color>(
                  Color.fromARGB(255, 56, 212, 0),
                ),
              ),
              child: Text('Reset Password'),
            ),
          ],
        ),
      ),
    );
  }

  void resetPassword() async {
    final newPassword = newPasswordController.text;
    final confirmNewPassword = confirmNewPasswordController.text;

    if (newPassword == confirmNewPassword) {
      final email = widget.userEmail;

      final response = await http.post(
        Uri.parse('https://ustp-appointment.online/USTP APP/password.php'),
        body: {
          'action': 'resetPassword',
          'email': email,
          'newPassword': newPassword,
        },
      );

      if (response.statusCode == 200) {
        final String result = response.body;
        if (result == 'Password updated successfully') {
          Navigator.of(context).pop();
        } else {
          ScaffoldMessenger.of(context).showSnackBar(SnackBar(
            content: Text('Password updated successfully.'),
          ));
          Navigator.of(context).push(
            MaterialPageRoute(
              builder: (context) => LoginPage(),
            ),
          );
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(
          content:
              Text('Failed to reset password (HTTP ${response.statusCode}).'),
        ));
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text('Passwords do not match.'),
      ));
    }
  }
}

class MyHttpOverrides extends HttpOverrides {
  @override
  HttpClient createHttpClient(SecurityContext? context) {
    return super.createHttpClient(context)
      ..badCertificateCallback =
          (X509Certificate cert, String host, int port) => true;
  }
}

void main() {
  HttpClient().badCertificateCallback =
      ((X509Certificate cert, String host, int port) => true);
  HttpOverrides.global = MyHttpOverrides();
  runApp(const LoginApp());
}

class LoginApp extends StatelessWidget {
  const LoginApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        return false;
      },
      child: const MaterialApp(
        debugShowCheckedModeBanner: false,
        home: LoginPage(),
      ),
    );
  }
}

class LoginPage extends StatefulWidget {
  const LoginPage({Key? key}) : super(key: key);

  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        return false;
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text(
            'USTP APPOINTMENT APP',
            style: TextStyle(color: Colors.white),
          ),
          backgroundColor: const Color.fromARGB(255, 1, 0, 75),
          automaticallyImplyLeading: false,
        ),
        body: Container(
          /* decoration: BoxDecoration(
            image: DecorationImage(
              image: AssetImage(
                  'assets/login_background.jpg'), 
              fit: BoxFit.cover,
            ),
          ),*/
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Image.asset(
                  'assets/USTP.png',
                  width: 140,
                  height: 140,
                ),
                const SizedBox(height: 16.0),
                TextField(
                  controller: _emailController,
                  decoration: const InputDecoration(
                    labelText: 'Email',
                  ),
                ),
                const SizedBox(height: 16.0),
                TextField(
                  controller: _passwordController,
                  obscureText: true,
                  decoration: const InputDecoration(
                    labelText: 'Password',
                  ),
                ),
                const SizedBox(height: 32.0),
                ElevatedButton(
                  onPressed: () async {
                    final email = _emailController.text;
                    final password = _passwordController.text;

                    if (email.isNotEmpty && password.isNotEmpty) {
                      try {
                        final url = Uri.parse(
                            'https://ustp-appointment.online/USTP APP/flutter_login.php');
                        final response = await http.post(
                          url,
                          headers: {"Content-Type": "application/json"},
                          body: jsonEncode(
                              {"email": email, "password": password}),
                        );

                        if (response.statusCode == 200) {
                          final Map<String, dynamic> data =
                              json.decode(response.body);

                          if (data["message"] == "Login successful") {
                            Navigator.pushReplacement(
                              context,
                              MaterialPageRoute(
                                builder: (context) => HomeScreen(email: email),
                              ),
                            );
                          } else {
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text(
                                    'Login failed. Please check your credentials.'),
                              ),
                            );
                          }
                        } else {
                          ScaffoldMessenger.of(context).showSnackBar(
                            const SnackBar(
                              content: Text(
                                  'HTTP request failed. Please try again.'),
                            ),
                          );
                        }
                      } catch (e) {
                        print('Error: $e');
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(
                            content: Text(
                                'An error occurred. Please try again later.'),
                          ),
                        );
                      }
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                          content:
                              Text('Please enter both email and password.'),
                        ),
                      );
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color.fromARGB(255, 1, 0, 75),
                    minimumSize: const Size(double.infinity, 50),
                    elevation: 4,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.symmetric(vertical: 12.0),
                    child: Text(
                      'Login',
                      style: TextStyle(
                        fontSize: 18.0,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => const RegistrationPage()),
                    );
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color.fromARGB(255, 255, 196, 0),
                    minimumSize: const Size(double.infinity, 50),
                    elevation: 4,
                  ),
                  child: const Padding(
                    padding: EdgeInsets.symmetric(vertical: 12.0),
                    child: Text(
                      'Register',
                      style: TextStyle(
                        fontSize: 18.0,
                        color: Colors.white,
                      ),
                    ),
                  ),
                ),
                SizedBox(
                  width: 150.0,
                  child: ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => PasswordResetScreen(),
                        ),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      primary: Color.fromARGB(255, 255, 52, 52),
                      elevation: 4,
                    ),
                    child: const Padding(
                      padding: EdgeInsets.symmetric(vertical: 12.0),
                      child: Text(
                        'Forgot Password',
                        style: TextStyle(
                          fontSize: 10.0,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _emailController.dispose();
    _passwordController.dispose();
    super.dispose();
  }
}

class RegistrationPage extends StatefulWidget {
  const RegistrationPage({super.key});

  @override
  _RegistrationPageState createState() => _RegistrationPageState();
}

class _RegistrationPageState extends State<RegistrationPage> {
  final TextEditingController _studentIdController = TextEditingController();
  final TextEditingController _fnameController = TextEditingController();
  final TextEditingController _lnameController = TextEditingController();
  final TextEditingController _contactController = TextEditingController();
  final TextEditingController _ageController = TextEditingController();
  final TextEditingController _birthdateController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController =
      TextEditingController();

  bool _acceptTerms = false;
  String? _selectedCourse;

  Future<void> _registerUser() async {
    final studentId = _studentIdController.text;
    final fname = _fnameController.text;
    final lname = _lnameController.text;
    final contact = _contactController.text;
    final age = _ageController.text;
    final email = _emailController.text;
    final password = _passwordController.text;
    final confirmPassword = _confirmPasswordController.text;

    if (studentId.isNotEmpty &&
        fname.isNotEmpty &&
        lname.isNotEmpty &&
        _selectedCourse != null &&
        contact.isNotEmpty &&
        age.isNotEmpty &&
        email.isNotEmpty &&
        password.isNotEmpty &&
        confirmPassword.isNotEmpty) {
      if (password == confirmPassword) {
        if (_acceptTerms) {
          final url = Uri.parse(
              'http://ustp-appointment.online/USTP APP/registeraccount.php');
          final response = await http.post(
            url,
            headers: {"Content-Type": "application/json"},
            body: jsonEncode({
              "student_id": studentId,
              "fname": fname,
              "lname": lname,
              "course": _selectedCourse,
              "contact": contact,
              "age": age,
              "birthdate": _birthdateController.text,
              "email": email,
              "password": password,
            }),
          );

          if (response.statusCode == 301) {
            final newUrl = response.headers['location'];
            if (newUrl != null) {
              final newResponse = await http.post(
                Uri.parse(newUrl),
                headers: {"Content-Type": "application/json"},
                body: jsonEncode({
                  "student_id": studentId,
                  "fname": fname,
                  "lname": lname,
                  "course": _selectedCourse,
                  "contact": contact,
                  "age": age,
                  "birthdate": _birthdateController.text,
                  "email": email,
                  "password": password,
                }),
              );

              final Map<String, dynamic> data = json.decode(newResponse.body);

              if (newResponse.statusCode == 200) {
                if (data["message"] == "Registration successful") {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(
                      builder: (context) => HomeScreen(email: email),
                    ),
                  );
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Registration successful'),
                    ),
                  );
                } else if (data["message"] == "Email already exists") {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text(
                          'Email already exists. Please use a different email.'),
                    ),
                  );
                }
              } else {}
            }
          } else if (response.statusCode == 200) {
            final Map<String, dynamic> data = json.decode(response.body);
            if (data["message"] == "Registration successful") {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Registration successful'),
                ),
              );
            } else if (data["message"] == "Email already exists") {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text(
                      'Email already exists. Please use a different email.'),
                ),
              );
            }
          } else {}
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Passwords do not match.'),
          ),
        );
      }
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Please fill in all fields.'),
        ),
      );
    }
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: DateTime.now(),
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
    );
    if (picked != null && picked != DateTime.now()) {
      setState(() {
        _birthdateController.text = "${picked.toLocal()}".split(' ')[0];
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'REGISTER',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: const Color.fromARGB(255, 1, 0, 75),
        automaticallyImplyLeading: false,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: SingleChildScrollView(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              const Text(
                'Register an Account',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 16.0),
              TextField(
                controller: _studentIdController,
                decoration: const InputDecoration(
                  labelText: 'Student ID',
                ),
              ),
              const SizedBox(height: 16.0),
              TextField(
                controller: _fnameController,
                decoration: const InputDecoration(
                  labelText: 'First Name',
                ),
              ),
              const SizedBox(height: 16.0),
              TextField(
                controller: _lnameController,
                decoration: const InputDecoration(
                  labelText: 'Last Name',
                ),
              ),
              const SizedBox(height: 16.0),
              DropdownButtonFormField<String>(
                value: _selectedCourse,
                onChanged: (String? newValue) {
                  setState(() {
                    _selectedCourse = newValue;
                  });
                },
                items: <String>[
                  'BSIT',
                  'BFPT',
                  'BTLED',
                ].map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
                decoration: const InputDecoration(
                  labelText: 'Course',
                ),
              ),
              const SizedBox(height: 16.0),
              TextField(
                controller: _contactController,
                decoration: const InputDecoration(
                  labelText: 'Contact',
                ),
              ),
              const SizedBox(height: 16.0),
              TextField(
                controller: _ageController,
                decoration: const InputDecoration(
                  labelText: 'Age',
                ),
              ),
              const SizedBox(height: 16.0),
              GestureDetector(
                onTap: () {
                  _selectDate(context);
                },
                child: AbsorbPointer(
                  child: TextField(
                    controller: _birthdateController,
                    decoration: const InputDecoration(
                      labelText: 'Birthdate',
                    ),
                  ),
                ),
              ),
              const SizedBox(height: 16.0),
              TextField(
                controller: _emailController,
                decoration: const InputDecoration(
                  labelText: 'Email',
                ),
              ),
              const SizedBox(height: 16.0),
              TextField(
                controller: _passwordController,
                obscureText: true,
                decoration: const InputDecoration(
                  labelText: 'Password',
                ),
              ),
              const SizedBox(height: 16.0),
              TextField(
                controller: _confirmPasswordController,
                obscureText: true,
                decoration: const InputDecoration(
                  labelText: 'Confirm Password',
                ),
              ),
              const SizedBox(height: 16.0),
              Row(
                children: <Widget>[
                  Checkbox(
                    value: _acceptTerms,
                    onChanged: (bool? value) {
                      setState(() {
                        _acceptTerms = value!;
                      });
                    },
                  ),
                  const Text('I accept the Terms and Conditions'),
                ],
              ),
              const SizedBox(height: 32.0),
              ElevatedButton(
                onPressed: _registerUser,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color.fromARGB(255, 0, 170, 57),
                ),
                child: const Text('Register'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  final String email;

  const HomeScreen({Key? key, required this.email}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        return false;
      },
      child: Scaffold(
        body: HomeNavigation(email: email),
      ),
    );
  }
}

class HomeNavigation extends StatefulWidget {
  final String email;

  const HomeNavigation({Key? key, required this.email}) : super(key: key);

  @override
  _HomeNavigationState createState() => _HomeNavigationState();
}

class _HomeNavigationState extends State<HomeNavigation> {
  final PageController _pageController = PageController();
  int _selectedIndex = 0;

  void _onPageChanged(int index) {
    setState(() {
      _selectedIndex = index;
    });
  }

  void _showLogoutConfirmationDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            'Logout Confirmation',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          content: Text(
            'Are you sure you want to logout?',
            style: TextStyle(
              fontSize: 16,
            ),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text(
                'Cancel',
                style: TextStyle(
                  color: Colors.black,
                  fontSize: 16,
                ),
              ),
            ),
            TextButton(
              onPressed: () {
                Navigator.pushReplacementNamed(context, '/');
              },
              child: Text(
                'Logout',
                style: TextStyle(
                  color: Colors.red,
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  void _navigateToPage(int index) {
    if (index == 4) {
      _showLogoutConfirmationDialog();
    } else {
      _pageController.animateToPage(
        index,
        duration: const Duration(milliseconds: 300),
        curve: Curves.easeInOut,
      );
    }
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
        return false;
      },
      child: Scaffold(
        appBar: AppBar(
          flexibleSpace: Center(
            child: Image.asset(
              'assets/USTP.png',
              width: 60,
              height: 60,
            ),
          ),
          title: const Text(''),
          backgroundColor: const Color.fromARGB(255, 1, 0, 75),
          automaticallyImplyLeading: false,
          actions: [
            IconButton(
              icon: const Icon(
                Icons.power_settings_new,
                color: Colors.amberAccent,
              ),
              onPressed: () {
                _showLogoutConfirmationDialog();
              },
            ),
          ],
        ),
        body: PageView(
          controller: _pageController,
          onPageChanged: _onPageChanged,
          children: [
            DashboardScreen(email: widget.email),
            DocumentScreen(
              email: widget.email,
            ),
            AppointmentScreen(
              email: widget.email,
            ),
            //availability
            SettingsScreen(
              email: widget.email,
            ),
          ],
        ),
        bottomNavigationBar: BottomNavigationBar(
          backgroundColor: const Color.fromARGB(255, 1, 0, 51),
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.dashboard),
              label: 'Dashboard',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.insert_drive_file),
              label: 'Document',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.calendar_today),
              label: 'Appointment',
            ),
            /*  BottomNavigationBarItem(
              icon: Icon(Icons.calendar_month),
              label: 'Availability',
            ),*/
            BottomNavigationBarItem(
              icon: Icon(Icons.settings),
              label: 'Settings',
            ),
          ],
          currentIndex: _selectedIndex,
          selectedItemColor: const Color.fromARGB(255, 255, 196, 0),
          unselectedItemColor: const Color.fromARGB(255, 0, 7, 112),
          onTap: _navigateToPage,
        ),
      ),
    );
  }
}

class AvailabilityScreen extends StatefulWidget {
  final String email;

  const AvailabilityScreen({Key? key, required this.email}) : super(key: key);

  @override
  _AvailabilityScreenState createState() => _AvailabilityScreenState();
}

class _AvailabilityScreenState extends State<AvailabilityScreen> {
  CalendarFormat _calendarFormat = CalendarFormat.month;
  DateTime _focusedDay = DateTime.now();
  DateTime _selectedDay = DateTime.now();

  Map<DateTime, List> _events = {};

  @override
  void initState() {
    super.initState();
    fetchData();
  }

  Future<void> fetchData() async {
    final response = await http
        .get(Uri.parse('http://192.168.1.119/ustp app/notavailabledates.php'));

    if (response.statusCode == 200) {
      final List<dynamic> data = json.decode(response.body);
      Map<DateTime, List> fetchedEvents = {};

      for (var entry in data) {
        DateTime date = DateTime.parse(entry['date']);
        String title = entry['title'];
        String description = entry['description'];

        fetchedEvents[date] = [title, description];
      }

      print('Fetched data: $fetchedEvents');

      setState(() {
        _events = fetchedEvents;
      });
    } else {
      print('Failed to fetch data: ${response.statusCode} ${response.body}');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Availability',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: const Color.fromARGB(255, 1, 0, 75),
        automaticallyImplyLeading: false,
      ),
      body: Center(
        child: Column(
          children: [
            const SizedBox(height: 10),
            Text('Availability Screen for ${widget.email}'),
            const SizedBox(height: 10),
            const Text('Unavailable Days:'),
            TableCalendar(
              calendarFormat: _calendarFormat,
              focusedDay: _focusedDay,
              firstDay: DateTime(DateTime.now().year - 1),
              lastDay: DateTime(DateTime.now().year + 1),
              eventLoader: (day) {
                return _events[day] ?? [];
              },
              calendarBuilders: CalendarBuilders(
                markerBuilder: (context, date, events) {
                  final eventInfo = _events[date];
                  if (eventInfo != null && eventInfo.isNotEmpty) {
                    return const Positioned(
                      bottom: 20,
                      child: Icon(
                        Icons.circle,
                        size: 10,
                        color: Colors.red,
                      ),
                    );
                  }
                  return const SizedBox.shrink();
                },
              ),
              onFormatChanged: (format) {
                setState(() {
                  _calendarFormat = format;
                });
              },
              onPageChanged: (focusedDay) {
                setState(() {
                  _focusedDay = focusedDay;
                });
              },
              onDaySelected: (selectedDay, focusedDay) {
                setState(() {
                  _selectedDay = selectedDay;
                  _focusedDay = focusedDay;
                });

                final eventInfo = _events[selectedDay];
                if (eventInfo != null && eventInfo.length >= 2) {
                  String title = eventInfo[0];
                  String description = eventInfo[1];

                  String formattedDate =
                      DateFormat('yyyy-MM-dd').format(selectedDay);

                  showDialog(
                    context: context,
                    builder: (context) {
                      return AlertDialog(
                        title: Text(title),
                        content: Text(description),
                        actions: <Widget>[
                          TextButton(
                            onPressed: () {
                              Navigator.of(context).pop();
                            },
                            child: const Text('Close'),
                          ),
                        ],
                      );
                    },
                  );
                }
              },
            ),
          ],
        ),
      ),
    );
  }
}

class DocumentLog {
  final String title;
  final String id;
  final DateTime date;
  final String status;

  DocumentLog({
    required this.title,
    required this.id,
    required this.date,
    required this.status,
  });
}

class DocumentScreen extends StatefulWidget {
  final String email;

  const DocumentScreen({Key? key, required this.email}) : super(key: key);

  @override
  _DocumentScreenState createState() => _DocumentScreenState();
}

class _DocumentScreenState extends State<DocumentScreen> {
  List<DocumentLog> _documents = [];

  @override
  void initState() {
    super.initState();

    _fetchDocuments();
  }

  Future<void> _fetchDocuments() async {
    final email = widget.email;
    final response = await http.get(Uri.parse(
        'http://ustp-appointment.online/USTP APP/documents.php?email=$email'));
    if (response.statusCode == 200) {
      final List<dynamic> data = json.decode(response.body);
      setState(() {
        _documents = data.map((documentData) {
          final documentStatus = documentData['docstatus'];
          if (documentStatus == 'Ready For Pickup') {
            (documentData['title']);
          }
          return DocumentLog(
            title: documentData['title'],
            id: documentData['id'],
            date: DateTime.parse(documentData['dateRequested']),
            status: documentStatus,
          );
        }).toList();
      });
    } else {
      print('Failed to fetch documents: ${response.statusCode}');
    }
  }

  @override
  Widget build(BuildContext context) {
    _documents.sort((a, b) {
      if (a.status == 'Ready For Pickup') {
        return -1;
      } else if (b.status == 'Ready For Pickup') {
        return 1;
      } else if (a.status == 'Processing..') {
        return -1;
      } else if (b.status == 'Processing..') {
        return 1;
      } else if (a.status == 'Pending') {
        return -1;
      } else if (b.status == 'Pending') {
        return 1;
      } else {
        return a.status.compareTo(b.status);
      }
    });

    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Document Logs',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Color.fromARGB(255, 1, 0, 75),
        automaticallyImplyLeading: false,
      ),
      body: ListView.builder(
        itemCount: _documents.length,
        itemBuilder: (context, index) {
          final document = _documents[index];
          IconData statusIcon;
          Color statusColor;

          switch (document.status) {
            case 'Ready For Pickup':
              statusIcon = Icons.inbox;
              statusColor = Color.fromARGB(255, 30, 231, 11);
              break;
            case 'Processing..':
              statusIcon = Icons.pending_rounded;
              statusColor = Color.fromARGB(255, 12, 0, 187);
              break;
            case 'Pending':
              statusIcon = Icons.pending_rounded;
              statusColor = Color.fromARGB(255, 255, 187, 0);
              break;
            case 'Rejected':
              statusIcon = Icons.error_sharp;
              statusColor = Color.fromARGB(255, 255, 0, 0);
              break;
            default:
              statusIcon = Icons.pending_rounded;
              statusColor = Color.fromARGB(255, 12, 0, 187);
              break;
          }

          return Column(
            children: [
              ListTile(
                title: Text(
                  document.title,
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                subtitle: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Date: ${document.date.toString().substring(0, 10)}',
                      style: TextStyle(fontSize: 16),
                    ),
                    Text(
                      'Appointment Number: ${document.id ?? ''}',
                      style: TextStyle(fontSize: 16),
                    ),
                    Row(
                      children: [
                        Icon(
                          statusIcon,
                          color: statusColor,
                        ),
                        Text(
                          'Status: ${document.status}',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: statusColor,
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Divider(),
            ],
          );
        },
      ),
    );
  }
}

class AppointmentLog {
  final String email;
  final String title;
  final String id;
  final DateTime date;
  final String status;
  final String remarks;

  AppointmentLog(
      {required this.title,
      required this.id,
      required this.date,
      required this.status,
      required this.remarks,
      required this.email});
}

class AppointmentScreen extends StatefulWidget {
  final String email;
  const AppointmentScreen({Key? key, required this.email}) : super(key: key);
  @override
  _AppointmentScreenState createState() => _AppointmentScreenState();
}

class _AppointmentScreenState extends State<AppointmentScreen> {
  List<AppointmentLog> _appointments = [];

  @override
  void initState() {
    super.initState();
    _fetchAppointments();
  }

  Future<void> _fetchAppointments() async {
    final email = widget.email;
    final response = await http.get(Uri.parse(
        'http://ustp-appointment.online/USTP APP/appointments.php?email=$email'));
    if (response.statusCode == 200) {
      final List<dynamic> data = json.decode(response.body);
      setState(() {
        _appointments = data.map((appointmentData) {
          return AppointmentLog(
            title: appointmentData['title'],
            id: appointmentData['id'],
            remarks: appointmentData['remarks'],
            date: DateTime.parse(appointmentData['dateRequested']),
            status: appointmentData['status'],
            email: email,
          );
        }).toList();
      });
    } else {
      print('Failed to fetch appointments: ${response.statusCode}');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: const Text(
            'Appointments Log',
            style: TextStyle(color: Colors.white),
          ),
          backgroundColor: const Color.fromARGB(255, 1, 0, 75),
          automaticallyImplyLeading: false,
        ),
        body: ListView.builder(
          itemCount: _appointments.length,
          itemBuilder: (context, index) {
            final appointment = _appointments[index];
            IconData statusIcon;
            Color statusColor;

            if (appointment.status == 'Approved') {
              statusIcon = Icons.check_circle;
              statusColor = const Color.fromARGB(255, 30, 231, 11);
            } else if (appointment.status == 'Pending') {
              statusIcon = Icons.pending_rounded;
              statusColor = const Color.fromARGB(255, 255, 187, 0);
            } else {
              statusIcon = Icons.error;
              statusColor = const Color.fromARGB(255, 255, 0, 0);
            }

            return Column(
              children: [
                ListTile(
                  title: Text(
                    appointment.title,
                    style: const TextStyle(
                        fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Date Requested: ${appointment.date.toString().substring(0, 10)}',
                        style: const TextStyle(fontSize: 16),
                      ),
                      Text(
                        'Appointment Number: ${appointment.id ?? ''}',
                        style: const TextStyle(fontSize: 16),
                      ),
                      Row(
                        children: [
                          Icon(
                            statusIcon,
                            color: statusColor,
                          ),
                          Text(
                            'Status: ${appointment.status}',
                            style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.bold,
                              color: statusColor,
                            ),
                          ),
                          /*     Container(
                            width: 16.0,
                          ),
                          Container(
                            width: 222.0,
                            child: Text(
                              '*Remarks*: ${appointment.remarks ?? ''}',
                              textAlign: TextAlign.justify, 
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.w900,
                                color: const Color.fromARGB(255, 66, 66, 66),
                              ),
                            ),
                          ),*/
                        ],
                      ),
                    ],
                  ),
                ),
                const Divider(),
              ],
            );
          },
        ));
  }
}

class SettingsScreen extends StatefulWidget {
  final String email;
  const SettingsScreen({Key? key, required this.email}) : super(key: key);

  @override
  _SettingsScreenState createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  File? _selectedImage;
  TextEditingController _studentIdController = TextEditingController();
  TextEditingController _firstNameController = TextEditingController();
  TextEditingController _lastNameController = TextEditingController();
  TextEditingController _courseController = TextEditingController();
  TextEditingController _contactController = TextEditingController();
  TextEditingController _ageController = TextEditingController();
  TextEditingController _birthdateController = TextEditingController();
  TextEditingController _passController = TextEditingController();
  Map<String, dynamic>? _userData;
  DateTime? _selectedDate;

  @override
  void initState() {
    super.initState();

    _fetchProfileData();
  }

  Future<void> _fetchProfileData() async {
    try {
      final response = await http.get(
        Uri.parse(
          'https://ustp-appointment.online/USTP%20APP/profile_fetcher.php?email=${widget.email}',
        ),
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> data = json.decode(response.body);

        String profilePictureUrl = '';
        if (data['profile_picture'] != null &&
            data['profile_picture'].isNotEmpty) {
          if (data['profile_picture'].startsWith('http')) {
            profilePictureUrl = data['profile_picture'];
          } else {
            profilePictureUrl =
                'https://ustp-appointment.online/USTP%20APP/${data['profile_picture']}';
          }
        }

        setState(() {
          _userData = {
            ...data,
            'profile_picture_url': profilePictureUrl,
          };
          _studentIdController.text = data['student_id'];
          _firstNameController.text = data['fname'];
          _lastNameController.text = data['lname'];
          _courseController.text = data['course'];
          _contactController.text = data['contact'];
          _ageController.text = data['age'];

          if (data['birthdate'] != null) {
            _selectedDate = DateTime.parse(data['birthdate']);
            _birthdateController.text =
                "${_selectedDate!.toLocal()}".split(' ')[0];
          }
          _passController.text = data['password'];
        });
      } else {
        print('Failed to fetch profile: ${response.reasonPhrase}');
      }
    } catch (e) {
      print('Error fetching profile: $e');
    }
  }

  Future<void> _selectImage() async {
    final imagePicker = ImagePicker();
    try {
      final pickedFile =
          await imagePicker.pickImage(source: ImageSource.gallery);

      if (pickedFile != null) {
        setState(() {
          _selectedImage = File(pickedFile.path);
        });
      } else {
        _setDefaultProfileIcon();
      }
    } catch (e) {
      _setDefaultProfileIcon();
    }
  }

  void _setDefaultProfileIcon() {
    setState(() {
      _selectedImage = File("assets/USTP.png");
    });
  }

  Future<void> _saveProfile() async {
    final String email = widget.email;

    if (_selectedImage != null) {
      final request = http.MultipartRequest(
        'POST',
        Uri.parse(
            'https://ustp-appointment.online/USTP%20APP/profile_updater.php?email=${Uri.encodeComponent(widget.email)}'),
      );
      request.fields['email'] = email;
      request.files.add(
        await http.MultipartFile.fromPath(
          'profile_picture',
          _selectedImage!.path,
        ),
      );

      final response = await request.send();
      if (response.statusCode == 200) {
        _fetchProfileData();
        print('Profile picture updated successfully');
      } else {
        print('Failed to update profile picture: ${response.reasonPhrase}');
      }
    }

    final Map<String, dynamic> updatedAttributes = {
      'student_id': _studentIdController.text,
      'fname': _firstNameController.text,
      'lname': _lastNameController.text,
      'course': _courseController.text,
      'contact': _contactController.text,
      'age': _ageController.text,
      'birthdate': _birthdateController.text,
      'password': _passController.text,
    };

    try {
      final updateResponse = await http.post(
        Uri.parse(
          'https://ustp-appointment.online/USTP%20APP/profile_updater.php?email=${Uri.encodeComponent(widget.email)}',
        ),
        body: {
          'email': email,
          ...updatedAttributes,
        },
      );

      if (updateResponse.statusCode == 200) {
        _fetchProfileData();
        print('Profile attributes updated successfully');

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Profile updated successfully'),
            duration: Duration(seconds: 2),
          ),
        );
      } else {
        print(
            'Failed to update profile attributes: ${updateResponse.reasonPhrase}');
      }
    } catch (e) {
      print('Error updating profile attributes: $e');
    }
  }

  Future<void> _selectDate(BuildContext context) async {
    final DateTime? picked = await showDatePicker(
      context: context,
      initialDate: _selectedDate ?? DateTime.now(),
      firstDate: DateTime(1900),
      lastDate: DateTime.now(),
    );

    if (picked != null && picked != _selectedDate) {
      setState(() {
        _selectedDate = picked;
        _birthdateController.text = "${picked.toLocal()}".split(' ')[0];
      });
    }
  }

  bool _obscureText = true;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Manage Profile',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: const Color.fromARGB(255, 1, 0, 75),
        automaticallyImplyLeading: false,
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              const SizedBox(height: 10),
              if (_selectedImage != null)
                ClipOval(
                  child: CircleAvatar(
                    radius: 75,
                    backgroundImage: FileImage(_selectedImage!),
                  ),
                ),
              const SizedBox(height: 2),
              if (_userData != null)
                Column(
                  children: [
                    if (_selectedImage == null &&
                        _userData!['profile_picture'] != null)
                      ClipOval(
                        child: CircleAvatar(
                          radius: 80,
                          child: Image.network(
                            'https://ustp-appointment.online/USTP%20APP/' +
                                _userData!['profile_picture'] +
                                '?timestamp=${DateTime.now().millisecondsSinceEpoch}',
                            fit: BoxFit.cover,
                            key: UniqueKey(),
                          ),
                        ),
                      ),
                    ElevatedButton(
                      onPressed: _selectImage,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Color.fromARGB(255, 0, 0, 0),
                        minimumSize: Size(90, 30),
                      ),
                      child: const Text('Update Image',
                          style: TextStyle(
                              color: Color.fromARGB(255, 255, 255, 255))),
                    ),
                    Text('Email: ${_userData!['email']}'),
                    Text('Student ID: ${_userData!['student_id']}'),
                  ],
                ),
              const SizedBox(height: 1),
              TextFormField(
                controller: _studentIdController,
                decoration: InputDecoration(labelText: 'Student ID:'),
              ),
              TextFormField(
                controller: _firstNameController,
                decoration: InputDecoration(labelText: 'First Name'),
              ),
              TextFormField(
                controller: _lastNameController,
                decoration: InputDecoration(labelText: 'Last Name'),
              ),
              DropdownButtonFormField<String>(
                value: _courseController.text.isNotEmpty
                    ? _courseController.text
                    : null,
                onChanged: (newValue) {
                  setState(() {
                    _courseController.text = newValue!;
                  });
                },
                items: ['BSIT', 'BTLED', 'BFPT']
                    .map<DropdownMenuItem<String>>((String value) {
                  return DropdownMenuItem<String>(
                    value: value,
                    child: Text(value),
                  );
                }).toList(),
                decoration: InputDecoration(labelText: 'Course'),
              ),
              TextFormField(
                controller: _contactController,
                decoration: InputDecoration(labelText: 'Contact'),
              ),
              TextFormField(
                controller: _ageController,
                decoration: InputDecoration(labelText: 'Age'),
              ),
              InkWell(
                onTap: () => _selectDate(context),
                child: IgnorePointer(
                  child: TextFormField(
                    controller: _birthdateController,
                    decoration: InputDecoration(labelText: 'Birthdate'),
                  ),
                ),
              ),
              TextFormField(
                controller: _passController,
                decoration: InputDecoration(
                  labelText: 'Password',
                  suffixIcon: IconButton(
                    icon: Icon(
                      _obscureText ? Icons.visibility : Icons.visibility_off,
                    ),
                    onPressed: () {
                      setState(() {
                        _obscureText = !_obscureText;
                      });
                    },
                  ),
                ),
                obscureText: _obscureText,
              ),
              const SizedBox(height: 20),
              ElevatedButton(
                onPressed: _saveProfile,
                style: ElevatedButton.styleFrom(
                  backgroundColor: Color.fromARGB(255, 0, 219, 40),
                ),
                child: const Text('Save Profile',
                    style:
                        TextStyle(color: Color.fromARGB(255, 255, 255, 255))),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class DashboardScreen extends StatelessWidget {
  final String email;

  const DashboardScreen({Key? key, required this.email}) : super(key: key);

  Future<Map<String, dynamic>> fetchUserData(String email) async {
    final response = await http.get(Uri.parse(
      'https://ustp-appointment.online/USTP APP/getuser.php?email=$email',
    ));

    if (response.statusCode == 200) {
      final userData = json.decode(response.body);
      final profilePictureUrl = userData['profile_picture'];
      return {...userData, 'profile_picture': profilePictureUrl};
    } else {
      throw Exception('Failed to load user data');
    }
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<Map<String, dynamic>>(
      future: fetchUserData(email),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Scaffold(
            appBar: AppBar(
              title: const Text('Dashboard'),
              backgroundColor: const Color.fromARGB(255, 1, 0, 75),
              automaticallyImplyLeading: false,
            ),
            body: const Center(
              child: CircularProgressIndicator(),
            ),
          );
        } else if (snapshot.hasError) {
          return Text('Error: ${snapshot.error}');
        } else {
          final userData = snapshot.data;
          final greetingsContainer = Container(
            padding: const EdgeInsets.all(32.0),
            decoration: BoxDecoration(
              color: const Color.fromARGB(255, 0, 2, 104),
              borderRadius: BorderRadius.circular(50.20),
            ),
            child: Column(
              children: [
                Container(
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    border: Border.all(
                      color: const Color.fromARGB(255, 236, 193, 0),
                      width: 5.0,
                    ),
                  ),
                  child: ClipOval(
                    child: CircleAvatar(
                      radius: 76,
                      child: Image.network(
                        'https://ustp-appointment.online/USTP%20APP/' +
                            userData!['profile_picture'] +
                            '?timestamp=${DateTime.now().millisecondsSinceEpoch}',
                        fit: BoxFit.cover,
                        key: UniqueKey(),
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 20),
                RichText(
                  text: TextSpan(
                    text: 'Welcome, ',
                    style: const TextStyle(
                      fontSize: 26.0,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                    children: <TextSpan>[
                      TextSpan(
                        text: '${userData?['fname']} ${userData?['lname']}',
                        style: TextStyle(
                          fontSize: 26.0,
                          fontWeight: FontWeight.bold,
                          color: const Color.fromARGB(255, 236, 193, 0),
                        ),
                      ),
                      TextSpan(text: '!'),
                    ],
                  ),
                ),
                Text(
                  'Student ID: ${userData?['student_id']}',
                  style: const TextStyle(
                    fontSize: 16.0,
                    color: Colors.white,
                  ),
                ),
                Text(
                  'Course: ${userData?['course']}',
                  style: const TextStyle(
                    fontSize: 16.0,
                    color: Colors.white,
                  ),
                ),
              ],
            ),
          );

          return Scaffold(
            appBar: AppBar(
              title: const Text(
                'Dashboard',
                style: TextStyle(color: Colors.white),
              ),
              backgroundColor: const Color.fromARGB(255, 1, 0, 75),
              automaticallyImplyLeading: false,
            ),
            body: Stack(
              children: [
                Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: <Widget>[
                      const SizedBox(height: 16.0),
                      greetingsContainer,
                      const SizedBox(height: 30.0),
                      ElevatedButton(
                        onPressed: () {
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (context) => AppointmentFormPage(
                                email: email,
                                course: userData?['course'] ?? '',
                              ),
                            ),
                          );
                        },
                        style: ButtonStyle(
                          backgroundColor: MaterialStateProperty.all<Color>(
                            const Color.fromARGB(255, 236, 193, 0),
                          ),
                          padding:
                              MaterialStateProperty.all<EdgeInsetsGeometry>(
                            const EdgeInsets.symmetric(
                                vertical: 20.0, horizontal: 60.0),
                          ),
                          shape:
                              MaterialStateProperty.all<RoundedRectangleBorder>(
                            RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30.0),
                            ),
                          ),
                        ),
                        child: const Text(
                          'Make Appointment',
                          style: TextStyle(
                            color: const Color.fromARGB(255, 0, 2, 104),
                            fontSize: 18.0,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      )
                    ],
                  ),
                ),
              ],
            ),
          );
        }
      },
    );
  }
}
