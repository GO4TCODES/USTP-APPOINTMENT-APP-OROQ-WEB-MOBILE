<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

	$username = $_POST['Admin'];
	$password = $_POST['Apass'];

	$con=mysqli_connect("localhost"," "," "," ");
	mysqli_select_db($con," ");

	$username = stripcslashes($username);
	$password = stripslashes($password);
	$username = mysqli_real_escape_string($con,$username);
	$password = mysqli_real_escape_string($con,$password);

	$result = mysqli_query($con,"SELECT * FROM user WHERE username = '$username' AND password = '$password'")
	or die("WALA NI EPEKT" .mysqli_error($con));
 
	$row = mysqlI_fetch_array($result);


	if (empty($username)) {
		echo "tet";
		header("Location: Login.php");
		exit();
	}
	if (empty($password)) {
		header("Location: Login.php");

	}

	if ($row['username'] == $username && $row['password'] == $password) {
		$_SESSION['username'] = $username;
		$_SESSION['logged_in_datetime'] = date("d M Y H:i");
		echo "LOGIN SUCCESS!";
		header("Location: Home.php"); /* Redirect browser */
  		exit();

	}
	else{
		header("Location: Login.php");
	}
	
?>