<?php
require_once("MUDMSCON.php");

// Check the database connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

if (isset($_POST['not_available']) && !empty($_POST['not_available'])) {
    // Get the selected not available day from the form
    $selectedDay = $_POST['not_available'];

    // Get the current month and year
    $currentMonth = $_POST['month'];
    $currentYear = $_POST['year'];

    // Initialize title and description
    $title = '';
    $description = '';

    // Check if title and description are set in the form for the selected day
    if (isset($_POST['title_' . $selectedDay])) {
        $title = $_POST['title_' . $selectedDay];
    }

    if (isset($_POST['description_' . $selectedDay])) {
        $description = $_POST['description_' . $selectedDay];
    }

    // Create a date string in YYYY-MM format
    $dateString = sprintf("%04d-%02d-%02d", $currentYear, $currentMonth, $selectedDay);

    // Insert the data into the database
    $sql = "INSERT INTO notavailabledays (date, title, description) VALUES (?, ?, ?)";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("sss", $dateString, $title, $description);

    if ($stmt->execute()) {
        header("Location: Availability.php");
        echo "Not available day for $dateString has been successfully saved to the database.";
    } else {
        echo "Error: " . $sql . "<br>" . $stmt->error;
    }
} else {
    // Handle the case where no day was selected
    echo "No day was selected.";
}
?>
