<?php
require_once("MUDMSCON.php");
ini_set('display_errors', 1);
error_reporting(E_ALL);

function handleUpdateError($stmt, $message) {
    echo '<script type="text/javascript">alert("Error: ' . $message . '")</script>';
    error_log("Error: " . $message);
    
    if ($stmt) {
        mysqli_stmt_close($stmt);
    }
}


if(isset($_POST['updateuser'])) {
    $id = $_POST['id'];
    
    // Use prepared statements to prevent SQL injection
    $query = "UPDATE `createdaccounts` SET username=?, password=?, role=? WHERE id=?";
    
    $stmt = mysqli_prepare($con, $query);
    
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'sssi', $_POST['username'], $_POST['password'], $_POST['role'], $id);
    
        if (mysqli_stmt_execute($stmt)) {
            echo '<script type="text/javascript">alert("Data Updated")</script>';
            header("location: Manageusers.php");
        } else {
            handleUpdateError($stmt, "Execution error: " . mysqli_error($con));
        }
    } else {
        handleUpdateError($stmt, "Preparation error: " . mysqli_error($con));
    }
}
?>
