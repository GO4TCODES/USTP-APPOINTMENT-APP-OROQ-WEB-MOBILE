<?php
require_once("MUDMSCON.php");
ini_set('display_errors', 1);
error_reporting(E_ALL);

function handleUpdateError($stmt, $message) {
    echo '<script type="text/javascript">alert("Error: ' . $message . '")</script>';
    error_log("Error: " . $message);
    
    if ($stmt) {
        mysqli_stmt_close($stmt);
    }
}

if(isset($_POST['updatedata_manageR'])) {
    $rid = $_POST['updateid'];
    
    // Use prepared statements to prevent SQL injection
    $query = "UPDATE `request` SET student_id=?, fname=?, mname=?, lname=?, type=?, course=?, rdate=?, released=?, status=? WHERE rid=?";
    
    $stmt = mysqli_prepare($con, $query);
    
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'sssssssssi', $_POST['student_id'], $_POST['fname'], $_POST['mname'], $_POST['lname'], $_POST['type'], $_POST['course'], $_POST['rdate'], $_POST['released'], $_POST['status'], $rid);
    
        if (mysqli_stmt_execute($stmt)) {
            echo '<script type="text/javascript">alert("Data Updated")</script>';
            header("location: Pending Staff.php");
        } else {
            handleUpdateError($stmt, "Execution error: " . mysqli_error($con));
        }
    } else {
        handleUpdateError($stmt, "Preparation error: " . mysqli_error($con));
    }
}

if(isset($_POST['updatedata_manageR2'])) {
    $rid = $_POST['updateid'];
    
    // Use prepared statements to prevent SQL injection
    $query = "UPDATE `request` SET student_id=?, fname=?, mname=?, lname=?, type=?, course=?, rdate=?, released=? WHERE rid=?";
    
    $stmt = mysqli_prepare($con, $query);
    
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'ssssssssi', $_POST['student_id'], $_POST['fname'], $_POST['mname'], $_POST['lname'], $_POST['type'], $_POST['course'], $_POST['rdate'], $_POST['released'], $rid);
    
        if (mysqli_stmt_execute($stmt)) {
            echo '<script type="text/javascript">alert("Data Updated")</script>';
            header("location: Pending Staff.php");
        } else {
            handleUpdateError($stmt, "Execution error: " . mysqli_error($con));
        }
    } else {
        handleUpdateError($stmt, "Preparation error: " . mysqli_error($con));
    }
}

if(isset($_POST['updateuser'])) {
    $id = $_POST['id'];
    
    // Use prepared statements to prevent SQL injection
    $query = "UPDATE `createdaccounts` SET username=?, password=?, role=? WHERE id=?";
    
    $stmt = mysqli_prepare($con, $query);
    
    if ($stmt) {
        mysqli_stmt_bind_param($stmt, 'sssi', $_POST['username'], $_POST['password'], $_POST['role'], $id);
    
        if (mysqli_stmt_execute($stmt)) {
            echo '<script type="text/javascript">alert("Data Updated")</script>';
            header("location: Manageusers.php");
        } else {
            handleUpdateError($stmt, "Execution error: " . mysqli_error($con));
        }
    } else {
        handleUpdateError($stmt, "Preparation error: " . mysqli_error($con));
    }
}
?>
