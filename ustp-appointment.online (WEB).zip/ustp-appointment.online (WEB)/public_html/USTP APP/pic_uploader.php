<?php
header('Content-Type: application/json');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email']; // Get the user's email from the request
    $uploadDirectory = "D:/CODE/htdocs/USTP APP/uploads/";

    if (!file_exists($uploadDirectory)) {
        mkdir($uploadDirectory, 0777, true); // Create the directory if it doesn't exist
    }

    $uploadedFile = $_FILES['profile_picture']['tmp_name'];
    $destination = $uploadDirectory . basename($_FILES['profile_picture']['name']);

    if (move_uploaded_file($uploadedFile, $destination)) {
        // File was successfully uploaded and saved to the "uploads" directory
        // You can now update the "profile_picture" column in your database
        // with the file path or any relevant information.

     

 
        if ($con->connect_error) {
            die("Connection failed: " . $con->connect_error);
        }

        $profilePicturePath = "path_to_uploaded_file"; // Set the actual path to the uploaded file
        $sql = "UPDATE studentacc SET profile_picture = '$profilePicturePath' WHERE email = '$email'";

        if ($conn->query($sql) === TRUE) {
            echo json_encode(["message" => "File uploaded and database updated successfully"]);
        } else {
            echo json_encode(["error" => "Failed to update database: " . $conn->error]);
        }

        $conn->close();
    } else {
        echo json_encode(["error" => "Failed to upload file"]);
    }
}
?>
