<?php
require_once("MUDMSCON.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get other data from the POST request
    $email = $_POST['email'];
    $title = $_POST['title'];
    $selectedPurpose = $_POST['selectedPurpose'];
    $selectedCategory = $_POST['selectedCategory'];
    $selectedCourse = $_POST['selectedCourse'];
    $selectedYear = $_POST['selectedYear'];
    $dateOfRequest = $_POST['dateOfRequest'];
    $lastSemesterAndSY = $_POST['lastSemesterAndSY'];
    $dateOfGraduation = $_POST['dateOfGraduation'];
    $alreadyRequestedCredentials = $_POST['alreadyRequestedCredentials'];
    $specifyText = $_POST['specifyText'];
    $dateRequested = $_POST['dateRequested'];
    $status ="Pending";
    // Handle the file upload
    if (isset($_POST['file'])) {
        $fileData = $_POST['file'];
        $fileBytes = base64_decode($fileData);

        // Specify the directory where you want to store uploaded files
        $targetDirectory = "uploads/";

        // Ensure the target directory exists or create it
        if (!file_exists($targetDirectory)) {
            mkdir($targetDirectory, 0777, true);
        }

        // Generate a unique filename for the uploaded file
        $uniqueFilename = uniqid() . '_' . $email . '.pdf';

        // Move the uploaded file to the target directory
        $targetPath = $targetDirectory . $uniqueFilename;
        if (file_put_contents($targetPath, $fileBytes)) {
            // File upload successful
            echo "File uploaded successfully to: $targetPath";
        } else {
            // File upload failed
            echo "File upload failed";
        }
    } else {
        // No file was uploaded
        echo "No file uploaded";
    }




    // Check connection
    if ($con->connect_error) {
        die("Connection failed: " . $con->connect_error);
    }

    // Prepare the SQL INSERT statement
    $sql = "INSERT INTO appointments (email, title, selectedPurpose, selectedCategory, selectedCourse, selectedYear, dateOfRequest, lastSemesterAndSY, dateOfGraduation, alreadyRequestedCredentials, specifyText, dateRequested, status, fileUpload) 
            VALUES ('$email', '$title', '$selectedPurpose', '$selectedCategory', '$selectedCourse', '$selectedYear', '$dateOfRequest', '$lastSemesterAndSY', '$dateOfGraduation', '$alreadyRequestedCredentials', '$specifyText', '$dateRequested', '$status', '$targetPath')";
$con->commit();


echo "SQL Query: $sql";
if ($con->query($sql) === TRUE) {
    // Data insertion successful
    echo "Data inserted successfully";
} else {
    // Error inserting data
    echo "Error inserting data: " . $con->error;
}

    // Close the database connection
    $con->close();
} else {
    // Invalid request method
    echo "Invalid request method";
}
?>
