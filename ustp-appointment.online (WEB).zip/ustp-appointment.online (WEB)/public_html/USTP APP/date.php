<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Interactive Calendar</title>
    <style>
        /* Add your CSS styles here */
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 20px;
        }
        table {
            border-collapse: collapse;
            margin: 0 auto;
            font-size: 18px; /* Increase font size */
        }
        th, td {
            border: 1px solid #ccc;
            padding: 15px; /* Increase cell padding */
            width: 50px; /* Increase cell width */
            text-align: center; /* Center cell content */
        }
        th {
            background-color: #f0f0f0;
        }
        td {
            cursor: pointer;
        }
        .event-popup {
            display: none;
            position: absolute;
            background-color: #fff;
            border: 1px solid #ccc;
            padding: 10px;
            z-index: 1;
        }
    </style>
</head>
<body>
    <h1>Interactive Calendar</h1>
    <div id="calendar"></div>
    <div id="event-popup" class="event-popup">
        <h2>Add Event</h2>
        <label for="event-title">Title:</label>
        <input type="text" id="event-title">
        <br>
        <label for="event-date">Date:</label>
        <input type="text" id="event-date" disabled>
        <br>
        <button id="save-event">Save</button>
        <button id="cancel-event">Cancel</button>
    </div>
    <script>
        // JavaScript code for the interactive calendar
        const calendar = document.getElementById("calendar");
        const eventPopup = document.getElementById("event-popup");
        const eventTitleInput = document.getElementById("event-title");
        const eventDateInput = document.getElementById("event-date");
        const saveEventButton = document.getElementById("save-event");
        const cancelEventButton = document.getElementById("cancel-event");

        const months = [
            "January", "February", "March",
            "April", "May", "June",
            "July", "August", "September",
            "October", "November", "December"
        ];

        function createCalendar(year, month) {
            const today = new Date();
            const firstDay = new Date(year, month, 1);
            const lastDay = new Date(year, month + 1, 0);
            const daysInMonth = lastDay.getDate();
            const startingDay = firstDay.getDay();

            let html = "<table>";
            html += "<tr><th colspan='7'>" + months[month] + " " + year + "</th></tr>";
            html += "<tr><th>Sun</th><th>Mon</th><th>Tue</th><th>Wed</th><th>Thu</th><th>Fri</th><th>Sat</th></tr><tr>";

            let day = 1;

            // Create empty cells for the days before the first day of the month
            for (let i = 0; i < startingDay; i++) {
                html += "<td></td>";
            }

            // Create cells for each day of the month
            for (let i = 0; i < 7 - startingDay; i++) {
                html += "<td>" + day + "</td>";
                day++;
            }

            html += "</tr>";

            // Continue creating rows and cells for the rest of the month
            while (day <= daysInMonth) {
                html += "<tr>";
                for (let i = 0; i < 7 && day <= daysInMonth; i++) {
                    html += "<td>" + day + "</td>";
                    day++;
                }
                html += "</tr>";
            }

            html += "</table>";

            // Attach the calendar HTML to the calendar element
            calendar.innerHTML = html;

            // Add click event listeners to the calendar cells
            const cells = calendar.querySelectorAll("td");
            cells.forEach(cell => {
                cell.addEventListener("click", () => {
                    const selectedDate = new Date(year, month, parseInt(cell.innerText));
                    showEventPopup(selectedDate);
                });
            });
        }

        function showEventPopup(date) {
            const dateString = date.toDateString();
            eventDateInput.value = dateString;
            eventTitleInput.value = "";
            eventPopup.style.display = "block";
        }

        function hideEventPopup() {
            eventPopup.style.display = "none";
        }

        saveEventButton.addEventListener("click", () => {
            const title = eventTitleInput.value.trim();
            const date = eventDateInput.value;
            if (title !== "") {
                // You can save the event here or perform other actions
                console.log("Event Title: " + title);
                console.log("Event Date: " + date);
                hideEventPopup();
            }
        });

        cancelEventButton.addEventListener("click", () => {
            hideEventPopup();
        });

        // Initialize the calendar with the current year and month
        const currentDate = new Date();
        createCalendar(currentDate.getFullYear(), currentDate.getMonth());
    </script>
</body>
</html>
