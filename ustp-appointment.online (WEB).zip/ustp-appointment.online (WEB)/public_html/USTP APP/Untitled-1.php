<?php
// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to select unavailable dates from your table
$sql = "SELECT unavailable_date FROM your_table_name";

// Execute the query
$result = $conn->query($sql);

// Fetch the results into an array
$unavailableDates = array();
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $unavailableDates[] = $row["unavailable_date"];
    }
}

// Close the database connection
$conn->close();

// Return the data as JSON
header('Content-Type: application/json');
echo json_encode($unavailableDates);
?>