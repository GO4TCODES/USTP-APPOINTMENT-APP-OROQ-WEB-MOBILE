
<?php

session_start();

if (!isset($_SESSION['user'])) {
  $_SESSION['msg'] = "You have to log in first";
  session_destroy();
  header('location: Login.php');
  
}

if (isset($_GET['logout'])) {
  session_destroy();
  unset($_SESSION['user']);
  header("location: Login.php");

}
              include_once 'MUDMSCON.php';

// Fetch the "not available" days from the database
$sql = "SELECT date, title, description FROM notavailabledays";
$result = $con->query($sql);

$notAvailableDays = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $notAvailableDays[] = [
            'date' => $row['date'],
            'title' => $row['title'],
            'description' => $row['description'],
        ];
    }
}
              $query6 ="SELECT * FROM `request` WHERE status='Pending'  
              ORDER BY `request`.`status` ASC";
              $result6=  mysqli_query($con,$query6);


              ?>

<!DOCTYPE html>
<html lang="en">
<head>
    
<meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="icon" href="./images/USTP.png" type="image/ico" sizes="16x16">
  <title>USTP Appointment System</title>
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.5/css/jquery.dataTables.css">
  <script type="text/javascript" charset="utf8" src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.5/js/jquery.dataTables.js"></script>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round"
  
  rel="stylesheet">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
  <style>
        /* Add some basic CSS for styling */
    
    </style>
  <!--MATERIAL CDN-->
  <!--STYLESHEET-->
  <link rel="stylesheet" href="Style.css">
  <link rel="stylesheet" href="calendar.css">

</head>
<body>
  
<div class="container-fluid">
  <div class="row">
    <aside class="col-md-2">
      <!-- Sidebar content goes here -->
      <div class="top">
        <div class="logo">
          <img src="./images/USTP.png">
          <h1><span class="danger"></span></h1>
        </div>
        <div class="close" id="close-btn">
          <span class="material-icons-round"> close </span>
        </div>
      </div>
      <div class="sidebar">
        <a href="HomeUser.php" >
          <span class="material-icons-round">dashboard</span>
          <h3> Dashboard </h3>
        </a>
        
        <a href="Appointments User.php"  >
          <span class="material-icons-round">description</span>
          <h3> Appointment </h3>
        </a>
        <a href="Availability Staff.php" class="active" >
          <?php
           if ($result6) {
             $notif = mysqli_num_rows($result6);
             mysqli_free_result($result6);
           }
          ?>       
          <span class="material-icons-round">check</span>
          <h3> Availability </h3>
          <span class="request-count"><?php echo $notif; ?></span>
        </a>
        <!--
        <a href="ManageD.php" >
          <span class="material-icons-round"> description</span>
          <h3> Manage Documents </h3>
        </a>
          -->
        <a href="Transaction Log User.php">
          <span class="material-icons-round"> report</span>
          <h3> Transaction Logs </h3>
        </a>
 
        <a href="Logout.php">
          <span class="material-icons-round">power_settings_new </span>
          <h3> Logout </h3>
        </a>
      </div>
    </aside>


      <!-------END OF ASIDE------>
  
      <main class="col-md-10 ">

<br>
<br>
<br>
<br>
      <h4>NOT AVAILABLE DAYS</h4>
   

    <div class="container">
        <div class="calendar">
            
            <h2 class="title">Select Not Available Days</h2>
            <form method="post" action="datesched.php" onsubmit="return validateForm()">
                <div class="month-year-select">
                    <label for="month">Month:</label>
                    <select name="month" id="month" onchange="updateCalendar()">
                        <?php
                        $currentMonth = isset($_POST['month']) ? $_POST['month'] : date('n');
                        for ($i = 1; $i <= 12; $i++) {
                            echo '<option value="' . $i . '"';
                            if ($i == $currentMonth) {
                                echo ' selected';
                            }
                            echo '>' . date('F', mktime(0, 0, 0, $i, 1)) . '</option>';
                        }
                        ?>
                    </select>
                    <label for="year">Year:</label>
                    <select name="year" id="year" onchange="updateCalendar()">
                        <?php
                        $currentYear = isset($_POST['year']) ? $_POST['year'] : date('Y');
                        $startYear = date('Y') - 10;
                        $endYear = date('Y') + 10;
                        for ($i = $startYear; $i <= $endYear; $i++) {
                            echo '<option value="' . $i . '"';
                            if ($i == $currentYear) {
                                echo ' selected';
                            }
                            echo '>' . $i . '</option>';
                        }
                        ?>
                    </select>
                </div>
                <table id="calendarTable">
                    <tr>
                        <th>Sun</th>
                        <th>Mon</th>
                        <th>Tue</th>
                        <th>Wed</th>
                        <th>Thu</th>
                        <th>Fri</th>
                        <th>Sat</th>
                    </tr>
      
                </table>
                <br>
      
            </form>
            <div id="confirmationModal" class="modal confirmation">
    <div class="modal-content">
        <span class="close" onclick="closeConfirmation()">&times;</span>
        <h1>Confirmation</h1>
        <p><strong>Date:</strong> <span id="selectedDate"></span></p>
        <p>Are you sure you want to submit?</p>
        <button type="submit" class="button2" onclick="submitForm()">Submit</button>
    </div>
</div>

        </div>
        <script>
            var selectedDate;
            var selectedTitle;
            var selectedDescription;


            function closeModal(day) {
                var modal = document.getElementById('modal_' + day);
                modal.style.display = "none";
            }

            function closeConfirmation() {
                var confirmationModal = document.getElementById('confirmationModal');
                confirmationModal.style.display = "none";
            }

            // Close the modal when clicking outside
            window.onclick = function(event) {
                if (event.target.className === "modal") {
                    event.target.style.display = "none";
                }
            }

            function validateForm() {
    var radios = document.getElementsByName("not_available");
    var selected = false;
    for (var i = 0; i < radios.length; i++) {
        if (radios[i].checked) {
            selected = true;
            break;
        }
    }
    if (!selected) {
        alert("Please select a day before submitting.");
        return false;
    } else {
        // Display the confirmation modal
        var confirmationModal = document.getElementById('confirmationModal');
        var dateElement = document.getElementById('selectedDate');
        dateElement.textContent = selectedDate;
        confirmationModal.style.display = "block";
        return false; // Prevent the form from submitting
    }
}
            function submitForm() {
                var form = document.querySelector('form');
                form.submit();
            }

            function updateCalendar() {
                var monthSelect = document.getElementById('month');
                var yearSelect = document.getElementById('year');
                var calendarTable = document.getElementById('calendarTable');

                var currentMonth = monthSelect.value;
                var currentYear = yearSelect.value;

                // Get the number of days in the current month
                var daysInMonth = new Date(currentYear, currentMonth, 0).getDate();

                // Get the first day of the month (0 = Sunday, 1 = Monday, ...)
                var firstDay = new Date(currentYear, currentMonth - 1, 1).getDay();

                var calendarContent = '';
                var dayCounter = 1;

                for (var i = 0; i < 6; i++) {
        calendarContent += '<tr>';
        for (var j = 0; j < 7; j++) {
            calendarContent += '<td>';
            if (i === 0 && j < firstDay) {
                calendarContent += '&nbsp;';
            } else if (dayCounter <= daysInMonth) {
                var isWeekday = j >= 1 && j <= 5; // Check if it's a weekday (Mon-Fri)

                if (isWeekday) {
                    calendarContent += '<input type="radio" name="not_available" value="' + dayCounter + '" onclick="openModal(' + dayCounter + ')" />' + dayCounter;

    calendarContent += '<div id="modal_' + dayCounter + '" class="modal">';
    calendarContent += '<div class="modal-content">';
    calendarContent += '<span class="close" onclick="closeModal(' + dayCounter + ')">&times;</span>';

    // Format the title and description fields
    calendarContent += '<label for="title_' + dayCounter + '" style="font-weight: bold; font-size: 16px;">Title:</label>';
    calendarContent += '<input type="text" name="title_' + dayCounter + '" id="title_' + dayCounter + '" style="width: 100%; padding: 5px;">';

    calendarContent += '<label for="description_' + dayCounter + '" style="font-weight: bold; font-size: 16px;">Description:</label>';
    calendarContent += '<textarea name="description_' + dayCounter + '" id="description_' + dayCounter + '" style="width: 100%; height: 100px; padding: 5px;"></textarea>';

    calendarContent += '</div>';
    calendarContent += '</div>';

} else {
                    calendarContent += dayCounter; // Display the day number without a radio button for weekends
                }
    dayCounter++;
}

                        calendarContent += '</td>';
                    }
                    calendarContent += '</tr>';
                }

                calendarTable.innerHTML = '<tr><th>Sun</th><th>Mon</th><th>Tue</th><th>Wed</th><th>Thu</th><th>Fri</th><th>Sat</th></tr>' + calendarContent;
            }

            // Initialize the calendar when the page loads
            window.onload = function() {
                updateCalendar();
            };

            function getFormattedDate(day) {
                var monthSelect = document.getElementById('month');
                var yearSelect = document.getElementById('year');
                var currentMonth = monthSelect.value;
                var currentYear = yearSelect.value;
                return currentYear + "-" + (currentMonth < 10 ? '0' : '') + currentMonth + "-" + (day < 10 ? '0' : '') + day;
            }
            
        </script>


<div class="not-available-container">
<h2 class="log">Not Available Days Log</h2>
   <table id="notAvailableTable" class="display responsive">
       <thead>
           <tr>
           <th>Date</th>
           <th>Title</th>
           <th>Description</th>
           <th>Action</th> 
           </tr>
       </thead>
       <tbody>
           <?php foreach ($notAvailableDays as $day) : ?>
               <tr>
                   <td><?php echo $day['date']; ?></td>
                   <td><?php echo $day['title']; ?></td>
                   <td><?php echo $day['description']; ?></td>
                   <td>
    
        <i class="fas fa-trash"></i> Delete
    </button>
</td>
               </tr>
           <?php endforeach; ?>
       </tbody>
   </table>
</div>
    </div>
       

          
    </main> 
   <!-------------------END OF MAIN---------------->  
   <div class="right">
      <div class="top">
        <button id="menu-btn">
          <span class="material-icons-round">menu</span>
        </button>
        
        <div class="profile">
          <div class="info">

            <p>Hello, 

              <b><?php echo $_SESSION['username']?></b></p>
            <small class="text-muted"></small>
          </div>
          <div class="profile-photo">
            <img src="./images/ustp.png">
          </div>
        </div>
   <!-------------------TOP RIGHT SIDE, TOGGLE DARK AND LIGHT MODE---------------->  
 <div class="col-md-1">
   
      </div>
      <!--END OF TOP-->
     
</body><script>
$(document).ready(function () {
    $('#notAvailableTable').DataTable({
        "lengthMenu": [5, 10, 25],
        "scrollX": "300px", // Set the desired height for the scrollable area
        "paging": true, // Enable paging
        "pageLength": 5 // Set the number of entries per page to 5
    });
});

</script>

<script>
    function deleteRow(date) {
        var table = $('#notAvailableTable').DataTable();
        var rowIndex = -1;

        // Find the row index with the given date
        table.rows().every(function (rowIdx, tableLoop, rowLoop) {
            var rowData = this.data();
            if (rowData[0] === date) {
                rowIndex = rowIdx;
                return false; // Exit the loop once found
            }
        });

        if (rowIndex !== -1) {
            // Show a confirmation dialog
            if (confirm('Are you sure you want to delete this row?')) {
                // Make an AJAX request to delete the row from the database
                $.ajax({
                    type: 'POST',
                    url: 'deleteday.php',
                    data: { date: date },
                    success: function (response) {
                        if (response === 'Success') {
                            // Remove the row from the DataTable
                            table.row(rowIndex).remove().draw(false);
                        } else {
                            alert('Error deleting row: ' + response);
                        }
                    },
                    error: function (xhr, status, error) {
                        alert('AJAX request failed: ' + error);
                    }
                });
            }
        }
    }
</script>

   


</html>
