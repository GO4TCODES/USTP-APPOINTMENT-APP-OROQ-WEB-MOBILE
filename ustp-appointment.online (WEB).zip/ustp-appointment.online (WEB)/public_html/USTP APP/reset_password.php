<?php
$mysqli = new mysqli("localhost", " ", " ", " ");

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["action"]) && $_POST["action"] === "resetPassword") {
        $email = $_POST["email"];
        $code = $_POST["code"];
        $newPassword = $_POST["newPassword"];

        if (verifyResetCode($email, $code)) {
            updatePassword($email, $newPassword);
            echo "Password reset successful.";
        } else {
            echo "Invalid code or email.";
        }
    }
}

function verifyResetCode($email, $code) {
    global $mysqli;
    $sql = "SELECT code FROM studentacc WHERE email = ?";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->bind_result($storedCode);
    if ($stmt->fetch() && $storedCode === $code) {
        $stmt->close();
        return true;
    } else {
        $stmt->close();
        return false;
    }
}

function updatePassword($email, $newPassword) {
    global $mysqli;
    $hashedPassword = password_hash($newPassword, PASSWORD_DEFAULT);
    $sql = "UPDATE studentacc SET password = ? WHERE email = ?";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("ss", $hashedPassword, $email);
    $stmt->execute();
    $stmt->close();
}

$mysqli->close();
?>
