
<?php
// Prevent caching
header("Cache-Control: no-cache, must-revalidate"); // HTTP/1.1
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");
require_once("MUDMSCON.php");
session_start();



if (!isset($_SESSION['username'])) {
  $_SESSION['msg'] = "You have to log in first";
  session_destroy();
  header('location: Login.php');
  exit(); // Exit to prevent further execution
}

if (isset($_GET['logout'])) {
  session_destroy();
  unset($_SESSION['username']);
  header("location: Login.php");

}require_once("MUDMSCON.php");
$query6 ="SELECT * FROM `notavailabledays`";
              $result6=  mysqli_query($con,$query6);
              ?>

<!DOCTYPE html>
<html lang="en">
<head>
    
<meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="icon" href="./images/USTP.png" type="image/ico" sizes="16x16">
  <title>USTP Appointment System</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css">
  <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.js"></script>
  <link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css"/>
  <!--MATERIAL CDN-->


  <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round"
  rel="stylesheet">

  <!--STYLESHEET-->
  <link rel="stylesheet" href="Style.css">
  <style>
    /* Adjust the modal size */
    .modal-dialog.modal-xxl {
        max-width: 95%;
        margin: 1.75rem auto;
    }
</style>

</head>
<body>
    <!-- Logout Confirmation Modal -->
<div class="modal fade" id="logoutConfirmationModal" tabindex="-1" role="dialog" aria-labelledby="logoutConfirmationModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="logoutConfirmationModalLabel">Logout Confirmation</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Are you sure you want to logout?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <a href="Logout.php" class="btn btn-primary">Logout</a>
            </div>
        </div>
    </div>
</div>

    <!-- Confirmation Modal -->
<div class="modal fade" id="confirmationModal" tabindex="-1" role="dialog" aria-labelledby="confirmationModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="confirmationModalLabel">Confirm Update</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Are you sure you want to update this appointment?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-primary" id="confirmUpdateBtn">Confirm Update</button>
            </div>
        </div>
    </div>
</div>

<div id="notification" class="alert alert-success" style="display: none;">Remarks submitted successfully</div>
<div class="container-fluid">
  <div class="row">
    <aside class="col-md-2">
      <!-- Sidebar content goes here -->
      <div class="top">
        <div class="logo">
          <img src="./images/USTP.png">
          <h1><span class="danger"></span></h1>
        </div>
        <div class="close" id="close-btn">
          <span class="material-icons-round"> close </span>
        </div>
      </div>
      <div class="sidebar">
        <a href="Home.php" >
          <span class="material-icons-round">dashboard</span>
          <h3> Dashboard </h3>
        </a>
        
        <a href="Appointments Admin.php" class="active" >
          <span class="material-icons-round">description</span>
          <h3> Appointment </h3>
        </a>
        <a href="Availability.php"  >
          <?php
           if ($result6) {
             $notif = mysqli_num_rows($result6);
             mysqli_free_result($result6);
           }
          ?>       
          <span class="material-icons-round">check</span>
          <h3> Availability </h3>
          <span class="request-count"><?php echo $notif; ?></span>
        </a>
        <!--
        <a href="ManageD.php" >
          <span class="material-icons-round"> description</span>
          <h3> Manage Documents </h3>
        </a>
          -->
        <a href="Transaction Log.php">
          <span class="material-icons-round"> report</span>
          <h3> Transaction Logs </h3>
        </a>
        <a href="Manageusers.php">
          <span class="material-icons-round"> settings</span>
          <h3> Manage Staff</h3>
        </a>
        <a href="#" data-toggle="modal" data-target="#logoutConfirmationModal">
            <span class="material-icons-round">power_settings_new</span>
            <h3>Logout</h3>
        </a>

      </div>
    </aside>


      <!-------END OF ASIDE------>
  
      <main class="col-md-8 ">
  
      
        <script type="text/javascript" src="DataTables/datatables.min.js"></script>
        
               <br>
               <br>
               <br>
               <br>
              <div>
  <h4>APPOINTMENTS</h4>
  <div style="height: 700px; width: 1500; overflow: auto;">
    <table class="table table-striped table-bordered">
      <thead class="thead-dark">
        <tr>
          <th>Appointment Id</th>
          <th>Document Type</th>
          <th>Request Status</th>
          <th>Document Status</th>
     
          <th>Actions</th>
        </tr>
      </thead>
     <tbody>
            <?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'Exception.php';
require 'PHPMailer.php';
require 'SMTP.php';

$mail = new PHPMailer(true);

// SMTP server settings
$mail->IsSMTP();
$mail->Host = 'smtp.hostinger.com';
$mail->Port = //PORT
$mail->SMTPAuth = true;
$mail->SMTPSecure = 'ssl'; 
$mail->Username = //EMAIL
$mail->Password = // Your email password

require_once("MUDMSCON.php");

if (isset($_POST['update'])) {
    $appointmentId = $_POST['appointmentId'];
    $requestStatus = $_POST['requestStatus'];
    $documentStatus = $_POST['documentStatus'];
 /*   $overallstatus = $_POST['overallstatus'];*/
    $username = $_SESSION['username'];


    $updateSql = "UPDATE appointments SET status = '$requestStatus', docstatus = '$documentStatus', staff = '$username' WHERE id = $appointmentId";
              
              
    if ($con->query($updateSql) === TRUE) {
    $completeSql = "UPDATE appointments 
                    SET overall_status = 'COMPLETED' 
                    WHERE id = $appointmentId 
                    AND status = 'Approved' 
                    AND docstatus = 'Complete'";

    // Execute the second update
    if ($con->query($completeSql) === TRUE) {
        echo "Appointment updated successfully";
    } else {
        echo "Error updating overall_status: " . $con->error;
    }  
    $rejectSql = "UPDATE appointments 
                    SET overall_status = 'REJECTED' 
                    WHERE id = $appointmentId 
                    AND status = 'Rejected' 
                    AND docstatus = 'Rejected'";

    // Execute the second update
    if ($con->query($completeSql) === TRUE) {
 $overallstatus = "COMPLETED";
    } else {
        echo "Error updating overall_status: " . $con->error;
    }    // Execute the second update
    if ($con->query($rejectSql) === TRUE) {

    } else {
        echo "Error updating overall_status: " . $con->error;
    }
        $fetchStudentSql = "SELECT s.fname AS FirstName, s.lname AS LastName, s.contact AS Contact, s.age AS Age, 
            s.birthdate AS DateOfBirth, s.email AS Email, s.student_id AS IDNumber, s.course AS CourseYear, 
            a.dateofrequest AS DateOfRequest, a.title AS Title, a.overall_status AS overallstatus
            FROM studentacc s
            INNER JOIN appointments a ON a.email = s.email
            WHERE a.id = $appointmentId";
        $studentResult = $con->query($fetchStudentSql);

        if ($studentResult->num_rows > 0) {
            $studentRow = $studentResult->fetch_assoc();
            $studentName = $studentRow['FirstName'] . ' ' . $studentRow['LastName'];
            $studentCourse = $studentRow['CourseYear'];
            $studentEmail = $studentRow['Email'];
            $dateRequested = $studentRow['DateOfRequest'];
            $title = $studentRow['Title'];
            $overallstatus = $studentRow['overallstatus'];
        
            $emailSubject = 'Appointment Status Update';
            $emailMessage = "
Dear $studentName,

Your appointment status has been updated. Here are the details:
- Appointment ID: $appointmentId
- Document Requested: $title
- Request Status: $requestStatus
- Document Status: $documentStatus
- Date Requested: $dateRequested
- Course & Year: $studentCourse


Appointment Overall Status: $overallstatus

Best regards,
USTP-APP OROQUIETA
";


       
            $mail->setFrom('ustp-oro@ustp-appointment.online', 'USTP-APP OROQUIETA'); 
            $mail->addAddress($studentEmail);

            $mail->Subject = $emailSubject;
            $mail->Body = $emailMessage;

            try {
   
                $mail->send();
                echo 'Email sent successfully';
            } catch (Exception $e) {
                echo 'Email could not be sent. Mailer Error: ' . $mail->ErrorInfo;
            }

   
            echo "<p class='alert alert-success'>Status updated successfully. Email notification sent to the student.</p>";
        } else {
            echo "<p class='alert alert-danger'>Error fetching student's information from the database.</p>";
        }
    } else {
        echo "<p class 'alert alert-danger'>Error updating status: " . $con->error . "</p>";
    }
}
// Handle the Delete Operation
if (isset($_POST['delete'])) {
    $deleteId = $_POST['deleteId'];

    // Add your SQL DELETE statement here
    $deleteSql = "DELETE FROM appointments WHERE id = $deleteId";

    if ($con->query($deleteSql) === TRUE) {
        echo "<p class='alert alert-success'>Appointment deleted successfully.</p>";
    } else {
        echo "<p class='alert alert-danger'>Error deleting appointment: " . $con->error . "</p>";
    }
}

        


 $sql = "SELECT
    a.id AS AppointmentId,
    a.title AS DocumentType,
    a.status AS RequestStatus,
    a.Docstatus AS DocumentStatus,
    a.overall_status AS overallstatus,
    s.fname AS FirstName,
    s.lname AS LastName,
    s.contact AS Contact,
    s.age AS Age,
    s.birthdate AS DateOfBirth,
    s.profile_picture AS profile_picture,
    a.dateofrequest AS DateOfRequest,
    a.selectedPurpose AS PurposeOfRequest,
    a.selectedCategory AS Category,
    a.email AS Email,
    s.student_id AS IDNumber,
    a.selectedCourse AS CourseYear,
    a.selectedYear AS selectedYear,
    a.id AS AppointmentNumber,
    a.fileUpload AS fileUpload,
    a.selectedCAVCertification AS CAV,
    a.selectedCertification AS certificate
FROM appointments a
INNER JOIN studentacc s ON a.email = s.email
WHERE a.overall_status = 'In Progress'";


            $result = $con->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<form method='post'>";
                    echo "<tr>";
                    echo "<td>" . $row['AppointmentId'] . "</td>";
                    echo "<td>" . $row['DocumentType'] . "</td>";
                    echo "<td>
                        <select class='form-control' name='requestStatus'>
                            <option value='Pending' " . ($row['RequestStatus'] == 'Pending' ? 'selected' : '') . ">Pending</option>
                            <option value='Approved' " . ($row['RequestStatus'] == 'Approved' ? 'selected' : '') . ">Approved</option>
                            <option value='Rejected' " . ($row['RequestStatus'] == 'Rejected' ? 'selected' : '') . ">Rejected</option>
                            
                        </select>
                    </td>";
                    echo "<td>
                        <select class='form-control' name='documentStatus'>
                        <option value='Pending' " . ($row['DocumentStatus'] == 'Pending' ? 'selected' : '') . ">Pending</option>
                        <option value='Rejected' " . ($row['DocumentStatus'] == 'Rejected' ? 'selected' : '') . ">Rejected</option>
                            <option value='Processing..' " . ($row['DocumentStatus'] == 'Processing..' ? 'selected' : '') . ">In Progress</option>
                            <option value='Ready for Pickup' " . ($row['DocumentStatus'] == 'Ready for Pickup' ? 'selected' : '') . ">Ready for Pickup</option>
                             <option value='Complete' " . ($row['DocumentStatus'] == 'Complete' ? 'selected' : '') . ">Complete and Picked up</option>
                        </select>
                    </td>";  
                     echo "<td>
                        <select class='form-control' name='overallstatus' style='display: none;'>
                        <option value='COMPLETED' " . ($row['overallstatus'] == 'COMPLETED' ? 'selected' : '') . ">Complete</option>
                        
                        <option value='IN PROGRESS' " . ($row['overallstatus'] == 'IN PROGRESS' ? 'selected' : '') . ">In Progress</option>
                         <option value='REJECTED' " . ($row['overallstatus'] == 'REJECTED' ? 'selected' : '') . ">Reject</option>
                        </select>
                        <input type='hidden' name='appointmentId' value='" . $row['AppointmentId'] . "'>
                        <input type='submit' class='btn btn-primary update-btn' name='update' value='Update'>


                        <button type='button' class='btn btn-info' data-toggle='modal' data-target='#studentModal" . $row['AppointmentId'] . "'>View</button>
                    </td>";
                  
                   
                    echo "</tr>";
                    echo "</form>";
                    $remarksQuery = "SELECT remarks FROM appointments WHERE id = " . $row['AppointmentId'];
                    $remarksResult = $con->query($remarksQuery);
                    $remarksText = "";
                
                    if ($remarksResult && $remarksResult->num_rows > 0) {
                        $remarksRow = $remarksResult->fetch_assoc();
                        $remarksText = $remarksRow['remarks'];
                    }
                    echo "<div class='modal fade' id='studentModal" . $row['AppointmentId'] . "' tabindex='-1' role='dialog' aria-labelledby='studentModalLabel' aria-hidden='true'>
                    <div class='modal-dialog modal-dialog-centered modal-xxl' role='document'>
                        <div class='modal-content'>
                            <div class='modal-header'>
                                <h5 class='modal-title' id='studentModalLabel'>Student Details</h5>
                                <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
                                    <span aria-hidden='true'>&times;</span>
                                </button>
                            </div>
                            <div class='modal-body'>
                                <div class='row'>
                                    <div class='col-md-3'>
                                        <p><strong>Full Name:</strong> " . $row['FirstName'] . ' ' . $row['LastName'] . "</p>
                                        <p><strong>Appointment Number:</strong> " . $row['AppointmentId'] . "</p>
                                        <p><strong>Course & Year:</strong> " . $row['CourseYear'] . ' - ' . $row['selectedYear'] . "</p>
                                        <p><strong>Date of Birth:</strong> " . $row['DateOfBirth'] . "</p>
                                        <p><strong>Age:</strong> " . $row['Age'] . "</p>
                                        <p><strong>Date of Request:</strong> " . $row['DateOfRequest'] . "</p>
                                        <p><strong>Request Document:</strong> " . $row['DocumentType'] . "</p>
                                        <p><strong>CAV Certificate Requested:</strong> " . $row['CAV'] . "</p>
                                        <p><strong>Certificate Requested:</strong> " . $row['certificate'] . "</p>
                                        <p><strong>Purpose of Request:</strong> " . $row['PurposeOfRequest'] . "</p>
                                        <p><strong>Email:</strong> " . $row['Email'] . "</p>
                                        <p><strong>Contact:</strong> " . $row['Contact'] . "</p>
                                        <p><strong>ID Number:</strong> " . $row['IDNumber'] . "</p>
                                        <p><strong>Category:</strong> " . $row['Category'] . "</p>
                                    </div>
                                    <div class='col-md-3'>
                                    <p><strong>Profile Picture</strong></p>
                                    <br>
                                   <img style='border: 5px solid #000; border-radius:30px;' src='" . $row['profile_picture'] . "?timestamp=" . time() . "' width='1' height='450'></img>

                                    <br>
                                    <br>
                                    
                                </div>
                                <br>
                                    <div class='col-md-6'>
                                    <p><strong>E-Clearance</strong></p>
                                    <br>
                                    <iframe src='" . $row['fileUpload'] . "' width='100%' height='500'></iframe>
                                    </div>
                                </div>
                               
                                <p><strong>Remarks:</strong></p>
                                <textarea class='form-control' name='remarks" . $row['AppointmentId'] . "' id='remarks" . $row['AppointmentId'] . "' rows='4'>" . $remarksText . "</textarea>
                                <br>
                                <button type='button' class='btn btn-primary' id='submitRemarks' onclick='submitRemarks(" . $row['AppointmentId'] . ")'>Update Remark</button>
                            </div>
                            <div class='modal-footer'>
                                <button type='button' class='btn btn-secondary' data-dismiss='modal'>Close</button>
                            </div>
                        </div>
                    </div>
                </div>";
                

                }
            } else {
                echo "<tr><td colspan='5'>No data found</td></tr>";
            }
            if ($result === false) {
                echo "Query error: " . mysqli_error($con);
            }
            
            $con->close();
            ?>
        </tbody>
    </table>
  </div>
</div>
     
          <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
          <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
          <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
          <div id="notification" class="alert alert-success" style="display: none;">Remarks submitted successfully</div>


          <script>
function submitRemarks(appointmentId) {
    var remarks = document.getElementById('remarks' + appointmentId).value;

    // Send the remarks to your server using Ajax
    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'update_remarks.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) {
                // Handle the response
                console.log(xhr.responseText);

                if (xhr.responseText.trim() === 'success') {
                    // Show the notification
                    document.getElementById('notification').style.display = 'block';

             
                }
            } else {
                // Handle errors here, if any
                console.log("An error occurred");
            }
        }
    };
    xhr.send('appointmentId=' + appointmentId + '&remarks=' + remarks);

    // Close the modal
    $('#studentModal' + appointmentId).modal('hide');
}
</script>
<script>
    $(document).ready(function () {
        $('#confirmDeleteBtn').click(function () {
            $('#deleteForm').submit();
        });
    });
</script>


           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script> 
           <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>  
           <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script> 
           <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
           <script src="https://cdn.datatables.net/plug-ins/1.11.1/features/fuzzySearch/dataTables.fuzzySearch.js"></script>


    </main> 
   <!-------------------END OF MAIN---------------->  

       <script src="./index.js"></script>
       
</body>
</html>

 