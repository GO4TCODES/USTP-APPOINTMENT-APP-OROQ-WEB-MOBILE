<!DOCTYPE html>
<html>
<head>
    <link rel="icon" href="./images/USTP.png" type="image/ico" sizes="16x16">

    <title>Admin Login Page</title>
    <link rel="stylesheet" type="text/css" href="Style2.css">
    <link rel="stylesheet" type="text/css" href="Newl.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
</head>
<body style="background-color: #1a1851;">
    <form action="Process.php" method="POST">
        <div class="wrapper fadeInDown">
            <div id="formContent">
                <!-- Tabs Titles -->
                <h2 class="active"><i class="fas fa-user"></i> Admin</h2>
                <a href="StaffLogin.php">
                    <h2 class="inactive underlineHover"><i class="fas fa-users"></i> Staff</h2>
                </a>
                <!-- Icon -->
                <div class="fadeIn first">
                    <img src="./images/USTP.png" alt="USTP Logo" style="width: 240px; height: 240px;">
                </div>
                <!-- Login Form -->
                <form>
                    <div class="input-container">
                        <i class="fas fa-user"></i>
                        <input type="text" id="user" class="fadeIn second" name="Admin" placeholder="Login">
                    </div>
                    <div class="input-container">
                        <i class="fas fa-lock"></i>
                        <input type="password" id="pass" class="fadeIn third" name="Apass" placeholder="Password">
                    </div>
                    <br>
                    <input type="submit" class="fadeIn fourth" i value="Log In">

                </form>
            </div>
        </div>
    </form>
</body>
</html>
