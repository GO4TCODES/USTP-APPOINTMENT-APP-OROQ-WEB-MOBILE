<?php
// Database connection parameters
require_once("MUDMSCON.php");

// Check the connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

// Get user registration data from the Flutter app
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);

$newStudentId = $request->student_id;
$newFname = $request->fname;
$newLname = $request->lname;
$newCourse = $request->course;
$newContact = $request->contact;
$newAge = $request->age;
$newBirthdate = $request->birthdate;
$newEmail = $request->email; // Change to 'email' instead of 'username'
$password = $request->password;
$profile_picture ="uploads/USTP.jpg";
// Check if the email already exists
$checkSql = "SELECT * FROM studentacc WHERE email = '$newEmail'";
$checkResult = $con->query($checkSql);

if ($checkResult->num_rows > 0) {
  
    $response = array("message" => "Email already exists");
} else {

    $sql = "INSERT INTO studentacc (student_id, fname, lname, course, contact, age, birthdate, email, password, profile_picture) 
            VALUES ('$newStudentId', '$newFname', '$newLname', '$newCourse', '$newContact', '$newAge', '$newBirthdate', '$newEmail', '$password','$profile_picture')";

    if ($con->query($sql) === TRUE) {
        $response = array("message" => "Registration successful");
    } else {
        $response = array("message" => "Registration failed: " . $con->error);
    }
}


header('Content-Type: application/json');
echo json_encode($response);


$con->close();
?>
