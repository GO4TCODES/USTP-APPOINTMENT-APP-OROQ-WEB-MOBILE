<?php
session_start();
	$user = $_POST['user'];
	$password = $_POST['upass'];

  	$con=mysqli_connect("localhost"," "," "," ");
	mysqli_select_db($con," ");

	$user = stripcslashes($user);
	$password = stripslashes($password);
	$user = mysqli_real_escape_string($con,$user);
	$password = mysqli_real_escape_string($con,$password);

	$result = mysqli_query($con,"SELECT * FROM createdaccounts WHERE username = '$user' AND password = '$password'")
	or die("WALA NI EPEKT" .mysqli_error($con));
 
	$row = mysqlI_fetch_array($result);


	if (empty($user)) {
		echo "tet";
		header("Location: StaffLogin.php");
		exit();
	}
	if (empty($password)) {
		header("Location: StaffLogin.php");

	}

	if ($row['username'] == $user && $row['password'] == $password) {
		$_SESSION['user'] = $user;
		$_SESSION['logged_in_datetime'] = date("d M Y H:i");
		echo "LOGIN SUCCESS!";
		header("Location: HomeUser.php"); /* Redirect browser */
  		exit();

	}
	else{
		header("Location: StaffLogin.php");
	}
	
?>