<?php

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $email = $_POST['email'];
    $enteredCode = $_POST['code'];

  
    $validVerificationCode = verifyCode($email, $enteredCode);

    if ($validVerificationCode) {
        echo 'Verified';
    } else {
        echo 'Invalid code';
    }
} else {
    http_response_code(405); // Method Not Allowed
    echo 'Invalid request method';
}

function verifyCode($email, $enteredCode) {
    
    $validCode = getVerificationCodeFromDatabase($email); 

    return $enteredCode === $validCode;
}

function getVerificationCodeFromDatabase($email) {
    
    $dbHost = 'localhost';
    $dbUser = 'u694644493_ustpapp';
    $dbPass = '968MxqQc7@0V';
    $dbName = 'u694644493_ustpapp';

    $con = new mysqli($dbHost, $dbUser, $dbPass, $dbName);

    if ($con->connect_error) {
        die('Connection failed: ' . $con->connect_error);
    }

  
    $email = $con->real_escape_string($email);

    $query = "SELECT code FROM studentacc WHERE email = '$email'";
    $result = $con->query($query);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row['code'];
    } else {
        return false; // Email not found
    }

    $con->close();
}
?>