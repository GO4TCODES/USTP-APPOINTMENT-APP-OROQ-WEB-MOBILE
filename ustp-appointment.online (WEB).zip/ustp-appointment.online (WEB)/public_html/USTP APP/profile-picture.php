<?php
header('Content-Type: application/json');
require_once("MUDMSCON.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email']; 

 
    $file = $_FILES['profile_picture'];
    $targetDirectory = 'D:/CODE/htdocs/USTP APP/uploads/';
    $targetPath = $targetDirectory . basename($file['name']);

    if (move_uploaded_file($file['tmp_name'], $targetPath)) {
   
        $sql = "UPDATE studentacc SET profile_picture = '$targetPath' WHERE email = '$email'";
        if ($con->query($sql) === true) {
            $response = ['message' => 'Image uploaded and database updated successfully'];
        } else {
            $response = ['error' => 'Database error: ' . $con->error];
        }
    } else {
        $response = ['error' => 'Failed to move uploaded file'];
    }

    echo json_encode($response);
}


$con->close();
?>
