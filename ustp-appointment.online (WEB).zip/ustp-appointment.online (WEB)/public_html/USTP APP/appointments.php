<?php
header('Content-Type: application/json');

require_once("MUDMSCON.php");

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $email = $_GET['email']; // Get the email address from the query parameter
    $sql = "SELECT id, title, dateRequested, status, remarks FROM appointments WHERE email = '$email'";
    $result = $con->query($sql);

    if ($result === false) {
        die("Database error: " . $con->error);
    }

    if ($result->num_rows > 0) {
        $appointments = array();
        while ($row = $result->fetch_assoc()) {
            $appointments[] = $row;
        }
        echo json_encode($appointments);
    } else {
        echo json_encode([]);
    }
}


// Close the database connection
$con->close();
?>  