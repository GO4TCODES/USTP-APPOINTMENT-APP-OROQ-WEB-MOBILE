<?php
// Database connection parameters
require_once("MUDMSCON.php");

// Check the connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

// Get user data from the Flutter app
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);

$username = $request->username;

// Check if the user exists
$checkSql = "SELECT * FROM studentacc WHERE email = '$username'";
$checkResult = $con->query($checkSql);

if ($checkResult->num_rows == 0) {
    // User doesn't exist, return an error message
    $response = array("message" => "User not found");
} else {
    // User exists, update user data in the database
    $newName = $request->name;
    $newEmail = $request->email;
    $newContact = $request->contact;

    $updateSql = "UPDATE studentacc 
                  SET fname = '$newName', email = '$newEmail', contact = '$newContact' 
                  WHERE email = '$username'";

    if ($con->query($updateSql) === TRUE) {
        $response = array("message" => "Profile updated successfully");
    } else {
        $response = array("message" => "Profile update failed: " . $con->error);
    }
}

// Send JSON response back to the Flutter app
header('Content-Type: application/json');
echo json_encode($response);

// Close the database connection
$con->close();
?>
