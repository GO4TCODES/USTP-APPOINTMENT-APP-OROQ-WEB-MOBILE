    <!DOCTYPE html>
<html>
<head>
    <title>Professional Table Design with Student Details</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>

<div class="container mt-4">
    <table class="table table-striped table-bordered">
        <thead class="thead-dark">
            <tr>
                <th>Appointment Id</th>
                <th>Document Type</th>
                <th>Request Status</th>
                <th>Document Status</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php
         require_once("MUDMSCON.php");

         if (isset($_POST['update'])) {
            $appointmentId = $_POST['appointmentId'];
            $requestStatus = $_POST['requestStatus'];
            $documentStatus = $_POST['documentStatus'];
        
 
            $updateSql = "UPDATE appointments SET status = '$requestStatus', Docstatus = '$documentStatus' WHERE id = $appointmentId";
        
            if ($con->query($updateSql) === TRUE) {

                echo "<p class='alert alert-success'>Status updated successfully</p>";
            } else {
                echo "<p class='alert alert-danger'>Error updating status: " . $con->error . "</p>";
            }
        }
        

        


            $sql = "SELECT
                a.id AS AppointmentId,
                a.title AS DocumentType,
                a.status AS RequestStatus,
                a.Docstatus AS DocumentStatus,
                s.fname AS FirstName,
                s.lname AS LastName,
                s.contact AS Contact,
                s.age AS Age,
                s.birthdate AS DateOfBirth,
                a.dateRequested AS DateOfRequest,
                a.selectedPurpose AS PurposeOfRequest,
                a.selectedCategory AS Category,
                a.email AS Email,
                s.student_id AS IDNumber,
                a.selectedCourse AS CourseYear,
                a.selectedYear AS selectedYear,
                a.id AS AppointmentNumber,
                a.fileUpload AS fileUpload
            FROM appointments a
            INNER JOIN studentacc s ON a.email = s.email";

            $result = $con->query($sql);

            if ($result->num_rows > 0) {
                while ($row = $result->fetch_assoc()) {
                    echo "<form method='post'>";
                    echo "<tr>";
                    echo "<td>" . $row['AppointmentId'] . "</td>";
                    echo "<td>" . $row['DocumentType'] . "</td>";
                    echo "<td>
                        <select class='form-control' name='requestStatus'>
                            <option value='Pending' " . ($row['RequestStatus'] == 'Pending' ? 'selected' : '') . ">Pending</option>
                            <option value='Approved' " . ($row['RequestStatus'] == 'Approved' ? 'selected' : '') . ">Approved</option>
                            <option value='Rejected' " . ($row['RequestStatus'] == 'Rejected' ? 'selected' : '') . ">Rejected</option>
                            
                        </select>
                    </td>";
                    echo "<td>
                        <select class='form-control' name='documentStatus'>
                        <option value='Pending' " . ($row['DocumentStatus'] == 'Pending' ? 'selected' : '') . ">Pending</option>
                        <option value='Rejected' " . ($row['DocumentStatus'] == 'Rejected' ? 'selected' : '') . ">Rejected</option>
                            <option value='Processing..' " . ($row['DocumentStatus'] == 'Processing..' ? 'selected' : '') . ">In Progress</option>
                            <option value='Ready for Pickup' " . ($row['DocumentStatus'] == 'Ready for Pickup' ? 'selected' : '') . ">Ready for Pickup</option>
                        </select>
                    </td>";
                    echo "<td>
                        <input type='hidden' name='appointmentId' value='" . $row['AppointmentId'] . "'>
                        <input type='submit' class='btn btn-primary' name='update' value='Update'>
                        <button type='button' class='btn btn-info' data-toggle='modal' data-target='#studentModal" . $row['AppointmentId'] . "'>View</button>
                    </td>";
                    echo "</tr>";
                    echo "</form>";
                    $remarksQuery = "SELECT remarks FROM appointments WHERE id = " . $row['AppointmentId'];
                    $remarksResult = $con->query($remarksQuery);
                    $remarksText = "";
                
                    if ($remarksResult && $remarksResult->num_rows > 0) {
                        $remarksRow = $remarksResult->fetch_assoc();
                        $remarksText = $remarksRow['remarks'];
                    }
                    echo "<div class='modal fade' id='studentModal" . $row['AppointmentId'] . "' tabindex='-1' role='dialog' aria-labelledby='studentModalLabel' aria-hidden='true'>
                    <div class='modal-dialog modal-dialog-centered modal-xl' role='document'>
                        <div class='modal-content'>
                            <div class='modal-header'>
                                <h5 class='modal-title' id='studentModalLabel'>Student Details</h5>
                                <button type='button' class='close' data-dismiss='modal' aria-label='Close'>
                                    <span aria-hidden='true'>&times;</span>
                                </button>
                            </div>
                            <div class='modal-body'>
                                <div class='row'>
                                    <div class='col-md-6'>
                                        <p><strong>Full Name:</strong> " . $row['FirstName'] . ' ' . $row['LastName'] . "</p>
                                        <p><strong>Appointment Number:</strong> " . $row['AppointmentId'] . "</p>
                                        <p><strong>Course & Year:</strong> " . $row['CourseYear'] . ' - ' . $row['selectedYear'] . "</p>
                                        <p><strong>Date of Birth:</strong> " . $row['DateOfBirth'] . "</p>
                                        <p><strong>Age:</strong> " . $row['Age'] . "</p>
                                        <p><strong>Date of Request:</strong> " . $row['DateOfRequest'] . "</p>
                                        <p><strong>Request Document:</strong> " . $row['DocumentType'] . "</p>
                                        <p><strong>Purpose of Request:</strong> " . $row['PurposeOfRequest'] . "</p>
                                        <p><strong>Email:</strong> " . $row['Email'] . "</p>
                                        <p><strong>Contact:</strong> " . $row['Contact'] . "</p>
                                        <p><strong>ID Number:</strong> " . $row['IDNumber'] . "</p>
                                        <p><strong>Category:</strong> " . $row['Category'] . "</p>
                                    </div>
                                    <div class='col-md-6'>
                                    <p><strong>E-Clearance</strong></p>
                                    <br>
                                    <iframe src='" . $row['fileUpload'] . "' width='100%' height='500'></iframe>
                                    </div>
                                </div>
                               
                                <p><strong>Remarks:</strong></p>
                                <textarea class='form-control' name='remarks" . $row['AppointmentId'] . "' id='remarks" . $row['AppointmentId'] . "' rows='4'>" . $remarksText . "</textarea>
                                <br>
                                <button type='button' class='btn btn-primary' id='submitRemarks' onclick='submitRemarks(" . $row['AppointmentId'] . ")'>Submit</button>
                            </div>
                            <div class='modal-footer'>
                                <button type='button' class='btn btn-secondary' data-dismiss='modal'>Close</button>
                            </div>
                        </div>
                    </div>
                </div>";
                

                }
            } else {
                echo "<tr><td colspan='5'>No data found</td></tr>";
            }
            if ($result === false) {
                echo "Query error: " . mysqli_error($con);
            }
            
            $con->close();
            ?>
        </tbody>
    </table>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
function submitRemarks(appointmentId) {
    var remarks = document.getElementById('remarks' + appointmentId).value;
    

    var xhr = new XMLHttpRequest();
    xhr.open('POST', 'update_remarks.php', true);
    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
    xhr.onreadystatechange = function () {
        if (xhr.readyState === 4 && xhr.status === 200) {

            console.log(xhr.responseText);
 
        }
    };
    xhr.send('appointmentId=' + appointmentId + '&remarks=' + remarks);

    
    $('#studentModal' + appointmentId).modal('hide');
}

</script>

</body>
</html>
