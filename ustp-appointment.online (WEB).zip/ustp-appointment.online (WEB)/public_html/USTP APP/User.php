
<!DOCTYPE html>
<html>
<head>
	<title>User</title>
	<link rel="stylesheet" type="text/css" href="Style.css">
</head>
<body>
	<div id="frm">
		<form action="Process2.php" method="POST">
			<p>
				<h2 style="text-align: center;font-family: futura; font-size: 55px; text-shadow: -4px 3px #808B96; color: #e89d25;">MUDMS</h2>
				<p style="text-align: center;">Staff Login</p>
	
				<label>Username: </label>
				<input type="text" id="user" name="user" size="30" />
			</p>
			<p>
				<label>Password:  </label>
				<input type="password" id="pass" name="upass" size="30"/>
				<p>Please fill up the blanks.</p>
			</p>


			<p align="center">
				<input type="submit" id="btn" value="Login"></input>
			</p>
			 <input style="background-color: #F7EF89 "type="button" value="Log in as Admin" class="btn" id="btnHome" onClick="document.location.href='http://localhost/MUDMS/Login.php'" />
		</form>
	</div>
</body>
</html>