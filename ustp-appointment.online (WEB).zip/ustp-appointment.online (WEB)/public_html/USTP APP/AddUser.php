<?php

session_start();

if (!isset($_SESSION['user']) && !isset($_SESSION['password']) ) {
  $_SESSION['msg'] = "You have to log in first";
  header('location: LoginStaff.php');
}
              include_once 'MUDMSCON.php';
              $query ="SELECT * FROM Request";
              $result = mysqli_query($con,$query);

              $query2 ="SELECT Request.*,Documents.* FROM Request, Documents WHERE Request.rid = Documents.rid";
              $result2= mysqli_query($con,$query2);
              
              $query6 ="SELECT * FROM `Request` WHERE status='Pending'  
              ORDER BY `Request`.`status` ASC";
              $result6=  mysqli_query($con,$query6);

              ?>

<!DOCTYPE html>
<html lang="en">
<head>
    
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <title>Misamis University Document Management System</title>

        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">


        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css">
        <link rel="stylesheet" type="text/css" href="bootstrap-4.0.0-dist/js/bootstrap.min.js"/>
        <link rel="stylesheet" type="text/css" href="bootstrap-4.0.0-dist/css/bootstrap.min.css"/>
        <link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css"/>
  <!--MATERIAL CDN-->


  <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round"
  rel="stylesheet">

  <!--STYLESHEET-->
  <link rel="stylesheet" href="Style.css">

</head>
<body>
  <!-- Delete Modal -->
<div class="modal fade" id="deletemodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Delete Request?</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="Delete.php" method="POST">
          <div class="modal-body">
           <input type="hidden" name="deleteid" id="deleteid">
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" name="deletedatauser" class="btn btn-primary" >Confirm</button>
          </div>
      </form>
      
    </div>
  </div>
</div>
 <!-- Create Modal -->
<div class="modal fade" id="createmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Create Request</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="Insert.php" method="POST" enctype="multipart/form-data">
          <div class="modal-body">
            <div class="Form-group"> 

              <label>Student ID</label>
              <input type="text" name="student_id" id="student_id" class="form-control" placeholder="Student ID">
              <label>First Name</label>
              <input type="text" name="fname" id="fname" class="form-control" placeholder="First name">
              <label>Middle Name</label>
              <input type="text" name="mname" id="mname" class="form-control" placeholder="Middle name">
              <label>Last Name</label>
              <input type="text" name="lname" id="lname" class="form-control" placeholder="Last name">

            </div> <br>
            <div class="Form-group">
              <label>Course & Year (click ->)</label>
                                    <select name="course" id="course" style="background-color: #f5bc45; border-radius: 5x;">
                                        <option value="">No Changes</option>
                                        <option value="BSIT">BSIT</option>
                                        <option value="BSBA">BSBA</option>
                                        <option value="BSED">BSED</option>
                                        <option value="CRIM">CRIM</option>
                                        <option value="HIGHSCHOOL">HIGHSCHOOL</option>
                                        <option value="ELEMENTARY">ELEMENTARY</option>
                                    </select>
            </div>
           <div class="Form-group">
              <label>What document type is requested?</label>
                                    <select name="type" id="type" style="background-color: #f5bc45; border-radius: 5px;">
                                        <option value="">SELECT</option>
                                        <option value="TOR">TOR</option>
                                        <option value="Cards">Cards</option>
                                        <option value="Diploma">Diploma</option>
                                        <option value="SO">SO</option>
                                        <option value="Form 137">Form 137</option>
                                        <option value="Honorable Dismissal">Honorable Dismissal</option>
                                        <option value="Good Moral">Good Moral</option>
                                    </select>
            </div>                     
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" name="submit2" class="btn btn-primary" >Confirm</button>
          </div>
      </form>
      
    </div>
  </div>
</div>
  <div class="container">
	  <aside>
	    <div class="top">
	      <div class="logo">
		      <img src="./images/logo.png">
		      <h1>MU<span class="danger">DMS</span></h1>
	      </div>
	      <div class="close" id="close-btn">
	        <span class="material-icons-round"> close </span>
        </div>
	    </div>
      <div class="sidebar">
        <a href="HomeUser.php">
          <span class="material-icons-round">dashboard</span>
          <h3> Dashboard </h3>
        </a>
         <a href="AddUser.php"  class="active">
          <span class="material-icons-round add" >post_add</span>
          <h3> Add Request</h3>
        </a>
        <a href="Downloaddoc.php">
          <span class="material-icons-round">download</span>
          <h3>Download Documents</h3>
        </a>
        <a href="Uploaddocuser.php">
          <span class="material-icons-round"> upload</span>
          <h3> Upload Documents</h3>
        </a>
        <a href="userManageR.php" >
<?
           if ($result6)
    {
      
        $notif = mysqli_num_rows($result6);
          
        // close the result.
        mysqli_free_result($result6);
    }?>       
          <span class="material-icons-round"> request_quote</span>
          <h3> Manage Request </h3>
          <span class="request-count"><?php echo $notif; ?></span>
        </a>
        <a href="#">
          <span class="material-icons-round"> settings</span>
          <h3> Settings </h3>
        </a>
        <a href="Logout.php">
          <span class="material-icons-round">power_settings_new </span>
          <h3> Logout </h3>
        </a>
      </div>
    </aside>
      <!-------END OF ASIDE------>
      <main>
        
         
        <script type="text/javascript" src="DataTables/datatables.min.js"></script>

        <div>

            <!-------------------TOP RIGHT SIDE, TOGGLE DARK AND LIGHT MODE---------------->  
    <div class="right">
      <div class="top">
        <button id="menu-btn">
          <span class="material-icons-round">menu</span>
        </button>
        <div class="theme-toggler">
          <span class="material-icons-round active">light_mode</span>
          <span class="material-icons-round">dark_mode</span>
        </div>
        <div class="profile">
          <div class="info">

            <p>Hello, 

              <b><? echo $_SESSION['user']?></b></p>
            <small class="text-muted">User</small>
          </div>
          <div class="profile-photo">
            <img src="./images/logo.png">
          </div>
        </div>
      </div>
      <!--END OF TOP-->
          <h4>ADD REQUEST</h4>

          <button type="button" class="btn add" style="float:right; background-color: #f5bc45;"> ADD REQUEST</button>

        </div>
        

        <br>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script type="text/javascript" src="DataTables/datatables.min.js"></script>

          <div class="">
           <div class="middle">
             <div class="left">
                <div class="table-responsive">  
                     <table id="request_data" class="table table-borderless" align="left" style="font-size: 14px;">  
                          <thead>  
                               <tr> 
                                   
                                    <td>Request ID</td>
                                    <td>Stud ID</td>  
                                    <td>First name</td>  
                                    <td>Middle name</td>  
                                    <td>Last name</td>  
                                    <td>Type</td>
                                    <td>Course</td>
                                    <td>Date Added</td>
                                    <td>Status</td>
                                    <td>Manage</td>

                               </tr>  
                          </thead>  
                          <?php  
                          while($row = mysqli_fetch_array($result))  
                          {  
                               echo '  
                               <tr>  
                                    <td>'.$row["rid"].'</td>
                                    <td>'.$row["student_id"].'</td>  
                                    <td>'.$row["fname"].'</td>  
                                    <td>'.$row["mname"].'</td>  
                                    <td>'.$row["lname"].'</td>
                                    <td>'.$row["type"].'</td>
                                    <td>'.$row["course"].'</td>
                                    <td>'.$row["rdate"].'</td>
                                    <td>'.$row["status"].'</td>
                                    <td><button type="button" class="btn btn-danger delete" style="font-size: 11px;"> Delete </button> </td>
                                
                               </tr>  
                               ';  
                          }  
                          ?>  
                     </table>  
                </div>  
        </div>
    </div>
</div> 

           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script> 
           <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>  
           <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script> 
           <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
           <script src="https://cdn.datatables.net/plug-ins/1.11.1/features/fuzzySearch/dataTables.fuzzySearch.js"></script>
    </main> 
   <!-------------------END OF MAIN---------------->  

   
           <script src="./index.js"></script>
</body>
</html>
  <script>
     $(document).ready(function() { 
        var table = $('#request_data').DataTable({ 
            fuzzySearch: {toggleSmart: false,threshold: 0.6},
            "autoWidth" : true,
            "paging": true,
            "scrollY": 250,
            "scrollX": false,
            order: [[8, 'asc']]
        });
        
         
     } );
 </script> 

  <script>  
 $(document).ready(function(){  
      $('.add').on('click', function() {
          $('#createmodal').modal('show');
            $tr = $(this).closest('tr');
            var data = $tr.children("td").map(function() {
              return $(this).text();
            }).get();

              console.log(data);

         
    });

        //IT STARTS HERE (CLOSE FUNCTION)
    $('.close,.btn').click(function() {
        $( "#createmodal" ).modal('hide');
      		});
    //IT ENDS HERE (CLOSE FUNCTION)
  			});  

 </script>

 <script>
   $('#column3_search').on( 'keyup', function () {
    table
        .columns( 3 )
        .search( this.value )
        .draw();
} 
 </script>
 <script>  
 $(document).ready(function(){  
      $('.delete').on('click', function() {
          $('#deletemodal').modal('show');
            $tr = $(this).closest('tr');
            var data = $tr.children("td").map(function() {
              return $(this).text();
            }).get();

              console.log(data);

              $('#deleteid').val(data[0]);

         
    });

        //IT STARTS HERE (CLOSE FUNCTION)
    $('.close,.btn').click(function() {
        $( "#deletemodal" ).modal('hide');
      });
    //IT ENDS HERE (CLOSE FUNCTION)
  });  

 </script>