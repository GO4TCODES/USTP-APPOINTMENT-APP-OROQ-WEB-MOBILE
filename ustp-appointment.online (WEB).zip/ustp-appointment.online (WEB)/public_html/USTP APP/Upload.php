<?php
include_once 'MUDMSCON.php';


if (isset($_POST['submit']) && isset($_FILES['file']))
{	

	if(empty($_POST['studid']) || empty($_POST['fname']) || empty($_POST['mname']) || empty($_POST['lname']) || empty($_POST['doctype']) || empty($_POST['course']))
        {
            echo ' Please Fill in the Blanks ';
            header("Uploaddoc.php");
        }
        else
        {  $rid = $_POST['rid'];
            $student_id = $_POST['studid'];
            $fname = $_POST['fname'];
            $mname = $_POST['mname'];
            $lname = $_POST['lname'];
            $type = $_POST['doctype'];
            $course = $_POST['course'];
            $added = date("Y-m-d H:i:s"); 
            $status = "Released";
            $doc_status = "✅ Available";
            $released = date("Y-m-d H:i:s"); 
            $query = "INSERT INTO `Request` (`rid`,`student_id`,`fname`, `mname`, `lname`, `type`, `course`, `rdate`, `status`, `doc_status`, `Released`) VALUES ('$rid','$student_id','$fname','$mname', '$lname', '$type', '$course', '$added', '$status','$doc_status','$released')";
            $result = mysqli_query($con,$query);
            
            

	if($result)
                {	


    $filename = $_FILES['file']['name'];
	$destination = 'uploads/' . $filename;

	$extension= pathinfo($filename,PATHINFO_EXTENSION);

	$file = $_FILES['file']['tmp_name'];

	$size = $_FILES['file']['size'];



	$rid = $_POST['rid'];
	$doctype = $_POST['doctype'];
    $added = date("Y-m-d H:i:s"); 
	
	if(!in_array($extension, ['zip', 'pdf', 'png']))
	{
		echo "File should be ZIP, PDF, PNG!";
	}
	elseif ($_FILES['file']['size'] > 20000000) {
		echo "file is too large!";
		# code...
	}
	else{


		if(move_uploaded_file($file, $destination))
		{
			$sql = "INSERT INTO Documents (rid,doctype,added,file) VALUES(LAST_INSERT_ID(),'$doctype','$added','$filename')";

			if(mysqli_query($con,$sql))
			{
				echo "file added successfully!";
				header("location: ManageR2.php");
			}
			else{
				echo "failed to upload";
			}
		}
	}
                     header("location: Uploaddoc.php");
                }
            }
	
}

if (isset($_POST['submituser']) && isset($_FILES['file']))
{	

	if(empty($_POST['studid']) || empty($_POST['fname']) || empty($_POST['mname']) || empty($_POST['lname']) || empty($_POST['doctype']) || empty($_POST['course']))
        {
            echo ' Please Fill in the Blanks ';
            header("Uploaddoc.php");
        }
        else
        {  $rid = $_POST['rid'];
            $student_id = $_POST['studid'];
            $fname = $_POST['fname'];
            $mname = $_POST['mname'];
            $lname = $_POST['lname'];
            $type = $_POST['doctype'];
            $course = $_POST['course'];
            $added = date("Y-m-d H:i:s"); 
            $status = "Released";
            $doc_status = "✅ Available";
            $released = date("Y-m-d H:i:s"); 
            $query = "INSERT INTO `Request` (`rid`,`student_id`,`fname`, `mname`, `lname`, `type`, `course`, `rdate`, `status`, `doc_status`, `Released`) VALUES ('$rid','$student_id','$fname','$mname', '$lname', '$type', '$course', '$added', '$status','$doc_status','$released')";
            $result = mysqli_query($con,$query);

	if($result)
                {	


    $filename = $_FILES['file']['name'];
	$destination = 'uploads/' . $filename;

	$extension= pathinfo($filename,PATHINFO_EXTENSION);

	$file = $_FILES['file']['tmp_name'];

	$size = $_FILES['file']['size'];



	$rid = $_POST['rid'];
	$doctype = $_POST['doctype'];
    $added = date("Y-m-d H:i:s"); 
	
	if(!in_array($extension, ['zip', 'pdf', 'png']))
	{
		echo "File should be ZIP, PDF, PNG!";
	}
	elseif ($_FILES['file']['size'] > 20000000) {
		echo "file is too large!";
		# code...
	}
	else{


		if(move_uploaded_file($file, $destination))
		{
			$sql = "INSERT INTO Documents (rid,doctype,added,file) VALUES(LAST_INSERT_ID(),'$doctype','$added','$filename')";

			if(mysqli_query($con,$sql))
			{
				echo "file added successfully!";
				header("location: Uploaddocuser.php");
			}
			else{
				echo "failed to upload";
			}
		}
	}
                     header("location: Uploaddocuser.php");
                }
            }
	
}


if (isset($_POST['submit2']) && isset($_FILES['file']))
{

	$doc_status = "✅ Available";
    $released = date("Y-m-d H:i:s"); 
    $status="Released";
	$filename = $_FILES['file']['name'];
	$destination = 'uploads/' . $filename;

	$extension= pathinfo($filename,PATHINFO_EXTENSION);

	$file = $_FILES['file']['tmp_name'];

	$size = $_FILES['file']['size'];

	$rid = $_POST['rid'];
	$doctype = $_POST['doctype'];
  	$added = date("Y-m-d H:i:s"); 
  
	$sql1 = "UPDATE `Request` SET `doc_status` ='$doc_status',`status` ='$status', Released = '$released' where rid='$_POST[rid]'";
            
            $query2  = mysqli_query($con,$sql1);
            
	if(!in_array($extension, ['zip', 'pdf', 'png']))
	{
		echo "File should be ZIP, PDF, PNG!";
	}
	elseif ($_FILES['file']['size'] > 20000000) {
		echo "file is too large!";
		# code...
	}
	else{


		if(move_uploaded_file($file, $destination))
		{
			$sql = "INSERT INTO Documents (rid,doctype,added,file) VALUES('$rid','$doctype','$added','$filename')";
			
            
			if(mysqli_query($con,$sql))
			{
				echo "file added successfully!";
				header("location: Uploaddoc.php");
			}
			else{
				echo "failed to upload";
				header("location: Uploaddoc.php");
			}
		}
	}
}

if (isset($_POST['submituser2']) && isset($_FILES['file']))
{
	$doc_status = "✅ Available";
    $released = date("Y-m-d H:i:s"); 
    $status="Released";

	$filename = $_FILES['file']['name'];
	$destination = 'uploads/' . $filename;

	$extension= pathinfo($filename,PATHINFO_EXTENSION);

	$file = $_FILES['file']['tmp_name'];

	$size = $_FILES['file']['size'];

	$rid = $_POST['rid'];
	$doctype = $_POST['doctype'];
  	$added = date("Y-m-d H:i:s"); 
  	
	$sql1 = "UPDATE `Request` SET `doc_status` ='$doc_status',`status` ='$status', Released = '$released' where rid='$_POST[rid]'";
            
            $query2  = mysqli_query($con,$sql1);
            
	if(!in_array($extension, ['zip', 'pdf', 'png']))
	{
		echo "File should be ZIP, PDF, PNG!";
	}
	elseif ($_FILES['file']['size'] > 20000000) {
		echo "file is too large!";
		# code...
	}
	else{


		if(move_uploaded_file($file, $destination))
		{
			$sql = "INSERT INTO Documents (rid,doctype,added,file) VALUES('$rid','$doctype','$added','$filename')";
			
            
			if(mysqli_query($con,$sql))
			{
				echo "file added successfully!";
				header("location: Uploaddocuser.php");
			}
			else{
				echo "failed to upload";
				header("location: Uploaddocuser.php");
			}
		}
	}
}
if (isset($_POST['downloadid']) && isset($_POST['downloadsubmit']) ) {

	$id = $_POST['downloadid'];
	$rid = $_POST['downrid'];
	$doctype = $_POST['documenttype'];

	$sql="SELECT * FROM Documents WHERE doc_id=$id";

	$result = mysqli_query($con,$sql);
	$file = mysqli_fetch_assoc($result);
	$filepath = 'uploads/' . $file['file'];

	#UPDATES DOCUMENT RELEASED DATE ON DOCUMENT RECORD WHEN DOWNLOAD IS CLICKED!
	$Dreleased = date("Y-m-d H:i:s"); 
	$query = "UPDATE `Documents` SET `Dreleased` ='$Dreleased' where doc_id='$_POST[downloadid]'";
    $query_run  = mysqli_query($con,$query);
    #UPDATES DOCUMENT RELEASED DATE ON REQUEST RECORD WHEN DOWNLOAD IS CLICKED!
    #$released="Released";
    #$query1 = "UPDATE `Request` SET status='$released' where rid='$_POST[downrid]'";
    
    #$query_run1  = mysqli_query($con,$query1);
    #UPDATES DOCUMENT RELEASED DATE ON Released History Counter WHEN DOWNLOAD IS CLICKED!

    $query2 = "INSERT INTO `Released_History` (`Doc_Id`, `Requester_ID`, `Released_Date`, `Document`) VALUES ('$id','$rid','$Dreleased','$doctype')";
    $query_run2  = mysqli_query($con,$query2);

	if(file_exists($filepath)){
		header('Content-Type: application/octet-stream');

		header('Content-Description: File Transfer');

		header('Content-Disposition: attachment; filename=' . basename($filepath));
		
		header('Expires: 0');

		header('Cache-Control: must-revalidate');
		header('Pragma:public');
		header('Content-Length:' . filesize('uploads/'.$file['file']));

		readfile('uploads/' . $file['file']);
		
            echo readfile('uploads/' . $file['file']);

	}
	if(mysqli_query($con,$sql))
			{
				echo "file added successfully!";
				header("location: ManageD.php");
			}
	# code...
}

if (isset($_POST['downloadid2']) && isset($_POST['downloadsubmit2']) ) {

	$id = $_POST['downloadid2'];
	$rid = $_POST['downrid'];
	$doctype = $_POST['documenttype'];

	$sql="SELECT * FROM Documents WHERE doc_id=$id";

	$result = mysqli_query($con,$sql);
	$file = mysqli_fetch_assoc($result);
	$filepath = 'uploads/' . $file['file'];

	#UPDATES DOCUMENT RELEASED DATE ON DOCUMENT RECORD WHEN DOWNLOAD IS CLICKED!
	$Dreleased = date("Y-m-d H:i:s"); 
	$query = "UPDATE `Documents` SET `Dreleased` ='$Dreleased' where doc_id='$_POST[downloadid2]'";
    $query_run  = mysqli_query($con,$query);
    #UPDATES DOCUMENT RELEASED DATE ON REQUEST RECORD WHEN DOWNLOAD IS CLICKED!
    #$released="Released";
    #$query1 = "UPDATE `Request` SET status='$released' where rid='$_POST[downrid]'";
    
    #$query_run1  = mysqli_query($con,$query1);
    #UPDATES DOCUMENT RELEASED DATE ON Released History Counter WHEN DOWNLOAD IS CLICKED!

    $query2 = "INSERT INTO `Released_History` (`Doc_Id`, `Requester_ID`, `Released_Date`, `Document`) VALUES ('$id','$rid','$Dreleased','$doctype')";
    $query_run2  = mysqli_query($con,$query2);

	if(file_exists($filepath)){
		header('Content-Type: application/octet-stream');

		header('Content-Description: File Transfer');

		header('Content-Disposition: attachment; filename=' . basename($filepath));
		
		header('Expires: 0');

		header('Cache-Control: must-revalidate');
		header('Pragma:public');
		header('Content-Length:' . filesize('uploads/'.$file['file']));

		readfile('uploads/' . $file['file']);
		
            echo readfile('uploads/' . $file['file']);

	}
	if(mysqli_query($con,$sql))
			{
				echo "file added successfully!";
				header("location: Downloaddoc.php");
			}
	# code...
}
?>