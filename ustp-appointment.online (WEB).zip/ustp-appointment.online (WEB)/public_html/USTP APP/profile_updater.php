<?php
error_log("Received email: $email");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $emailForFilename = preg_replace("/[^a-zA-Z0-9]/", "", $email); 
    $student_id = $_POST['student_id'];
    $firstName = $_POST['fname'];
    $lastName = $_POST['lname'];
    $course = $_POST['course'];
    $contact = $_POST['contact'];
    $age = $_POST['age'];
    $birthdate = $_POST['birthdate'];
    $pass = $_POST['password'];

    
    $target_dir = "uploads/";
    $target_file = $target_dir . $emailForFilename . ".jpg";
    move_uploaded_file($_FILES["profile_picture"]["tmp_name"], $target_file);

  
    $db = new mysqli("localhost", " ", " ", " ");

   
    if (!$target_file) {
        echo "Failed to upload profile picture.";
        exit;
    }

    $sql = "UPDATE studentacc SET student_id=?, fname=?, lname=?, course=?, contact=?, age=?, birthdate=?, profile_picture=?, password=? WHERE email=?";
  
    $stmt = $db->prepare($sql);
    $stmt->bind_param("ssssssssss", $student_id, $firstName, $lastName, $course, $contact, $age, $birthdate, $target_file, $pass, $email);
    $result = $stmt->execute();

    if ($result) {
       
        $fetchSql = "SELECT * FROM studentacc WHERE email=?";
        $fetchStmt = $db->prepare($fetchSql);
        $fetchStmt->bind_param("s", $email);
        $fetchResult = $fetchStmt->execute();

        if ($fetchResult) {
            $fetchStmt->store_result();
            if ($fetchStmt->num_rows > 0) {
      
                $fetchStmt->bind_result($acc_id, $email, $student_id, $password, $fname, $lname, $course, $contact, $age, $birthdate, $id, $profile_picture, $code);
                $fetchStmt->fetch();

             
                $resultArray = array(
                    'acc_id' => $acc_id,
                    'email' => $email,
                    'student_id' => $student_id,
                    'password' => $password,
                    'fname' => $fname,
                    'lname' => $lname,
                    'course' => $course,
                    'contact' => $contact,
                    'age' => $age,
                    'birthdate' => $birthdate,
                    'id' => $id,
                    'profile_picture' => $profile_picture,
                    'code' => $code
                );

                echo json_encode($resultArray);
            } else {
                echo "Failed to fetch updated profile: No rows found.";
            }
        } else {
            echo "Failed to fetch updated profile: " . $fetchStmt->error;
        }

        $fetchStmt->close();
    } else {
        echo "Failed to update profile: " . $stmt->error;
    }

    $stmt->close();
    $db->close();
} else {
    echo "Invalid request method";
}
?>
