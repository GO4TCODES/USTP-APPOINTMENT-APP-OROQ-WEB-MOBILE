<?php
// Database connection parameters
require_once("MUDMSCON.php");

// Check the connection
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

// Get username from the Flutter app
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);
$username = $request->username;

// Fetch user profile data from the database
$sql = "SELECT name, email, contact FROM users WHERE username = '$username'";
$result = $con->query($sql);

if ($result->num_rows > 0) {
    // User profile found, retrieve data
    $row = $result->fetch_assoc();
    $profileData = array(
        "name" => $row["name"],
        "email" => $row["email"],
        "contact" => $row["contact"]
    );

    // Send JSON response back to the Flutter app
    header('Content-Type: application/json');
    echo json_encode($profileData);
} else {
    // User profile not found
    $response = array("message" => "Profile not found");
    header('Content-Type: application/json');
    echo json_encode($response);
}

// Close the database connection
$con->close();
?>
