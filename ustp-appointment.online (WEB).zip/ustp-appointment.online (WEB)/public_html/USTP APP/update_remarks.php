<?php
 require_once("MUDMSCON.php");
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
 
    $appointmentId = $_POST['appointmentId'];
    $remarks = $_POST['remarks'];

  


  
    if ($con->connect_error) {
        die("Connection failed: " . $con->connect_error);
    }

  
    $sql = "UPDATE appointments SET remarks = ? WHERE id = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("si", $remarks, $appointmentId);

    if ($stmt->execute()) {
      
        echo "Remarks updated successfully!";
     
    } else {
      
        echo "Error updating remarks: " . $stmt->error;
    }


    $stmt->close();
    $con->close();
} else {
 
    echo "Invalid request method.";
}   echo "success";
?>
