const sideMenu =document.querySelector("aside");
const menuBtn =document.querySelector("#menu-btn");
const closeBtn =document.querySelector("#close-btn");
const themeToggler =document.querySelector(".theme-toggler");
const bodyEl =document.querySelector('body');

//show sidebar
menuBtn.addEventListener('click', () =>{
    sideMenu.style.display ='block';
})
//close sidebar
closeBtn.addEventListener('click', () =>{
    sideMenu.style.display ='none';
})

