<?php
header('Content-Type: application/json');

$data = json_decode(file_get_contents("php://input"));

if (!$data) {
    echo json_encode(["message" => "Invalid request data"]);
    exit; 
}

$email = $data->email;
$password = $data->password;

$conn = new mysqli("localhost", " ", " ", " "); 

if ($conn->connect_error) {
    echo json_encode(["message" => "Database connection failed"]);
    exit;
}

$stmt = $conn->prepare("SELECT * FROM studentacc WHERE email = ? AND password = ?");
$stmt->bind_param("ss", $email, $password);
$stmt->execute();
$result = $stmt->get_result();

$fname = "";
$lname = "";
$course = "";

if ($result->num_rows == 1) {

    $row = $result->fetch_assoc();
    $email = $row['email'];
    $fname = $row['fname'];
    $lname = $row['lname'];
    $course = $row['course'];
}

$stmt->close();
$conn->close();

if ($fname !== "" && $lname !== "" && $course !== "") {
 
    $response = array(
        "message" => "Login successful",
        "email" => $email,
        "fname" => $fname,
        "lname" => $lname,
        "course" => $course
    );

    echo json_encode($response);
} else {
    echo json_encode(["message" => "Login failed"]);
}
?>
