<?php
// Database connection detailsmysqli = new mysqli("localhost", "u694644493_ustpapp", "968MxqQc7@0V", "u694644493_ustpapp");
$host = 'localhost';
$username = ' ';
$password = ' ';
$database = ' ';

// Email to check
$email = $_GET['email'];

// Create a database connection
$mysqli = new mysqli($host, $username, $password, $database);

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// SQL query to check if the email exists in your database
$query = "SELECT COUNT(*) as count FROM studentacc WHERE email = ?";

if ($stmt = $mysqli->prepare($query)) {
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $count = $row['count'];

    if ($count > 0) {
        echo 'true'; // Email exists in the database
    } else {
        echo 'false'; // Email doesn't exist in the database
    }

    $stmt->close();
} else {
    echo 'false'; // Query execution failed
}

$mysqli->close();
?>
