<?php
require_once("MUDMSCON.php");
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

// Define the query to select data from the notavailabledays table
$sql = "SELECT date, title, description FROM notavailabledays"; // Include title and description

$result = $con->query($sql);

if ($result->num_rows > 0) {
    $events = array();


    while ($row = $result->fetch_assoc()) {
        $date = $row["date"];
        $title = $row["title"]; 
        $description = $row["description"]; 
        $events[] = array("date" => $date, "title" => $title, "description" => $description);
    }


    header('Content-Type: application/json');
    echo json_encode($events);
} else {
    echo "No data found";
}


$con->close();
?>
