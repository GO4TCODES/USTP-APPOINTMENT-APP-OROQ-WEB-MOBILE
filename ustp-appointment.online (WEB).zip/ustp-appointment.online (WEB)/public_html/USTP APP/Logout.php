<?php
    
    session_start();
    unset($_SESSION['username']);
    unset($_SESSION['user']);
    session_destroy();
    header("location:Login.php");


    
?>