
<?php

session_start();

if (!isset($_SESSION['username']) && !isset($_SESSION['password']) ) {
  $_SESSION['msg'] = "You have to log in first";
  header('location: Login.php');
}
              include_once 'MUDMSCON.php';
              $query ="SELECT * FROM createdaccounts";
              $result = mysqli_query($con,$query);
            
              $query6 ="SELECT * FROM `notavailabledays`";
              $result6=  mysqli_query($con,$query6);

              ?>

<!DOCTYPE html>
<html lang="en">
<head>
    
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <link rel="icon" href="./images/USTP.png" type="image/ico" sizes="16x16">
  <title>Manage Staff</title>

        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">


        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css">
        <link rel="stylesheet" type="text/css" href="bootstrap-4.0.0-dist/js/bootstrap.min.js"/>
        <link rel="stylesheet" type="text/css" href="bootstrap-4.0.0-dist/css/bootstrap.min.css"/>
        <link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css"/>
  <!--MATERIAL CDN-->


  <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round"
  rel="stylesheet">

  <!--STYLESHEET-->
  <link rel="stylesheet" href="Style.css">      
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>

</head>
<body>
        <!-- Logout Confirmation Modal -->
<div class="modal fade" id="logoutConfirmationModal" tabindex="-1" role="dialog" aria-labelledby="logoutConfirmationModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="logoutConfirmationModalLabel">Logout Confirmation</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Are you sure you want to logout?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <a href="Logout.php" class="btn btn-primary">Logout</a>
            </div>
        </div>
    </div>
</div>

  <!-- Delete Modal -->
<div class="modal fade" id="deletemodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Delete User Account?</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="Delete.php" method="POST">
          <div class="modal-body">
           <input type="hidden" name="deleteid" id="deleteid">
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" name="deleteuser" class="btn btn-primary" >Confirm</button>
          </div>
      </form>
      
    </div>
  </div>
</div>


<!--Edit Modal-->
  <div class="modal fade" id="editmodal" tabindex="-1" role="form" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit User</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="Update.php" method="POST">
          <div class="modal-body">
            <div class="Form-group"> 
               <input type="hidden" name="id" id="id">
            </div>
            <div class="Form-group"> 
              <label>Username</label>
              <input type="text" name="username" id="username" class="form-control" placeholder="Username">
            </div>
            <div class="Form-group"> 
              <label>Password</label>
              <input type="text" name="password" id="password" class="form-control" placeholder="Enter password">
            </div>
 
            <br>
            <div class="Form-group">
              <label>Role</label>
                                    <select name="role" id="role" style="background-color: #f5bc45; border-radius: 5px; opacity: 80%;">
                                        <option value="">No Changes</option>
                                        <option value="Staff">Staff</option>
                                        <option value="Others">Others</option>
                                    </select>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-mdb-dismiss="modal">Close</button>
            <button type="submit" name="updateuser" class="btn btn-primary">Save changes</button>
          </div>
      </form>
      
    </div>
  </div>
</div>
 <!-- Create Modal -->
<div class="modal fade" id="createmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Create User</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="Insert.php" method="POST" enctype="multipart/form-data">
          <div class="modal-body">
            <div class="Form-group"> 



              <input type="hidden" name="id" id="id" class="form-control">
              <label>Username</label>
              <input type="text" name="username" id="username" class="form-control" placeholder="Username">
              <label>Password</label>
              <input type="text" name="password" id="password" class="form-control" placeholder="Password">

            </div> <br>
            <div class="Form-group">
              <label>Role</label>
                                    <select name="role" id="role" style="background-color: #f5bc45; border-radius: 5px; opacity: 80%;">
                                        <option value="">No Changes</option>
                                        <option value="Staff">Staff</option>
                                        <option value="Others">Others</option>
                                    </select>
            </div>
       
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" name="insertuser" class="btn btn-primary" >Confirm</button>
          </div>
      </form>
      
    </div>
  </div>
</div>
</div>
<div class="container-fluid">
  <div class="row">
    <aside class="col-md-2">
      <!-- Sidebar content goes here -->
      <div class="top">
        <div class="logo">
          <img src="./images/USTP.png">
          <h1><span class="danger"></span></h1>
        </div>
        <div class="close" id="close-btn">
          <span class="material-icons-round"> close </span>
        </div>
      </div>
      <div class="sidebar">
        <a href="Home.php" >
          <span class="material-icons-round">dashboard</span>
          <h3> Dashboard </h3>
        </a>
        
        <a href="Appointments Admin.php" >
          <span class="material-icons-round">description</span>
          <h3> Appointment </h3>
        </a>
        <a href="Availability.php" >
          <?php
           if ($result6) {
             $notif = mysqli_num_rows($result6);
             mysqli_free_result($result6);
           }
          ?>       
          <span class="material-icons-round">check</span>
          <h3> Availability </h3>
          <span class="request-count"><?php echo $notif; ?></span>
        </a>
        <!--
        <a href="ManageD.php" >
          <span class="material-icons-round"> description</span>
          <h3> Manage Documents </h3>
        </a>
          -->
        <a href="Transaction Log.php">
          <span class="material-icons-round"> report</span>
          <h3> Transaction Logs </h3>
        </a>
        <a href="Manageusers.php" class="active">
          <span class="material-icons-round"> settings</span>
          <h3> Manage Staff</h3>
        </a>
        <a href="#" data-toggle="modal" data-target="#logoutConfirmationModal">
            <span class="material-icons-round">power_settings_new</span>
            <h3>Logout</h3>
        </a>
      </div>
    </aside>


      <!-------END OF ASIDE------>
      <main class="col-md-5">
        
         
        <script type="text/javascript" src="DataTables/datatables.min.js"></script>

        <div>
           <BR>
           <BR> 
           <BR>
           <BR>
          <h4>MANAGE STAFF</h4>


        </div>
       

        <br>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script type="text/javascript" src="DataTables/datatables.min.js"></script>
        <button type="button" class="btn add" style="float:right; background-color: #f5bc45;">Add Users</button>
       
 
            <div class="table-responsive">
                <table id="request_data" class="table table-borderless" style="font-size: 14px; width: 100%;">
                    <thead>
                        <tr>
                            <td>User ID</td>
                            <td>Username</td>
                            <td>Password</td>
                            <td>Role</td>
                            <td>Manage</td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td></td>
                        </tr>
                    </thead>
                    <?php
                    while($row = mysqli_fetch_array($result))
                    {
                        echo '
                        <tr tr-default>
                            <td>'.$row["id"].'</td>
                            <td>'.$row["username"].'</td>
                            <td>'.$row["password"].'</td>
                            <td>'.$row["role"].'</td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td><button type="button" class="btn btn-success edit" style="font-size: 11px;"> Edit </button> </td>
                            <td><button type="button" class="btn btn-danger delete" style="font-size: 11px;"> Delete </button> </td>
                        </tr>
                        ';
                    }
                    ?>
                </table>
            </div>
       



           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script> 
           <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>  
           <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script> 
           <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
           <script src="https://cdn.datatables.net/plug-ins/1.11.1/features/fuzzySearch/dataTables.fuzzySearch.js"></script>
    </main> 
   <!-------------------END OF MAIN---------------->  
  <!-------------------TOP RIGHT SIDE, TOGGLE DARK AND LIGHT MODE---------------->  
  <div class="col-md-1">
    <div class="right">
      <div class="top">
        <button id="menu-btn">
          <span class="material-icons-round">menu</span>
        </button>
        
       
      
      <script src="./index.js"></script>
</body>
</html>

<script>
    $(document).ready(function() {
        var table = $('#request_data').DataTable({
            fuzzySearch: { toggleSmart: true, threshold: 0.6 },
            "autoWidth": true,
            "paging": true,
            "scrollY": 250,
            "scrollX": true, // Enable horizontal scrolling
        });

        // Set DataTable to use the full width of the container
        table.columns.adjust().draw();
    });
</script>
 
<script>  
 $(document).ready(function(){  
      $('.edit').on('click', function() {

          $('#editmodal').modal('show');
            $tr = $(this).closest('tr');
            var data = $tr.children("td").map(function() {
              return $(this).text();
            }).get();

              console.log(data);

              $('#id').val(data[0]);
              $('#username').val(data[1]);
              $('#password').val(data[2]);
              $('#role').val(data[3]);

       


    });
    //IT STARTS HERE (CLOSE FUNCTION)
    $('.close,.btn').click(function() {
        $( "#editmodal" ).modal('hide');
      });
    //IT ENDS HERE (CLOSE FUNCTION)

  });  

</script>
<script>  
 $(document).ready(function(){  
      $('.add').on('click', function() {
          $('#createmodal').modal('show');
            $tr = $(this).closest('tr');
            var data = $tr.children("td").map(function() {
              return $(this).text();
            }).get();

              console.log(data);

         
    });

        //IT STARTS HERE (CLOSE FUNCTION)
    $('.close,.btn').click(function() {
        $( "#createmodal" ).modal('hide');
      		});
    //IT ENDS HERE (CLOSE FUNCTION)
  			});  
</script>

<script>  
 $(document).ready(function(){  
      $('.delete').on('click', function() {
          $('#deletemodal').modal('show');
            $tr = $(this).closest('tr');
            var data = $tr.children("td").map(function() {
              return $(this).text();
            }).get();

              console.log(data);

              $('#deleteid').val(data[0]);

         
    });

        //IT STARTS HERE (CLOSE FUNCTION)
    $('.close,.btn').click(function() {
        $( "#deletemodal" ).modal('hide');
      });
    //IT ENDS HERE (CLOSE FUNCTION)
  });  

 </script>
 
