            <?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

require 'Exception.php';
require 'PHPMailer.php';
require 'SMTP.php';

$mail = new PHPMailer(true);

// SMTP server settings
$mail->IsSMTP();
$mail->Host = 'smtp.hostinger.com';
$mail->Port = //
$mail->SMTPAuth = true;
$mail->SMTPSecure = 'ssl'; 
$mail->Username = //
$mail->Password = // Your email password

require_once("MUDMSCON.php");

if (isset($_POST['update'])) {
    $appointmentId = $_POST['appointmentId'];
    $requestStatus = $_POST['requestStatus'];
    $documentStatus = $_POST['documentStatus'];
    $overallstatus = $_POST['overallstatus'];
    $username = $_SESSION['username'];


    $updateSql = "UPDATE appointments SET status = '$requestStatus', docstatus = '$documentStatus', overall_status = '$overallstatus', staff = '$username' WHERE id = $appointmentId";
              
              
    if ($con->query($updateSql) === TRUE) {
   // Second update to set overall_status to 'Completed'
    $completeSql = "UPDATE appointments 
                    SET overall_status = 'Completed' 
                    WHERE id = $appointmentId 
                    AND status = 'Approved' 
                    AND docstatus = 'Ready for Pickup'";

    // Execute the second update
    if ($con->query($completeSql) === TRUE) {
        echo "Appointment updated successfully";
    } else {
        echo "Error updating overall_status: " . $con->error;
    }  
    $rejectSql = "UPDATE appointments 
                    SET overall_status = 'Rejected' 
                    WHERE id = $appointmentId 
                    AND status = 'Rejected' 
                    AND docstatus = 'Rejected'";

    // Execute the second update
    if ($con->query($completeSql) === TRUE) {

    } else {
        echo "Error updating overall_status: " . $con->error;
    }    // Execute the second update
    if ($con->query($rejectSql) === TRUE) {
 $rejectSql = "DELETE appointments 
                    WHERE id = $appointmentId 
                 ";
    } else {
        echo "Error updating overall_status: " . $con->error;
    }
        $fetchStudentSql = "SELECT s.fname AS FirstName, s.lname AS LastName, s.contact AS Contact, s.age AS Age, 
            s.birthdate AS DateOfBirth, s.email AS Email, s.student_id AS IDNumber, s.course AS CourseYear, 
            a.dateofrequest AS DateOfRequest, a.title AS Title, a.overall_status AS overallstatus
            FROM studentacc s
            INNER JOIN appointments a ON a.email = s.email
            WHERE a.id = $appointmentId";
        $studentResult = $con->query($fetchStudentSql);

        if ($studentResult->num_rows > 0) {
            $studentRow = $studentResult->fetch_assoc();
            $studentName = $studentRow['FirstName'] . ' ' . $studentRow['LastName'];
            $studentCourse = $studentRow['CourseYear'];
            $studentEmail = $studentRow['Email'];
            $dateRequested = $studentRow['DateOfRequest'];
            $title = $studentRow['Title'];

        
            $emailSubject = 'Appointment Status Update';
            $emailMessage = "
Dear $studentName,

Your appointment status has been updated. Here are the details:
- Appointment ID: $appointmentId
- Document Requested: $title
- Request Status: $requestStatus
- Document Status: $documentStatus
- Date Requested: $dateRequested
- Course & Year: $studentCourse


Appointment Overall Status: $overallstatus

Best regards,
USTP-APP OROQUIETA
";


       
            $mail->setFrom('ustp-oro@ustp-appointment.online', 'USTP-APP OROQUIETA'); 
            $mail->addAddress($studentEmail);

            $mail->Subject = $emailSubject;
            $mail->Body = $emailMessage;

            try {
   
                $mail->send();
                echo 'Email sent successfully';
            } catch (Exception $e) {
                echo 'Email could not be sent. Mailer Error: ' . $mail->ErrorInfo;
            }

   
            echo "<p class='alert alert-success'>Status updated successfully. Email notification sent to the student.</p>";
        } else {
            echo "<p class='alert alert-danger'>Error fetching student's information from the database.</p>";
        }
    } else {
        echo "<p class 'alert alert-danger'>Error updating status: " . $con->error . "</p>";
    }
} ?>