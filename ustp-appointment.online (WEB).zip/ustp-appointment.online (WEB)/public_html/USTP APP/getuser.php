<?php

require_once("MUDMSCON.php");   
$email = $_GET['email'];


$sql = "SELECT student_id, fname, lname, course, profile_picture FROM studentacc WHERE email = '$email'";
$result = mysqli_query($con, $sql);

if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $response = $row;
} else {
    $response = array('error' => 'User not found');
}

header('Content-Type: application/json');
echo json_encode($response);
?>
