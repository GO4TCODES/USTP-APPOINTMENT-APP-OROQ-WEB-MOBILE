<?php

session_start();


if(isset($_SESSION['username'])){
    $username = $_SESSION['username'];
} else {

    header("Location: Login.php");
    exit();
}
if (!isset($_SESSION['username']) && !isset($_SESSION['password']) ) {
  $_SESSION['msg'] = "You have to log in first";
  header('location: Login.php');
}
          include_once 'MUDMSCON.php';
              $query ="SELECT * FROM appointments";
              $result = mysqli_query($con,$query);

            //  $query2 ="SELECT Request.*,Documents.* FROM Request, Documents WHERE Request.rid = Documents.rid ORDER BY added DESC LIMIT 9";
              //$result2= mysqli_query($con,$query2);
              $query2 ="SELECT request.*,documents.* FROM request, documents WHERE request.rid = documents.rid ORDER BY added DESC LIMIT 9";
              $result2= mysqli_query($con,$query2);

              $query3 ="SELECT * FROM `createdaccounts`";
              $result3= mysqli_query($con,$query3);

              $query4 ="SELECT * FROM request";
              $result4= mysqli_query($con,$query4);

              $query5 ="SELECT * FROM `notavailabledays`";
              $result5= mysqli_query($con,$query5);
              
              $query6 ="SELECT * FROM `notavailabledays`";
              $result6=  mysqli_query($con,$query6);
              ?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="icon" href="./images/USTP.png" type="image/ico" sizes="16x16">
  <title>USTP Appointment System</title>


  <!--MATERIAL CDN-->
 <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.css">
  <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.js"></script>
  <link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css"/>

  <!--STYLESHEET-->
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round"
  rel="stylesheet">

 <link rel="stylesheet" href="Style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
      <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
</head>

<body>
  
<!-- Logout Confirmation Modal -->
<div class="modal fade" id="logoutConfirmationModal" tabindex="-1" role="dialog" aria-labelledby="logoutConfirmationModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="logoutConfirmationModalLabel">Logout Confirmation</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Are you sure you want to logout?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <a href="Logout.php" class="btn btn-primary">Logout</a>
            </div>
        </div>
    </div>
</div>
<div class="container-fluid">
  <div class="row">
    <aside class="col-md-2">
      <!-- Sidebar content goes here -->
      <div class="top">
        <div class="logo">
          <img src="./images/USTP.png">
          <h1><span class="danger"></span></h1>
        </div>
        <div class="close" id="close-btn">
          <span class="material-icons-round"> close </span>
        </div>
      </div>
      <div class="sidebar">
        <a href="Home.php" class="active">
          <span class="material-icons-round">dashboard</span>
          <h3> Dashboard </h3>
        </a>
        
        <a href="Appointments Admin.php" >
          <span class="material-icons-round">description</span>
          <h3> Appointment </h3>
        </a>
        <a href="Availability.php" >
          <?php
           if ($result6) {
             $notif = mysqli_num_rows($result6);
             mysqli_free_result($result6);
           }
          ?>       
          <span class="material-icons-round">check</span>
          <h3> Availability </h3>
          <span class="request-count"><?php echo $notif; ?></span>
        </a>
        <!--
        <a href="ManageD.php" >
          <span class="material-icons-round"> description</span>
          <h3> Manage Documents </h3>
        </a>
          -->
        <a href="Transaction Log.php">
          <span class="material-icons-round"> report</span>
          <h3> Transaction Logs </h3>
        </a>
        <a href="Manageusers.php">
          <span class="material-icons-round"> settings</span>
          <h3> Manage Staff</h3>
        </a>
       <a href="#" data-toggle="modal" data-target="#logoutConfirmationModal">
            <span class="material-icons-round">power_settings_new</span>
            <h3>Logout</h3>
        </a>

      </div>
    </aside>


      <!-------END OF ASIDE------>
      <main class="col-md-8">
        
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
        <script type="text/javascript" src="DataTables/datatables.min.js"></script>
        <br>   <br>   <br>   <br>
        <h4>DASHBOARD</h4>
         

          <div class="insights">


    <div class="Documents" id="totalAppointmentLink">
            <span class="material-icons-round">folder</span>
            <div class="middle">
                <div class="left">
                    <h3>Total Appointment</h3>
                    <br>
                    <?php
                        if ($result6) {
                            $row2 = mysqli_num_rows($result);
                            mysqli_free_result($result4);
                        }
                    ?>       
                    <h1><?php echo $row2; ?></h1>
                </div>
            </div>
        
    </div>


<script>
    document.getElementById("totalAppointmentLink").addEventListener("click", function(event) {
        event.preventDefault(); 
        window.location.href = "Appointments Admin.php";
    });
</script>

          <div class="Request" id="totalStaffLink" style="cursor: pointer;">
    <span class="material-icons-round">person</span>
    <div class="middle">
        <div class="left">
            <h3>Total Staff</h3>
            <br>
            <?php
                if ($result3) {
                    $row1 = mysqli_num_rows($result3);
                    mysqli_free_result($result3);
                }
            ?>       
            <h1><?php echo $row1; ?></h1>
        </div>
    </div>
</div>

<script>
    document.getElementById("totalStaffLink").addEventListener("click", function() {

        window.location.href = "Manageusers.php";
    });
</script>

            <!-------END OF TOTAL REQUEST------>
          
          <!-------END OF TOTAL DOCUMENTS------>
          

     
          <div class="Released" id="notAvailableDaysLink" style="cursor: pointer;">
    <span class="material-icons-round">task</span>
    <div class="middle">
        <div class="left">
            <h3>Not Available Days</h3>
            <br>
            <?php
                if ($result3) {
                    $row3 = mysqli_num_rows($result5);
                    mysqli_free_result($result5);
                }
            ?>       
            <h1><?php echo $row3; ?></h1> 
        </div>
    </div>
</div>

<script>
    document.getElementById("notAvailableDaysLink").addEventListener("click", function() {
        window.location.href = "Availability.php";
    });
</script>

       
        <!-------END OF TOTAL INSIGHTS------>
        
        
        
       <!---------END OF RECENT UPLOAD TABLE------->
           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script> 
           <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>  
           <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script> 
           <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
           <br>
           <br>
           <br>
        

       </main> 
     <!-------------------TOP RIGHT SIDE, TOGGLE DARK AND LIGHT MODE---------------->  
       <!-------------------TOP RIGHT SIDE, TOGGLE DARK AND LIGHT MODE---------------->  
    <div class="col-md-2">
    <div class="right">
      <div class="top">
        <button id="menu-btn">
          <span class="material-icons-round">menu</span>
        </button>
        
        <div class="profile">
          <div class="info">

            <p>Hello, 

              <b><?php echo $_SESSION['username']?></b></p>
            <small class="text-muted"></small>
          </div>
          <div class="profile-photo">
          <span class="material-icons-round">account_circle</span>
        </div>
        </div>
      </div>
      <!--END OF TOP-->
      
      <div class="recent-request">
        <h2>Staff Recent Acivities</h2>
        <div class="r-request">
          <div class="request">

            <?php
              if (mysqli_num_rows($result) > 0) {
            ?>
<br>
            
            <table>
              <thead>
                <tr>

                  <th>Staff</th>
                  <th>Document Requested</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                    <?php
                $i=0;
                while($row = mysqli_fetch_array($result)) {
                ?>
                  <td><?php echo $row["staff"]; ?></td>
                  <td><?php echo $row["title"]; ?></td>
                  <td><?php echo $row["status"]; ?></td>
                </tr>
              
              </tbody>

              <?php
              
                }
                ?>
            </table>
            <a href="Home.php">Show All</a>
                       <?php
          }
          else
          {
              echo "No result found";
          }
          ?>  
          </div>
        </div>
      </div>
    </div>

  </div>
        </div>
  <script src="./index.js"></script>


</body>
</html>

<script>  
 $(document).ready(function(){  
      $('.add').on('click', function() {
          $('#createmodal').modal('show');
            $tr = $(this).closest('tr');
            var data = $tr.children("td").map(function() {
              return $(this).text();
            }).get();

              console.log(data);

         
    });
    $('.close,.btn').click(function() {
        $( "#createmodal" ).modal('hide');
      });
  });  

 </script>

  <script>  
 $(document).ready(function(){  
      $('.upload').on('click', function() {
          $('#uploadmodal').modal('show');
            $tr = $(this).closest('tr');
            var data = $tr.children("td").map(function() {
              return $(this).text();
            }).get();

              console.log(data);


         
    });
    $('.close,.btn').click(function() {
        $( "#uploadmodal" ).modal('hide');
      });
  });  
 

 </script>