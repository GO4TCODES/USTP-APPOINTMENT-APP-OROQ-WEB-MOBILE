<?php
require_once("MUDMSCON.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['appointmentId']) && isset($_POST['newStatus']) && isset($_POST['statusType'])) {
        $appointmentId = $_POST['appointmentId'];
        $newStatus = $_POST['newStatus'];
        $statusType = $_POST['statusType'];

        // Validate and sanitize the data to prevent SQL injection (please use prepared statements)
        $appointmentId = mysqli_real_escape_string($con, $appointmentId);
        $newStatus = mysqli_real_escape_string($con, $newStatus);
        $statusType = mysqli_real_escape_string($con, $statusType);

        // Update the status in the database
        $updateSql = "UPDATE appointments SET $statusType = '$newStatus' WHERE id = $appointmentId";

        if ($con->query($updateSql) === TRUE) {
            echo "Status updated successfully";
        } else {
            echo "Error updating status: " . $con->error;
        }

        // Close the database connection
        $con->close();
    } else {
        echo "Invalid data received";
    }
} else {
    echo "Invalid request method";
}
?>
