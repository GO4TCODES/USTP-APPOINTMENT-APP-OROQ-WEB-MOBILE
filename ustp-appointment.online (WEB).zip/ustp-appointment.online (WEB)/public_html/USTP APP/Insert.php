<?php

    require_once("MUDMSCON.php");
ini_set('display_errors', 1);
error_reporting(E_ALL);


  if(isset($_POST['submit2']))
    {
        if(empty($_POST['student_id']) || empty($_POST['fname']) || empty($_POST['mname']) || empty($_POST['lname']) || empty($_POST['type']) || empty($_POST['course']))
        {
            header("location: Appointment Users.php" );
            echo ' Please Fill in the Blanks ';
        }
        else
        {   $rid =0;

            $student_id = $_POST['student_id'];
            $fname = $_POST['fname'];
            $mname = $_POST['mname'];
            $lname = $_POST['lname'];
            $type = $_POST['type'];
            $course = $_POST['course'];
            $status = "Pending";
            $doc_status = "❌ No File";
            $rdate = date("Y-m-d H:i:s"); 
            $query = "INSERT INTO `Request` (`rid`,`student_id`,`fname`, `mname`, `lname`, `type`, `course`, `status`, `rdate`,doc_status) VALUES ('$rid','$student_id','$fname','$mname', '$lname', '$type', '$course','$status', '$rdate', '$doc_status')";
            $result = mysqli_query($con,$query);

            if($result)
                {
                     header("location: Appointment Users.php" );
                }
            else
                {
                    echo '  Please Check Your Query ';
                }
        }
    }

    if(isset($_POST['adminsubmit']))
    {
        if(empty($_POST['student_id']) || empty($_POST['fname']) || empty($_POST['mname']) || empty($_POST['lname']) || empty($_POST['type']) || empty($_POST['course']))
        {
            header("location: Availability.php" );
            echo ' Please Fill in the Blanks ';
        }
        else
        {   $rid =0;

            $student_id = $_POST['student_id'];
            $fname = $_POST['fname'];
            $mname = $_POST['mname'];
            $lname = $_POST['lname'];
            $type = $_POST['type'];
            $course = $_POST['course'];
            $status = "Pending";
            $doc_status = "❌ No File";
            $rdate = date("Y-m-d H:i:s"); 
            $query = "INSERT INTO `Request` (`rid`,`student_id`,`fname`, `mname`, `lname`, `type`, `course`, `status`, `rdate`,doc_status) VALUES ('$rid','$student_id','$fname','$mname', '$lname', '$type', '$course','$status', '$rdate', '$doc_status')";
            $result = mysqli_query($con,$query);

            if($result)
                {
                     header("location: Availability.php" );
                }
            else
                {
                    echo '  Please Check Your Query ';
                }
        }
    }
    

    if(isset($_POST['rsubmit']))
    {
        if(empty($_POST['student_id']) || empty($_POST['fname']) || empty($_POST['mname']) || empty($_POST['lname']) || empty($_POST['type']) || empty($_POST['course']))
        {
            header("location: Availability.php" );
            echo ' Please Fill in the Blanks ';
        }
        else
        {   $rid =0;

            $student_id = $_POST['student_id'];
            $fname = $_POST['fname'];
            $mname = $_POST['mname'];
            $lname = $_POST['lname'];
            $type = $_POST['type'];
            $course = $_POST['course'];
            $status = "Pending";
            $doc_status = "❌ No File";
            $rdate = date("Y-m-d H:i:s"); 
            $query = "INSERT INTO `Request` (`rid`,`student_id`,`fname`, `mname`, `lname`, `type`, `course`, `status`, `rdate`,doc_status) VALUES ('$rid','$student_id','$fname','$mname', '$lname', '$type', '$course','$status', '$rdate', '$doc_status')";
            $result = mysqli_query($con,$query);

            if($result)
                {
                     header("location: android demo .php" );
                }
            else
                {
                    echo '  Please Check Your Query ';
                }
        }
    }
    

     if(isset($_POST['insertuser']))
    {
        if(empty($_POST['username']) || empty($_POST['password']) || empty($_POST['role']))
        {
            header("location: Manageusers.php" );
            echo ' Please Fill in the Blanks ';
        }
        else
        {   $id =0;

            $username = $_POST['username'];
            $password = $_POST['password'];
            $role = $_POST['role'];
            $query = "INSERT INTO `createdaccounts` (`id`,`username`,`password`, `role`) VALUES ('$id','$username','$password','$role')";
            $result = mysqli_query($con,$query);

            if($result)
                {
                     header("location: Manageusers.php" );
                }
            else
                {
                    echo '  Please Check Your Query ';
                }
        }
    }

?>