<?php

    require_once("MUDMSCON.php");
ini_set('display_errors', 1);
error_reporting(E_ALL);


     if(isset($_POST['insertuser']))
    {
        if(empty($_POST['username']) || empty($_POST['password']) || empty($_POST['role']))
        {
            header("location: Manageusers.php" );
            echo ' Please Fill in the Blanks ';
        }
        else
        {   $id =0;

            $username = $_POST['username'];
            $password = $_POST['password'];
            $role = $_POST['role'];
            $query = "INSERT INTO `createdaccounts` (`id`,`username`,`password`, `role`) VALUES ('$id','$username','$password','$role')";
            $result = mysqli_query($con,$query);

            if($result)
                {
                     header("location: Manageusers.php" );
                }
            else
                {
                    echo '  Please Check Your Query ';
                }
        }
    }

?>