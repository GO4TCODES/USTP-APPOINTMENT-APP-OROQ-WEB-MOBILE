
<?php

session_start();

if (!isset($_SESSION['user'])) {
  $_SESSION['msg'] = "You have to log in first";
  session_destroy();
  header('location: Login.php');
  
}

if (isset($_GET['logout'])) {
  session_destroy();
  unset($_SESSION['username']);
  header("location: Login.php");

}
              include_once 'MUDMSCON.php';

              $query ="SELECT * FROM request ORDER BY rdate DESC LIMIT 5";
              $result = mysqli_query($con,$query);

              $query ="SELECT * FROM request WHERE doc_status='❌ No File'" ;
              $result = mysqli_query($con,$query);

              $query2 ="SELECT request.*,documents.* FROM request, documents WHERE request.rid = documents.rid";
              $result2= mysqli_query($con,$query2);

              $query6 ="SELECT * FROM `request` WHERE status='Pending'  
              ORDER BY `request`.`status` ASC";
              $result6=  mysqli_query($con,$query6);


              ?>

<!DOCTYPE html>
<html lang="en">
<head>
    
<meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" href="./images/USTP.png" type="image/ico" sizes="16x16">
  <title>USTP Appointment System</title>

  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css">
  <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.js"></script>
  <link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css"/>
  <!--MATERIAL CDN-->


  <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round"
  rel="stylesheet">

  <!--STYLESHEET-->
  <link rel="stylesheet" href="Style.css">

</head>
<body>

 <!-- Delete Modal -->
 <div class="modal fade" id="deletemodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Delete Request?</h5>
          <button type="button" class="close" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">&times;</span>
          </button>
        </div>
        <form action="Delete.php" method="POST">
            <div class="modal-body">
             <input type="hidden" name="deleteid" id="deleteid">
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
              <button type="submit" name="deletedata2" class="btn btn-primary" >Confirm</button>
            </div>
        </form>
        
      </div>
    </div>
  </div>

  <!--Edit Modal-->
  <div class="modal fade" id="editmodal" tabindex="-1" role="form" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Edit Request</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="Update.php" method="POST">
          <div class="modal-body">
            <div class="Form-group"> 
             
              <input type="hidden" name="updateid" id="updateid">
            </div>
            <div class="Form-group"> 
              <label>Student ID</label>
              <input type="text" name="student_id" id="student_id" class="form-control" placeholder="Enter Student ID">
            </div>
            <div class="Form-group"> 
              <label>First Name</label>
              <input type="text" name="fname" id="fname" class="form-control" placeholder="Enter Firstname">
            </div>
            <div class="Form-group"> 
              <label>Middle Name</label>
              <input type="text" name="mname" id="mname" class="form-control" placeholder="Enter Middlename">
            </div>
            <div class="Form-group"> 
              <label>Last Name</label>
              <input type="text" name="lname" id="lname" class="form-control" placeholder="Enter Lastname">
            </div>
            <br>
            <div class="">
              <label>What document type is requested?</label>
                                    <select name="type" id="type" style="background-color: #f5bc45; border-radius: 5px; opacity: 80%;">
                                         <option value="">SELECT</option>
                                        <option value="TOR">TOR</option>
                                        <option value="Cards">Cards</option>
                                        <option value="Diploma">Diploma</option>
                                        <option value="SO">SO</option>
                                        <option value="Form 137">Form 137</option>
                                        <option value="Honorable Dismissal">Honorable Dismissal</option>
                                        <option value="Good Moral">Good Moral</option>
                                    </select>
            </div>
            <br>
            <div class="Form-group">
              <label>Course & Year</label>
                                    <select name="course" id="course" style="background-color: #f5bc45; border-radius: 5px; opacity: 80%;">
                                        <option value="">No Changes</option>
                                        <option value="BSIT">BSIT</option>
                                        <option value="BSBA">BSBA</option>
                                        <option value="BSED">BSED</option>
                                        <option value="CRIM">CRIM</option>
                                        <option value="HIGHSCHOOL">HIGHSCHOOL</option>
                                        <option value="ELEMENTARY">ELEMENTARY</option>
                                    </select>
                                   
            </div>
            <div class="Form-group">
              <br>
                <label>Request Date</label>
                                <input type="date" class="form-control mb-3" name="rdate" id="rdate" value="">
                <label>Date Released</label>
                                <input type="date" class="form-control mb-3" name="released" id="released" value="">
            </div>
            
         
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-mdb-dismiss="modal">Close</button>
            <button type="submit" name="updatedata_manageR" class="btn btn-primary" >Save changes</button>
          </div>
      </form>
      
    </div>
  </div>
</div>

<!-- Create Modal -->
<div class="modal fade" id="createmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Create Request</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <form action="Insert.php" method="POST" enctype="multipart/form-data">
          <div class="modal-body">
            <div class="Form-group"> 

              <label>Student ID</label>
              <input type="text" name="student_id" id="student_id" class="form-control" placeholder="Student ID">
              <label>First Name</label>
              <input type="text" name="fname" id="fname" class="form-control" placeholder="First name">
              <label>Middle Name</label>
              <input type="text" name="mname" id="mname" class="form-control" placeholder="Middle name">
              <label>Last Name</label>
              <input type="text" name="lname" id="lname" class="form-control" placeholder="Last name">

            </div> <br>
            <div class="Form-group">
              <label>Course & Year (click ->)</label>
                                    <select name="course" id="course" style="background-color: #f5bc45; border-radius: 5x;">
                                    <option value="">No Changes</option>
                                        <option value="BSIT">BSIT</option>
                                        <option value="BFPT">BFPT</option>
                                        <option value="BTLED">BTLED</option>
                                    
                                    </select>
            </div>
           <div class="Form-group">
              <label>What document type is requested?</label>
                                    <select name="type" id="type" style="background-color: #f5bc45; border-radius: 5px;">
                                    <option value="">SELECT</option>
                                        <option value="TOR">TOR</option>
                                        <option value="Diploma">Diploma</option>
                                        <option value="Authentication">Authentication</option> 
                                        <option value="Honorable Dismissal">Honorable Dismissal</option>
                                        <option value="Good Moral">Good Moral</option>
                                    </select>
            </div>                     
          </div>
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            <button type="submit" name="adminsubmit" class="btn btn-primary" >Confirm</button>
          </div>
      </form>
      
    </div>
  </div>
</div>
<div class="container-fluid">
  <div class="row">
    <aside class="col-md-2">
      <!-- Sidebar content goes here -->
      <div class="top">
        <div class="logo">
       <img src="./images/USTP.png">
          <h1><span class="danger"></span></h1>
        </div>
        <div class="close" id="close-btn">
          <span class="material-icons-round"> close </span>
        </div>
      </div>
      <div class="sidebar">
        <a href="Home.php" >
          <span class="material-icons-round">dashboard</span>
          <h3> Dashboard </h3>
        </a>
        
        <a href="Uploaddoc.php"  >
          <span class="material-icons-round">description</span>
          <h3> Appointment </h3>
        </a>
        <a href="Availability.php" class="active" >
          <?php
           if ($result6) {
             $notif = mysqli_num_rows($result6);
             mysqli_free_result($result6);
           }
          ?>       
          <span class="material-icons-round">check</span>
          <h3> Availability </h3>
          <span class="request-count"><?php echo $notif; ?></span>
        </a>
        <!--
        <a href="ManageD.php" >
          <span class="material-icons-round"> description</span>
          <h3> Manage Documents </h3>
        </a>
          -->
        <a href="Transaction Log.php">
          <span class="material-icons-round"> report</span>
          <h3> Transaction Logs </h3>
        </a>
        <a href="Manageusers.php">
          <span class="material-icons-round"> settings</span>
          <h3> Manage Staff</h3>
        </a>
        <a href="Logout.php">
          <span class="material-icons-round">power_settings_new </span>
          <h3> Logout </h3>
        </a>
      </div>
    </aside>


      <!-------END OF ASIDE------>
  
      <main class="col-md-8 ">
  
      
        <script type="text/javascript" src="DataTables/datatables.min.js"></script>
        
               <br>
               <br>
               <br>
               <br>
              
      <div>
      <h4>AVAILABILITY</h4>
      <!--
          <button  type="button" class="btn add-request" style="float:right; background-color: #f5bc45; margin:5px;"> ADD REQUEST</button>
        <i Style="Color:red;"><?php echo $notif." Pending request"; ?></i>
          -->
         <button onclick="location.href='Availability Released.php'" type="button" class="btn" style="float:right; background-color: #BADADD; margin:5px;">RELEASED ✅</button>
        <br>
        <br>
          <div class="">
           <div class="middle">
             <div class="left">
                <div class="table-responsive">  
                     <table id="request_data" class="table table-borderless" align="left" style="font-size: 11px;">  
                          <thead>  
                               <tr> 
                                   
                                    <td>Request ID</td>
                                    <td>Stud ID</td>  
                                    <td>First name</td>  
                                    <td>Middle name</td>  
                                    <td>Last name</td>  
                                    <td>Docu Type</td>
                                    <td>Course</td>
                                    <td>Request Date</td>
                                    <td>Request Status</td>
                                    <td>Document Status</td>
                                    <td>Released Date</td>
                                    <td>Manage</td>
                                    <td></td>


                               </tr>  
                          </thead>  
                          <?php  
                          while($row = mysqli_fetch_array($result))  
                          {  
                               echo '  
                               <tr>  
                                    <td>'.$row["rid"].'</td>
                                    <td>'.$row["student_id"].'</td>  
                                    <td>'.$row["fname"].'</td>  
                                    <td>'.$row["mname"].'</td>  
                                    <td>'.$row["lname"].'</td>
                                    <td>'.$row["type"].'</td>
                                    <td>'.$row["course"].'</td>
                                    <td>'.$row["rdate"].'</td>
                                    <td>'.$row["status"].'</td>
                                    <td>'.$row["doc_status"].'</td>
                                    <td>'.$row["Released"].'</td>
                                    <td><button type="button" class="btn btn-warning edit" style="font-size: 11px;"> Edit </button> </td>
                                    <td><button type="button" class="btn btn-warning delete" style="font-size: 11px;"> Delete </button> </td>
                               </tr>  
                               ';  
                          }  
                          ?>  
                     </table>  
                </div>  
        </div>
    </div>
</div>

           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script> 
           <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>  
           <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script> 
           <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
           <script src="https://cdn.datatables.net/plug-ins/1.11.1/features/fuzzySearch/dataTables.fuzzySearch.js"></script>
    </main> 
   <!-------------------END OF MAIN---------------->  

       <script src="./index.js"></script>
     
</body>
</html>
 <script>
     $(document).ready(function() { 
        var table = $('#request_data').DataTable({ 
            fuzzySearch: {toggleSmart: false,threshold: 0.6},
            "autoWidth" : true,
            "paging": true,
            "scrollY": 250,
            "scrollX": false,
            order: [[7, 'desc']]
        });
        
         
     } );
 </script> 
 
 
 <script>  
 $(document).ready(function(){  
      $('.edit').on('click', function() {

          $('#editmodal').modal('hide')
          $('#editmodal').modal('show');
            $tr = $(this).closest('tr');
            var data = $tr.children("td").map(function() {
              return $(this).text();
            }).get();

              console.log(data);

              $('#updateid').val(data[0]);
              $('#student_id').val(data[1]);
              $('#fname').val(data[2]);
              $('#mname').val(data[3]);
              $('#lname').val(data[4]);
              $('#type').val(data[5]);
              $('#course').val(data[6]);
              $('#rdate').val(data[7]);
              $('#released').val(data[10]);

    });
    //IT STARTS HERE (CLOSE FUNCTION)
    $('.close,.btn').click(function() {
        $( "#editmodal" ).modal('hide');
      });
    //IT ENDS HERE (CLOSE FUNCTION)

  });  

 </script>
 
 <script>  
 $(document).ready(function(){  
      $('.add-request').on('click', function() {
          $('#createmodal').modal('show');
            $tr = $(this).closest('tr');
            var data = $tr.children("td").map(function() {
              return $(this).text();
            }).get();

              console.log(data);

         
    });

        //IT STARTS HERE (CLOSE FUNCTION)
    $('.close,.btn').click(function() {
        $( "#createmodal" ).modal('hide');
      		});
    //IT ENDS HERE (CLOSE FUNCTION)
  			});  

 </script>
<script>  
 $(document).ready(function(){  
      $('.delete').on('click', function() {
          $('#deletemodal').modal('show');
            $tr = $(this).closest('tr');
            var data = $tr.children("td").map(function() {
              return $(this).text();
            }).get();

              console.log(data);

              $('#deleteid').val(data[0]);

         
    });

        //IT STARTS HERE (CLOSE FUNCTION)
    $('.close,.btn').click(function() {
        $( "#deletemodal" ).modal('hide');
      });
    //IT ENDS HERE (CLOSE FUNCTION)
  });  

 </script>
 