<?php
require_once("MUDMSCON.php");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $email = $_POST['email'];
    $title = $_POST['title'];
    $selectedPurpose = $_POST['selectedPurpose'];
    $selectedCategory = $_POST['selectedCategory'];
    $selectedCourse = $_POST['selectedCourse'];
    $selectedYear = $_POST['selectedYear'];
    $dateOfRequest = $_POST['dateOfRequest'];
    $lastSemesterAndSY = $_POST['lastSemesterAndSY'];
    $dateOfGraduation = $_POST['dateOfGraduation'];
    $alreadyRequestedCredentials = $_POST['alreadyRequestedCredentials'];
    $specifyText = $_POST['specifyText'];
    $dateRequested = $_POST['dateRequested'];
    $status = "Pending";
    $overallstatus = "IN PROGRESS";
    $selectedCertification = $_POST['selectedCertification'];
    $selectedCAVCertification = isset($_POST['selectedCAVCertification']) ? $_POST['selectedCAVCertification'] : "None";
    
    if (isset($_POST['file'])) {
        $fileData = $_POST['file'];
        $fileBytes = base64_decode($fileData);

        $targetDirectory = "uploads/";

        if (!file_exists($targetDirectory)) {
            mkdir($targetDirectory, 0777, true);
        }

        $uniqueFilename = uniqid() . '_' . $email . '.jpg';

        $targetPath = $targetDirectory . $uniqueFilename;
        if (file_put_contents($targetPath, $fileBytes)) {
            echo "File uploaded successfully to: $targetPath";
        } else {
            echo "File upload failed";
        }
    } else {
        echo "No file uploaded";
    }

    // Check connection
    if ($con->connect_error) {
        die("Connection failed: " . $con->connect_error);
    }

    $docstatus = "Pending";

    // Prepare the SQL INSERT statement
    $sql = "INSERT INTO appointments (email, title, selectedPurpose, selectedCategory, selectedCourse, selectedYear, dateOfRequest, lastSemesterAndSY, dateOfGraduation, alreadyRequestedCredentials, specifyText, dateRequested, status, fileUpload, Docstatus, selectedCAVCertification,selectedCertification,overall_status) 
            VALUES ('$email', '$title', '$selectedPurpose', '$selectedCategory', '$selectedCourse', '$selectedYear', '$dateOfRequest', '$lastSemesterAndSY', '$dateOfGraduation', '$alreadyRequestedCredentials', '$specifyText', '$dateRequested', '$status', '$targetPath', '$docstatus', '$selectedCAVCertification',  '$selectedCertification','$overallstatus')";

    $con->commit();

    echo "SQL Query: $sql";

    if ($con->query($sql) === TRUE) {
        // Data insertion successful
        echo "Data inserted successfully";
    } else {
        // Error inserting data
        echo "Error inserting data: " . $con->error;
    }

    // Close the database connection
    $con->close();
} else {
    // Invalid request method
    echo "Invalid request method";
}
?>
