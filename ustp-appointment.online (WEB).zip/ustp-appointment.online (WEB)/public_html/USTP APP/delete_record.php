<?php
// delete_record.php
session_start();
include_once 'MUDMSCON.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['appointmentId'])) {
    $appointmentId = $_POST['appointmentId'];

    // Use prepared statement to avoid SQL injection
    $deleteQuery = "DELETE FROM appointments WHERE id = ?";
    $stmt = mysqli_prepare($con, $deleteQuery);

    // Bind parameters
    mysqli_stmt_bind_param($stmt, "i", $appointmentId);

    // Execute the statement
    $result = mysqli_stmt_execute($stmt);

    if ($result) {
        echo json_encode(array('success' => true, 'message' => 'Record deleted successfully'));
    } else {
        echo json_encode(array('success' => false, 'message' => 'Error deleting record'));
    }

    // Close the statement
    mysqli_stmt_close($stmt);
} else {
    echo json_encode(array('success' => false, 'message' => 'Invalid request'));
}
?>
