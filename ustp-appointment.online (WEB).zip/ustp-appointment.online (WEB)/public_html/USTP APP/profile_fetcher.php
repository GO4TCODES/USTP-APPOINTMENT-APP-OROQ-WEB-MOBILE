<?php
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    
    // with columns 'email', 'student_id', 'fname', 'lname', 'course', 'contact', 'age', 'birthdate', 'id', 'profile_picture'

    $email = $_GET['email'];

  
    $db = new mysqli("localhost", " ", " ", " ");
    $sql = "SELECT * FROM studentacc WHERE email='$email'";
    $result = $db->query($sql);

    if ($result && $result->num_rows > 0) {
        $row = $result->fetch_assoc();
        echo json_encode($row);
    } else {
        echo "User not found or error fetching profile: " . $db->error;
    }

    $db->close();
} else {
    echo "Invalid request method";
}
?>
