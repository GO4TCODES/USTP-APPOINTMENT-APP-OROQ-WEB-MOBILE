<?php
header('Content-Type: application/json');

require_once("MUDMSCON.php");

if ($_SERVER["REQUEST_METHOD"] == "GET") {
    $email = $_GET['email']; // Get the email address from the query parameter
    $sql = "SELECT profile_picture FROM studentacc WHERE email = '$email'";
    $result = $con->query($sql);

    if ($result === false) {
        die("Database error: " . $con->error);
    }

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $profilePictureUrl = $row['profile_picture'];
        
        $response = ['profilePictureUrl' => $profilePictureUrl];
        echo json_encode($response);
    } else {
        echo json_encode(['profilePictureUrl' => '']); // Return an empty URL if no record found
    }
}

// Close the database connection
$con->close();
?>
