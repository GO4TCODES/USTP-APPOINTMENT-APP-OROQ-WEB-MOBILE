<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
// Check if the user is logged in
if (!isset($_SESSION['username'])) {
    $_SESSION['msg'] = "You have to log in first";
    header('location: Login.php');
    exit();
}

$dataPoints1 = array();

try {
    $con = mysqli_connect("localhost", " ", " ", " ");
    mysqli_select_db($con, " ");

    $query = "SELECT title, COUNT(*) as count FROM appointments GROUP BY title";
    $result = mysqli_query($con, $query);

    while ($row = mysqli_fetch_array($result)) {
        array_push($dataPoints1, array("label" => $row["title"], "y" => $row["count"]));
    }
}
catch (\PDOException $ex) {
    print($ex->getMessage());
}
?>
<!-- Rest of your HTML code -->

<?php



             include_once 'MUDMSCON.php';
              $query ="SELECT
              a.id AS AppointmentId,
              a.title AS DocumentType,
              a.status AS RequestStatus,
              a.docstatus AS DocumentStatus,
              s.fname AS FirstName,
              s.lname AS LastName,
              s.contact AS Contact,
              s.age AS Age,
              s.birthdate AS DateOfBirth,
              s.profile_picture AS profile_picture,
              a.daterequested AS DateOfRequest,
              a.selectedpurpose AS PurposeOfRequest,
              a.selectedcategory AS Category,
              a.email AS Email,
              s.student_id AS IDNumber,
              a.selectedcourse AS CourseYear,
              a.selectedyear AS selectedYear,
              a.id AS AppointmentNumber,
              a.fileupload AS fileUpload,
              a.overall_status AS overallstatus,
              a.staff AS staff
          FROM appointments a
          INNER JOIN studentacc s ON a.email = s.email";
              $result = mysqli_query($con,$query);

              $query2 ="SELECT request.*,documents.* FROM request, documents WHERE request.rid =documents.rid";
              $result2= mysqli_query($con,$query2);
              
              $query6 ="SELECT * FROM `request` WHERE status='Pending'  
              ORDER BY `request`.`status` ASC";
              $result6=  mysqli_query($con,$query6);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <title>USTP APPOINTMENT LOGS</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css">
  <link  rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/2.2.2/css/buttons.dataTables.min.css">
  <script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.11.3/js/jquery.dataTables.js"></script>
  <link rel="stylesheet" type="text/css" href="DataTables/datatables.min.css"/>
  <!--MATERIAL CDN-->


 
  <link href="https://fonts.googleapis.com/icon?family=Material+Icons+Round"
  rel="stylesheet">

  <!--STYLESHEET-->
  <link rel="stylesheet" href="Style.css">
<link rel="stylesheet" href="Datatable.css">
<script>
window.onload = function () {
 
var chart = new CanvasJS.Chart("chartContainer", {
     exportEnabled: true,
	animationEnabled: true,
	theme: "light2",
	title:{
		text: "Transaction Report"
	},
	axisY:{
		includeZero: false,
	},
	axisX:{
		valueFormatString: "COURSE"

	},
	legend:{
		cursor: "pointer",
		verticalAlign: "center",
		horizontalAlign: "right",
		itemclick: toggleDataSeries
	},
	data: [{
		type: "column",// DIRI I CHANGE IYANG FORMAT LINE, AREA, COLUMN(DEFAULT), PIE
		indexLabel: "{y}",
		yValueFormatString: "#",
		showInLegend: false,
		dataPoints: <?php echo json_encode($dataPoints1, JSON_NUMERIC_CHECK); ?>
	}]
});
chart.render();
 
function toggleDataSeries(e){
	if (typeof(e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
		e.dataSeries.visible = false;
	}
	else{
		e.dataSeries.visible = true;
	}

}
 
}
</script>
</head>
<body>
    
        <!-- Logout Confirmation Modal -->
<div class="modal fade" id="logoutConfirmationModal" tabindex="-1" role="dialog" aria-labelledby="logoutConfirmationModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="logoutConfirmationModalLabel">Logout Confirmation</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Are you sure you want to logout?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <a href="Logout.php" class="btn btn-primary">Logout</a>
            </div>
        </div>
    </div>
</div>

    <!-- Add this modal at the end of your HTML body -->
<div class="modal fade" id="confirmationModal" tabindex="-1" role="dialog" aria-labelledby="confirmationModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="confirmationModalLabel">Confirmation</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                Are you sure you want to delete this record?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                <button type="button" class="btn btn-danger" id="confirmDelete">Delete</button>
            </div>
        </div>
    </div>
</div>

<div class="container-fluid">
  <!-- Central Modal Fluid -->
  <div class="modal fade" id="showreport" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
      aria-hidden="true">
      <div class="modal-dialog modal-fluid" role="document">
        <!--Content-->
        <div class="modal-content">
          <!--Body-->
          <div class="modal-body">
            <div id="chartContainer" style="height: 370px; width: 90%;"></div>
            <script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
          </div>
          <!--Footer-->
          <div class="modal-footer">
            <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
          </div>
        </div>
        <!--/.Content-->
      </div>
    </div>
  <div class="row">
    <aside class="col-md-2">
      <!-- Sidebar content goes here -->
      <div class="top">
        <div class="logo">
          <img src="./images/USTP.png">
          <h1><span class="danger"></span></h1>
        </div>
        <div class="close" id="close-btn">
          <span class="material-icons-round"> close </span>
        </div>
      </div>
      <div class="sidebar">
        <a href="Home.php" >
          <span class="material-icons-round">dashboard</span>
          <h3> Dashboard </h3>
        </a>
        
        <a href="Appointments Admin.php"  >
          <span class="material-icons-round">description</span>
          <h3> Appointment </h3>
        </a>
        <a href="Availability.php"  >
          <?php
           if ($result6) {
             $notif = mysqli_num_rows($result6);
             mysqli_free_result($result6);
           }
          ?>       
          <span class="material-icons-round">check</span>
          <h3> Availability </h3>
          <span class="request-count"><?php echo $notif; ?></span>
        </a>
        <!--
        <a href="ManageD.php" >
          <span class="material-icons-round"> description</span>
          <h3> Manage Documents </h3>
        </a>
          -->
        <a href="Transaction Log.php" class="active">
          <span class="material-icons-round"> report</span>
          <h3> Transaction Logs </h3>
        </a>
        <a href="Manageusers.php">
          <span class="material-icons-round"> settings</span>
          <h3> Manage Staff</h3>
        </a>
         <a href="#" data-toggle="modal" data-target="#logoutConfirmationModal">
            <span class="material-icons-round">power_settings_new</span>
            <h3>Logout</h3>
        </a>
      </div>
    </aside>


      <!-------END OF ASIDE------>
  
      <main class="col-md-8">

        <script type="text/javascript" src="DataTables/datatables.min.js"></script>

  
      <?
           if ($result6)
    {
      
        $notif = mysqli_num_rows($result6);
          
        // close the result.
        mysqli_free_result($result6);
    }?>  
        <h4>TRANSACTION LOGS</h4>
        <button  type="button" class="btn showreport" style="float:left; background-color: #F9E7AF; margin:5px;">Request Count</button>
          <div class="">
           <div class="middle">
             <div class="left">
                <div class="table-responsive">  
                     <table id="request_data" class="table table-borderless" align="left" style="font-size: 11px;">  
                          <thead>  
                               <tr> 
                                    <td>Appointment ID</td>  
                                    <td>Stud ID</td>  
                                    <td>Category</td>
                                    <td>First name</td>
                                    <td>Last name</td>  
                                    <td>Docu Type</td>
                                    <td>Course</td>
                                    <td>Year</td>
                                    <td>Request Date</td>
                                    <td>Request Status</td>
                                    <td>Document Status</td>
                                    <td>Staff</td>
                                    <!--<td>Overall Status</td>--->
                                    <td>Action</td>


                               </tr>  
                          </thead>  
                          <?php  
                          while($row = mysqli_fetch_array($result))  
                          {  
                               echo '  
                               <tr>  
                                    <td>'.$row["AppointmentId"].'</td>  
                                    <td>'.$row["IDNumber"].'</td>  
                                    <td>'.$row["Category"].'</td>
                                    <td>'.$row["FirstName"].'</td>
        
                                    <td>'.$row["LastName"].'</td>
                                    <td>'.$row["DocumentType"].'</td>
                                    <td>'.$row["CourseYear"].'</td>
                                    <td>'.$row["selectedYear"].'</td>
                                    <td>'.$row["DateOfRequest"].'</td>
                                    <td>'.$row["RequestStatus"].'</td>
                                    <td>'.$row["DocumentStatus"].'</td>
                                     <td>'.$row["staff"].'</td>
                                   <!-- <td>'.$row["overallstatus"].'</td>-->
                                     <td>
                                        <button class="btn btn-danger btn-sm delete-btn" data-id="'.$row["AppointmentId"].'">Delete</button>
                                    </td>
                                
                               </tr>  
                               ';  
                          }  
                          ?>  
                     </table>  
                </div>  
        </div>
        
         
    </div>
</div> <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
          <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
          <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

           <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script> 
           <script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>  
           <script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script> 
           <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>
           <script src="https://cdn.datatables.net/plug-ins/1.11.1/features/fuzzySearch/dataTables.fuzzySearch.js"></script>
           <script src="https://cdn.datatables.net/buttons/2.2.2/js/dataTables.buttons.min.js"></script>
           <script src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.print.min.js"></script>
           <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/pdfmake.min.js"></script>
           <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
           <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.53/vfs_fonts.js"></script>
           <script src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.html5.min.js"></script>
           <script src="https://cdn.datatables.net/buttons/2.2.2/js/buttons.colVis.min.js"></script>
    </main> 
   <!-------------------END OF MAIN---------------->  
 <!-------------------TOP RIGHT SIDE, TOGGLE DARK AND LIGHT MODE---------------->  
 <div class="col-md-2">
    <div class="right">
      <div class="top">
        <button id="menu-btn">
          <span class="material-icons-round">menu</span>
        </button>
        
        <div class="profile">
          <div class="info">

            <p>Hello, 

              <b><?php echo $_SESSION['username']?></b></p>
            <small class="text-muted"></small>
          </div>
         <div class="profile-photo">
          <span class="material-icons-round">account_circle</span>
        </div>
        </div>
      </div>
      <!--END OF TOP-->
       <script src="./index.js"></script>

<script>
$(document).ready(function () {
var appointmentIdToDelete; // Variable to store the appointmentId to be deleted

// Delete button click event
$('.delete-btn').on('click', function () {
    appointmentIdToDelete = $(this).data('id');
    $('#confirmationModal').modal('show');
});

// Confirm delete button click event
$('#confirmDelete').on('click', function () {
    // Close the modal
    $('#confirmationModal').modal('hide');

    // Confirm before deleting
    if (appointmentIdToDelete) {
        // Ajax request to delete the record
        $.ajax({
            url: 'delete_record.php', // Replace with the actual PHP file to handle the deletion
            method: 'POST',
            data: { appointmentId: appointmentIdToDelete },
            success: function (response) {
                // Reload the page after deletion
                location.reload();
            },
            error: function (error) {
                console.error('Error deleting record:', error);
            }
        });
    }
});

    // DataTable initialization
    var table = $('#request_data').DataTable({
        fuzzySearch: { toggleSmart: false, threshold: 0.6 },
        "autoWidth": true,
        "paging": true,
        "scrollY": 250,
        "scrollX": false,
        order: [[7, 'desc']],
        buttons: ['print'],
        dom: 'lBfrtip',
        buttons: [
            {
                extend: 'print',
                exportOptions: {
                    columns: ':visible'
                }
            },
            {
                extend: 'copyHtml5',
                exportOptions: {
                    columns: [0, ':visible']
                }
            },
            {
                extend: 'pdfHtml5',
                exportOptions: {
                    columns: ':visible'
                }
            },
            'colvis'
        ]
    });

    // Show Report button click event
    $('.showreport').on('click', function () {
        $('#showreport').modal('show');
        chart.render();
    });

    // Close modal function
    $('.close, .btn').click(function () {
        $('#showreport').modal('hide');
    });
});
</script>
</body>
</html>

 
<script>  
 $(document).ready(function(){  
      $('.showreport').on('click', function() {
          $('#showreport').modal('show');
 

            chart.render();
         
    });

        //IT STARTS HERE (CLOSE FUNCTION)
    $('.close,.btn').click(function() {
        $( "#showreport" ).modal('hide');
      		});
    //IT ENDS HERE (CLOSE FUNCTION)
  			});  

 </script>


 
 