<?php
$hostname = "localhost"; // The database server hostname
$username = // Your MySQL username
$password = // Your MySQL password
$database = // Your database name

$con = mysqli_connect($hostname, $username, $password, $database);

if (!$con) {
    die("Connection Error: " . mysqli_connect_error());
}
?>
