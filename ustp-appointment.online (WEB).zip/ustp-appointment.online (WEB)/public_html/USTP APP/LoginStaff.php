<!DOCTYPE html>
<html>
<head>
	<title>Login Page</title>
	<link rel="stylesheet" type="text/css" href="Style2.css">
	<link rel="stylesheet" type="text/css" href="Newl.css">
</head>
<body>
	<form action="Process2.php" method="POST">
	    	<div class="wrapper fadeInDown">
  <div id="formContent">
    <!-- Tabs Titles -->
    <a href="Login.php">
<h2 class="inactive underlineHover">Admin</h2>
    </a>

    <a href="LoginStaff.php" class="active">
    <h2 class="active">Staff</h2>
    </a>
    <!-- Icon -->
    <div class="fadeIn first">
  <h2 style="text-align: center;font-family: futura; font-size: 55px; text-shadow: -4px 3px #808B96; color: #fcbe03;" class="">MUDMS</h2>
  <br>
  <br>
    </div>

    <!-- Login Form -->
    <form>
      <input type="text" id="user" class="fadeIn second" name="user" placeholder="login">
      <input type="password" id="pass" class="fadeIn third" name="upass" placeholder="password">
       <br>
      <input type="submit" class="fadeIn fourth" value="Log In">
    </form>

  </div>
	</form>

</div>
</body>
</html>