<?php
$mysqli = new mysqli("localhost", "u694644493_ustpapp", "968MxqQc7@0V", "u694644493_ustpapp");

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["action"]) && $_POST["action"] === "resetPassword") {
        $email = $_POST["email"];
        $newPassword = $_POST["newPassword"];

        // Check if the user exists
        $userExists = checkUserExists($email);

        if ($userExists) {
            // For now, we're not hashing the password, so you can directly use the new password.
            $updatedPassword = $newPassword;

            // Update the password for the user
            $updateResult = updatePassword($email, $updatedPassword);

            if ($updateResult) {
                echo "Password updated successfully.";
            } else {
                echo "Failed to update password. Please try again later.";
            }
        } else {
            echo "User not found. Please check the email address.";
        }
    } else {
        echo "Invalid action requested.";
    }
} else {
    echo "Invalid request method.";
}

function checkUserExists($email) {
    global $mysqli;
    $sql = "SELECT email FROM studentacc WHERE email = ?";
    $stmt = $mysqli->prepare($sql);
    if ($stmt === false) {
        return false; // Error in SQL query
    }
    
    $stmt->bind_param("s", $email);
    $stmt->execute();
    
    if ($stmt->error) {
        return false; // Error executing the query
    }
    
    $stmt->store_result();
    $userExists = $stmt->num_rows > 0;
    $stmt->close();
    return $userExists;
}

function updatePassword($email, $newPassword) {
    global $mysqli;
    $sql = "UPDATE studentacc SET password = ? WHERE email = ?";
    $stmt = $mysqli->prepare($sql);
    if ($stmt === false) {
        return false; // Error in SQL query
    }

    $stmt->bind_param("ss", $newPassword, $email);
    $updateResult = $stmt->execute();
    
    if ($stmt->error) {
        return false; // Error executing the query
    }
    
    $stmt->close();
    return $updateResult;
}

$mysqli->close();
?>
