<?php
include_once 'MUDMSCON.php';

if (isset($_POST['deletedata'])) {
    $rid = $_POST['deleteid'];
    $query = "DELETE FROM `request` WHERE `rid` = ?";
    $stmt = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($stmt, "i", $rid);
    if (mysqli_stmt_execute($stmt)) {
        echo '<script type="text/javascript"> alert("Data Updated") </script>';
        header("location:Add.php");
    } else {
        echo "nah";
    }
    mysqli_stmt_close($stmt);
}

if (isset($_POST['deletedata2'])) {
    $rid = $_POST['deleteid'];
    $query = "DELETE FROM `request` WHERE `rid` = ?";
    $stmt = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($stmt, "i", $rid);
    if (mysqli_stmt_execute($stmt)) {
        echo '<script type="text/javascript"> alert("Data Updated") </script>';
        header("location:Availability.php");
    } else {
        echo "nah";
    }
    mysqli_stmt_close($stmt);
}

if (isset($_POST['deletedatauser'])) {
    $rid = $_POST['deleteid'];
    $query = "DELETE FROM `request` WHERE `rid` = ?";
    $stmt = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($stmt, "i", $rid);
    if (mysqli_stmt_execute($stmt)) {
        echo '<script type="text/javascript"> alert("Data Updated") </script>';
        header("location:Pending Staff.php");
    } else {
        echo "nah";
    }
    mysqli_stmt_close($stmt);
}

if (isset($_POST['deletedata2user'])) {
    $rid = $_POST['deleteid'];
    $query = "DELETE FROM `request` WHERE `rid` = ?";
    $stmt = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($stmt, "i", $rid);
    if (mysqli_stmt_execute($stmt)) {
        echo '<script type="text/javascript"> alert("Data Updated") </script>';
        header("location:Released Staff.php");
    } else {
        echo "nah";
    }
    mysqli_stmt_close($stmt);
}

if (isset($_POST['deleteuser'])) {
    $id = $_POST['deleteid'];
    $query = "DELETE FROM `createdaccounts` WHERE `id` = ?";
    $stmt = mysqli_prepare($con, $query);
    mysqli_stmt_bind_param($stmt, "i", $id);
    if (mysqli_stmt_execute($stmt)) {
        echo '<script type="text/javascript"> alert("Data Updated") </script>';
        header("location:Manageusers.php");
    } else {
        echo "nah";
    }
    mysqli_stmt_close($stmt);
}
?>
