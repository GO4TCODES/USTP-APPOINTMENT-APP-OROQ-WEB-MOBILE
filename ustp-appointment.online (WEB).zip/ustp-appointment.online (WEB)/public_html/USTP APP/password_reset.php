<?php
$mysqli = new mysqli("localhost", " ", " ", " ");

if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST["action"])) {
        if ($_POST["action"] === "insertCode") {
            if (isset($_POST["email"], $_POST["code"])) {
                $email = $_POST["email"];
                $code = $_POST["code"];

                // Check if the code already exists for the email
                $existingCode = getPasswordResetCode($email);

                if ($existingCode === null) {
                    // Insert a new code
                    $inserted = insertPasswordResetCode($email, $code);
                    if ($inserted) {
                        echo "Code inserted successfully.";
                    } else {
                        echo "Failed to insert code.";
                    }
                } else {
                    // Update the existing code
                    $updated = updatePasswordResetCode($email, $code);
                    if ($updated) {
                        echo "Code updated successfully.";
                    } else {
                        echo "Failed to update code.";
                    }
                }
            } else {
                echo "Missing data.";
            }
        } elseif ($_POST["action"] === "getCode") {
            if (isset($_POST["email"])) {
                $email = $_POST["email"];
                $code = getPasswordResetCode($email);
                if ($code !== null) {
                    echo $code;
                } else {
                    echo "Code not found.";
                }
            } else {
                echo "Missing data.";
            }
        }
    }
}

/*function insertPasswordResetCode($email, $code) {
    global $mysqli;
    $sql = "INSERT INTO password_reset (email, code) VALUES (?, ?)";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("ss", $email, $code);
    if ($stmt->execute()) {
        $stmt->close();
        return true;
    } else {
        echo "MySQL Error: " . $mysqli->error; // Add this line to display the MySQL error.
        $stmt->close();
        return false;
    }
}
*/
function getPasswordResetCode($email) {
    global $mysqli;
    $sql = "SELECT code FROM studentacc WHERE email = ?";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->bind_result($code);
    if ($stmt->fetch()) {
        $stmt->close();
        return $code;
    } else {
        $stmt->close();
        return null;
    }
}

function updatePasswordResetCode($email, $code) {
    global $mysqli;
    $sql = "UPDATE studentacc SET code = ? WHERE email = ?";
    $stmt = $mysqli->prepare($sql);
    $stmt->bind_param("ss", $code, $email);
    if ($stmt->execute()) {
        $stmt->close();
        return true;
    } else {
        echo "MySQL Error: " . $mysqli->error; // Add this line to display the MySQL error.
        $stmt->close();
        return false;
    }
}

$mysqli->close();
?>