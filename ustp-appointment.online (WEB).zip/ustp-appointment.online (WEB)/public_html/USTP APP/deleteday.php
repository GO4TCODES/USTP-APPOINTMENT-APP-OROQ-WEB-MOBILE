<?php
// Include your database connection code here
require_once("MUDMSCON.php");

if (isset($_POST['date'])) {
    $dateToDelete = $_POST['date'];
    
    // Use prepared statements to prevent SQL injection
    $stmt = $con->prepare("DELETE FROM notavailabledays WHERE date = ?");
    $stmt->bind_param("s", $dateToDelete);
    
    if ($stmt->execute()) {
        // Deletion was successful
        echo "Success";
    } else {
        // Deletion failed
        echo "Error: " . $stmt->error;
    }
    
    // Close the database connection
    $stmt->close();
    $con->close();
}
?>
