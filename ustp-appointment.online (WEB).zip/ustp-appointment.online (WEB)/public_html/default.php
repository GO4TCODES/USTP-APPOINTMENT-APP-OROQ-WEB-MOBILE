<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8">
  <meta http-equiv="refresh" content="5;url=https://USTP-Appointment.online/USTP APP/Login.php">
  <link rel="icon" href="USTP APP/images/USTP.png" type="image/ico" sizes="16x16">
  <title>USTP Appointment System</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      text-align: center;
      background-color: #1a1851;
      margin: 0;
      padding: 0;
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
    }
    .container {
      max-width: 600px;
      background-color: #fff;
      border: 1px solid #ccc;
      box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
      padding: 20px;
    }
    h1 {
      color: #333;
    }
    p {
      font-size: 18px;
      color: #555;
    }
    a {
      text-decoration: none;
      color: #007BFF;
    }
    a:hover {
      text-decoration: underline;
    }
    .logo {
      background: url('USTP APP/images/USTP.png') center center no-repeat;
      background-size: contain;
      height: 150px;
      margin: 0 auto 20px;
    }
    .countdown {
      font-size: 24px;
      font-weight: bold;
      color: #333;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="logo"></div>
    <h1>USTP Appointment</h1>
    <p>You will be redirected to the login page shortly.</p>
    <div class="countdown" id="countdown">5 seconds</div>
    <p>If not, click <a href="https://USTP-Appointment.online/USTP APP/Login.php">here</a>.</p>
  </div>

  <script>
    var countdown = 5;
    var countdownElement = document.getElementById('countdown');

    function updateCountdown() {
      countdown--;
      countdownElement.textContent = countdown + ' seconds';

      if (countdown <= 0) {
        window.location.href = 'https://USTP-Appointment.online/USTP APP/Login.php';
      }
    }

    setInterval(updateCountdown, 1000);
  </script>
</body>
</html>
